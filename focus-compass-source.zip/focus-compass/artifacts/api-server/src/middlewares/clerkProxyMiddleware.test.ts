import express from "express";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./clerkProxyMiddleware";

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

async function runClerkProxyMiddlewareRegressionTests() {
  assert(
    getClerkProxyHost({
      headers: {
        host: "internal.example",
        "x-forwarded-host": "public.example, edge.example",
      },
    }) === "public.example",
    "the proxy and Clerk middleware must agree on the first public forwarded host",
  );

  const previousNodeEnv = process.env.NODE_ENV;
  process.env.NODE_ENV = "development";
  const app = express();
  app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
  app.get(`${CLERK_PROXY_PATH}/probe`, (_req, res) => {
    res.status(204).end();
  });

  const server = app.listen(0, "127.0.0.1");
  try {
    await new Promise<void>((resolve, reject) => {
      server.once("listening", resolve);
      server.once("error", reject);
    });
    const address = server.address();
    assert(
      address !== null && typeof address !== "string",
      "the test server must bind a local port",
    );
    const response = await fetch(
      `http://127.0.0.1:${address.port}${CLERK_PROXY_PATH}/probe`,
    );
    assert(
      response.status === 204,
      "the development pass-through must preserve the mounted Clerk proxy route",
    );
  } finally {
    await new Promise<void>((resolve, reject) => {
      server.close((error) => (error ? reject(error) : resolve()));
    });
    if (previousNodeEnv === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = previousNodeEnv;
  }
}

void runClerkProxyMiddlewareRegressionTests();
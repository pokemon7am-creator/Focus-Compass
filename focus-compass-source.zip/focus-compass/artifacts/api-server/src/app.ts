import express, { type Express, type RequestHandler } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import { clerkMiddleware } from "@clerk/express";
import { publishableKeyFromHost } from "@clerk/shared/keys";
import router from "./routes";
import { logger } from "./lib/logger";
import {
  CLERK_PROXY_PATH,
  clerkProxyMiddleware,
  getClerkProxyHost,
} from "./middlewares/clerkProxyMiddleware";

const app: Express = express();

type RateBucket = { count: number; resetAt: number };

function createRateLimiter(maxRequests: number, windowMs: number): RequestHandler {
  const buckets = new Map<string, RateBucket>();

  return (req, res, next) => {
    const now = Date.now();
    const key = req.ip || req.socket.remoteAddress || "unknown";
    const current = buckets.get(key);
    const bucket =
      !current || current.resetAt <= now
        ? { count: 0, resetAt: now + windowMs }
        : current;

    bucket.count += 1;
    buckets.set(key, bucket);

    if (buckets.size > 10_000) {
      for (const [bucketKey, value] of buckets) {
        if (value.resetAt <= now) buckets.delete(bucketKey);
      }
    }

    res.setHeader("RateLimit-Limit", String(maxRequests));
    res.setHeader("RateLimit-Remaining", String(Math.max(0, maxRequests - bucket.count)));
    res.setHeader("RateLimit-Reset", String(Math.ceil(bucket.resetAt / 1000)));

    if (bucket.count > maxRequests) {
      res.setHeader("Retry-After", String(Math.ceil((bucket.resetAt - now) / 1000)));
      res.status(429).json({ message: "Too many requests. Please wait and try again." });
      return;
    }

    next();
  };
}

app.set("trust proxy", 1);
app.disable("x-powered-by");

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(CLERK_PROXY_PATH, clerkProxyMiddleware());
app.use((_, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  res.setHeader("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'");
  res.setHeader("Cross-Origin-Resource-Policy", "same-site");
  next();
});
app.use(
  cors((req, callback) => {
    const origin = req.header("origin");
    const forwardedHost = req.header("x-forwarded-host")?.split(",")[0]?.trim();
    const requestHost = forwardedHost || req.header("host");
    const configuredOrigins = new Set(
      (process.env.ALLOWED_ORIGINS || "")
        .split(",")
        .map((value) => value.trim())
        .filter(Boolean),
    );
    let allowed = !origin;

    if (origin) {
      try {
        const originUrl = new URL(origin);
        allowed =
          originUrl.host === requestHost ||
          configuredOrigins.has(origin) ||
          (process.env.NODE_ENV !== "production" &&
            (originUrl.hostname === "localhost" ||
              originUrl.hostname.endsWith(".replit.dev") ||
              originUrl.hostname.endsWith(".picard.replit.dev")));
      } catch {
        allowed = false;
      }
    }

    callback(null, {
      origin: allowed ? origin || false : false,
      methods: ["GET", "POST", "PUT", "OPTIONS"],
      allowedHeaders: ["Authorization", "Content-Type"],
      maxAge: 600,
    });
  }),
);
app.use(
  (req, res, next) =>
    clerkMiddleware({
      publishableKey: publishableKeyFromHost(
        getClerkProxyHost(req) ?? "",
        process.env.CLERK_PUBLISHABLE_KEY,
      ),
    })(req, res, next),
);
app.use(express.json({ limit: "8mb" }));

app.use("/api", createRateLimiter(120, 60_000));
app.use("/api/tutor", createRateLimiter(12, 60_000));
app.use("/api/roasts", createRateLimiter(20, 60_000));
app.use("/api", router);

export default app;

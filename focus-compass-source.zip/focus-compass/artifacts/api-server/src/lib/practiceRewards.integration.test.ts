import assert from "node:assert/strict";
import test from "node:test";
import { pool } from "@workspace/db";

const connectionString = process.env.TEST_DATABASE_URL;

test("database CAS grants once and a stale save cannot erase its ledger key", {
  skip: !connectionString,
}, async () => {
  const table = "practice_states_claim_integration";
  const userId = "claim-integration-user";
  const claimKey = "weekly:2025-01-06:focus-sessions";
  const original = {
    version: 1,
    focus: { sessions: [] },
    rewards: { leaves: 0, rewardClaimKeys: [] },
  };
  const claimed = {
    ...original,
    rewards: { leaves: 25, rewardClaimKeys: [claimKey] },
  };

  try {
    await pool.query(`DROP TABLE IF EXISTS ${table}`);
    await pool.query(`
      CREATE TABLE ${table} (
        user_id text PRIMARY KEY,
        revision integer NOT NULL,
        snapshot jsonb NOT NULL
      )
    `);
    await pool.query(
      `INSERT INTO ${table} (user_id, revision, snapshot) VALUES ($1, 4, $2::jsonb)`,
      [userId, JSON.stringify(original)],
    );

    const writerSql = `
      UPDATE ${table}
      SET revision = 5, snapshot = $2::jsonb
      WHERE user_id = $1 AND revision = 4
      RETURNING revision
    `;
    const writers = await Promise.all([
      pool.query(writerSql, [userId, JSON.stringify(claimed)]),
      pool.query(writerSql, [userId, JSON.stringify(claimed)]),
    ]);
    assert.deepEqual(writers.map((result) => result.rowCount).sort(), [0, 1]);

    const staleSave = await pool.query(
      `UPDATE ${table} SET revision = 5, snapshot = $2::jsonb
       WHERE user_id = $1 AND revision = 4 RETURNING revision`,
      [userId, JSON.stringify(original)],
    );
    assert.equal(staleSave.rowCount, 0);

    const result = await pool.query(
      `SELECT revision, snapshot FROM ${table} WHERE user_id = $1`,
      [userId],
    );
    assert.equal(result.rows[0].revision, 5);
    assert.equal(result.rows[0].snapshot.rewards.leaves, 25);
    assert.deepEqual(result.rows[0].snapshot.rewards.rewardClaimKeys, [claimKey]);
  } finally {
    await pool.query(`DROP TABLE IF EXISTS ${table}`);
    await pool.end();
  }
});
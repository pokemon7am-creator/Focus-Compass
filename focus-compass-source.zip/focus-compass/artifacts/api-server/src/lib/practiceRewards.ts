import type { StoredPracticeSnapshot } from "@workspace/db";

export type RewardClaim =
  | {
      kind: "weekly";
      claimKey: string;
      premium: false;
      grant: { kind: "leaves"; amount: number } | { kind: "collectible"; id: string };
    }
  | {
      kind: "pass";
      claimKey: string;
      premium: boolean;
      grant: { kind: "leaves"; amount: number } | { kind: "unlock"; id: string };
    };

export type ClaimResolution =
  | { ok: true; claim: RewardClaim }
  | { ok: false; reason: "invalid" | "obsolete" | "not-eligible" };

type CivilDate = { year: number; month: number; day: number };
type FocusSession = { id?: unknown; completedAt?: unknown; durationMinutes?: unknown };

const WEEKLY_REWARDS = {
  "focus-sessions": { goal: 3, grant: { kind: "leaves", amount: 25 } },
  "focus-minutes": { goal: 60, grant: { kind: "leaves", amount: 30 } },
  "stillness-sessions": { goal: 2 },
} as const;

const COLLECTIBLES = [
  "paper-folded-comet",
  "paper-notebook-moon",
  "paper-origami-rocket",
  "paper-constellation-page",
] as const;

const THEME_NAMES = [
  "Quiet Orbit", "Dawn Circuit", "Rainy Library", "Greenhouse", "Moon Garden",
  "Sunlit Desk", "Tide Pool", "Night Flight", "Paper Planets", "Golden Hour",
  "Evergreen", "Winter Signal", "Ink & Ivy", "Cloud Desk", "Lantern Room",
  "Moss Signal", "Little Comet", "Quiet Harbor", "Copper Dawn", "Atlas Notes",
  "Meadow Circuit", "Blue Lantern", "Seedling Studio", "Still Water",
] as const;

const SPECIAL_REWARDS: Record<number, string> = {
  1: "breath-moonlight",
  2: "roast-bold",
  3: "breath-starlight",
  4: "roast-dry",
  5: "breath-sunrise",
  6: "roast-chaos",
  7: "breath-aurora",
};

const PAPER_PLANETS_REWARDS: Record<number, string> = {
  1: "breath-paperfold",
  2: "roast-margin-notes",
  3: "breath-starlight",
};

function civilDateAt(date: Date, timeZone: string): CivilDate | null {
  try {
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).formatToParts(date);
    const value = (type: Intl.DateTimeFormatPartTypes) =>
      Number(parts.find((part) => part.type === type)?.value);
    const result = { year: value("year"), month: value("month"), day: value("day") };
    return Object.values(result).every(Number.isInteger) ? result : null;
  } catch {
    return null;
  }
}

function civilKey(date: CivilDate) {
  return `${date.year}-${String(date.month).padStart(2, "0")}-${String(date.day).padStart(2, "0")}`;
}

function weekStart(date: CivilDate): CivilDate {
  const utc = new Date(Date.UTC(date.year, date.month - 1, date.day));
  const daysSinceMonday = (utc.getUTCDay() + 6) % 7;
  utc.setUTCDate(utc.getUTCDate() - daysSinceMonday);
  return {
    year: utc.getUTCFullYear(),
    month: utc.getUTCMonth() + 1,
    day: utc.getUTCDate(),
  };
}

export function getCanonicalWeekKey(now: Date, timeZone: string) {
  const civil = civilDateAt(now, timeZone);
  return civil ? civilKey(weekStart(civil)) : null;
}

export function getCanonicalSeasonKey(now: Date, timeZone: string) {
  const civil = civilDateAt(now, timeZone);
  return civil ? `${civil.year}-${String(civil.month).padStart(2, "0")}` : null;
}

export function getCollectibleForWeekKey(weekKey: string) {
  const [year, month, day] = weekKey.split("-").map(Number);
  const civilDay = Math.floor(Date.UTC(year, month - 1, day) / 86_400_000);
  const weekNumber = Math.floor(civilDay / 7);
  const index = ((weekNumber % COLLECTIBLES.length) + COLLECTIBLES.length) % COLLECTIBLES.length;
  return COLLECTIBLES[index];
}

function eligibleTimestampInZone(
  value: unknown,
  prefix: string,
  timeZone: string,
  nowTime: number,
) {
  if (typeof value !== "string") return null;
  const date = new Date(value);
  const time = date.getTime();
  if (Number.isNaN(time) || time > nowTime) return null;
  const civil = civilDateAt(date, timeZone);
  if (!civil) return null;
  const matches = prefix.length === 7
    ? `${civil.year}-${String(civil.month).padStart(2, "0")}` === prefix
    : civilKey(weekStart(civil)) === prefix;
  return matches ? time : null;
}

function sessions(snapshot: StoredPracticeSnapshot): FocusSession[] {
  const value = snapshot.focus?.sessions;
  return Array.isArray(value) ? value as FocusSession[] : [];
}

function stillnessEvents(snapshot: StoredPracticeSnapshot): unknown[] {
  const value = snapshot.rewards?.stillnessEvents;
  return Array.isArray(value) ? value : [];
}

function eligibleSessions(
  snapshot: StoredPracticeSnapshot,
  prefix: string,
  timeZone: string,
  nowTime: number,
) {
  const countedIds = new Set<string>();
  const result: Array<{ id: string; durationMinutes: number }> = [];
  for (const session of sessions(snapshot)) {
    if (
      typeof session.id !== "string" ||
      countedIds.has(session.id) ||
      typeof session.durationMinutes !== "number" ||
      !Number.isFinite(session.durationMinutes) ||
      session.durationMinutes <= 0 ||
      eligibleTimestampInZone(session.completedAt, prefix, timeZone, nowTime) === null
    ) {
      continue;
    }
    countedIds.add(session.id);
    result.push({ id: session.id, durationMinutes: session.durationMinutes });
  }
  return result;
}

function resolveWeekly(
  snapshot: StoredPracticeSnapshot,
  claimKey: string,
  keyDate: string,
  missionId: keyof typeof WEEKLY_REWARDS,
  weekKey: string,
  timeZone: string,
  nowTime: number,
): ClaimResolution {
  if (keyDate !== weekKey) return { ok: false, reason: "obsolete" };
  const weeklySessions = eligibleSessions(snapshot, weekKey, timeZone, nowTime);
  const progress = missionId === "focus-sessions"
    ? weeklySessions.length
    : missionId === "focus-minutes"
      ? weeklySessions.reduce((total, session) => {
          return total + session.durationMinutes;
        }, 0)
      : new Set(
          stillnessEvents(snapshot)
            .map((event) => eligibleTimestampInZone(event, weekKey, timeZone, nowTime))
            .filter((time): time is number => time !== null),
        ).size;
  const reward = WEEKLY_REWARDS[missionId];
  if (progress < reward.goal) return { ok: false, reason: "not-eligible" };
  const grant = missionId === "stillness-sessions"
    ? { kind: "collectible" as const, id: getCollectibleForWeekKey(weekKey) }
    : missionId === "focus-sessions"
      ? WEEKLY_REWARDS["focus-sessions"].grant
      : WEEKLY_REWARDS["focus-minutes"].grant;
  return { ok: true, claim: { kind: "weekly", claimKey, premium: false, grant } };
}

function passGrant(
  seasonKey: string,
  premium: boolean,
  tier: number,
): { kind: "leaves"; amount: number } | { kind: "unlock"; id: string } {
  const month = Number(seasonKey.slice(5, 7));
  const themeName = THEME_NAMES[(month - 1) % THEME_NAMES.length];
  const specialId = premium
    ? themeName === "Paper Planets"
      ? PAPER_PLANETS_REWARDS[tier] ?? SPECIAL_REWARDS[tier]
      : SPECIAL_REWARDS[tier]
    : undefined;
  if (specialId) return { kind: "unlock", id: specialId };
  return { kind: "leaves", amount: Math.min(50, 5 + Math.floor((tier - 1) / 5) * 5) };
}

export function resolveRewardClaim(
  snapshot: StoredPracticeSnapshot,
  claimKey: string,
  timeZone: string,
  now = new Date(),
): ClaimResolution {
  const weekKey = getCanonicalWeekKey(now, timeZone);
  const seasonKey = getCanonicalSeasonKey(now, timeZone);
  if (!weekKey || !seasonKey) return { ok: false, reason: "invalid" };

  const weekly = /^weekly:(\d{4}-\d{2}-\d{2}):(focus-sessions|focus-minutes|stillness-sessions)$/.exec(claimKey);
  if (weekly) {
    return resolveWeekly(
      snapshot,
      claimKey,
      weekly[1],
      weekly[2] as keyof typeof WEEKLY_REWARDS,
      weekKey,
      timeZone,
      now.getTime(),
    );
  }

  const pass = /^pass:(\d{4}-\d{2}):(free|premium):([1-9]\d*)$/.exec(claimKey);
  if (!pass) return { ok: false, reason: "invalid" };
  if (pass[1] !== seasonKey) return { ok: false, reason: "obsolete" };
  const tier = Number(pass[3]);
  if (tier > 50) return { ok: false, reason: "invalid" };
  const monthMinutes = eligibleSessions(snapshot, seasonKey, timeZone, now.getTime())
    .reduce((total, session) => {
      return total + session.durationMinutes;
    }, 0);
  const level = Math.min(50, Math.floor(monthMinutes / 20) + 1);
  if (level < tier) return { ok: false, reason: "not-eligible" };
  const premium = pass[2] === "premium";
  return {
    ok: true,
    claim: { kind: "pass", claimKey, premium, grant: passGrant(seasonKey, premium, tier) },
  };
}

export function getRewardClaimKeys(snapshot: StoredPracticeSnapshot) {
  const value = snapshot.rewards?.rewardClaimKeys;
  return Array.isArray(value)
    ? value.filter((key): key is string => typeof key === "string")
    : [];
}

export function classifyClaimAttempt(
  snapshot: StoredPracticeSnapshot,
  currentRevision: number,
  expectedRevision: number,
  claimKey: string,
) {
  if (getRewardClaimKeys(snapshot).includes(claimKey)) return "already-claimed" as const;
  if (currentRevision !== expectedRevision) return "revision-conflict" as const;
  return "proceed" as const;
}

export function applyRewardClaim(snapshot: StoredPracticeSnapshot, claim: RewardClaim) {
  const rewards = { ...snapshot.rewards };
  if (claim.grant.kind === "leaves") {
    const current = typeof rewards.leaves === "number" ? rewards.leaves : 0;
    rewards.leaves = current + claim.grant.amount;
  } else if (claim.grant.kind === "collectible") {
    const current = Array.isArray(rewards.ownedCollectibles)
      ? rewards.ownedCollectibles.filter((id): id is string => typeof id === "string")
      : [];
    rewards.ownedCollectibles = [...new Set([...current, claim.grant.id])];
  } else {
    const current = Array.isArray(rewards.unlockedRewards)
      ? rewards.unlockedRewards.filter((id): id is string => typeof id === "string")
      : [];
    rewards.unlockedRewards = [...new Set([...current, claim.grant.id])];
    const equipped = rewards.equipped && typeof rewards.equipped === "object"
      ? { ...rewards.equipped as Record<string, unknown> }
      : {};
    if (claim.grant.id.startsWith("breath-")) {
      equipped.breath = claim.grant.id.slice("breath-".length);
    } else if (claim.grant.id.startsWith("roast-")) {
      equipped.roast = claim.grant.id.slice("roast-".length);
    }
    rewards.equipped = equipped;
  }
  rewards.rewardClaimKeys = [...new Set([...getRewardClaimKeys(snapshot), claim.claimKey])];
  return { ...snapshot, rewards };
}

export function mergeRewardClaimKeys(
  incoming: StoredPracticeSnapshot,
  current: StoredPracticeSnapshot,
) {
  const keys = [...new Set([...getRewardClaimKeys(current), ...getRewardClaimKeys(incoming)])];
  return keys.length === 0
    ? incoming
    : { ...incoming, rewards: { ...incoming.rewards, rewardClaimKeys: keys } };
}
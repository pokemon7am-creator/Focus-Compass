import assert from "node:assert/strict";
import test from "node:test";
import type { StoredPracticeSnapshot } from "@workspace/db";
import {
  applyRewardClaim,
  classifyClaimAttempt,
  getCanonicalWeekKey,
  mergeRewardClaimKeys,
  resolveRewardClaim,
} from "./practiceRewards";

function snapshot(
  sessions: Array<{ id: string; completedAt: string; durationMinutes: number }> = [],
): StoredPracticeSnapshot {
  return {
    version: 1,
    focus: { sessions },
    rewards: {
      leaves: 0,
      stillnessEvents: [],
      ownedCollectibles: [],
      unlockedRewards: [],
    },
  };
}

test("canonical Monday uses the supplied IANA time zone", () => {
  const instant = new Date("2025-01-06T00:30:00.000Z");
  assert.equal(getCanonicalWeekKey(instant, "America/Los_Angeles"), "2024-12-30");
  assert.equal(getCanonicalWeekKey(instant, "Asia/Tokyo"), "2025-01-06");
  assert.equal(getCanonicalWeekKey(instant, "not/a-zone"), null);
});

test("weekly progress is derived from stored sessions in the canonical week", () => {
  const state = snapshot([
    { id: "1", completedAt: "2025-01-06T18:00:00.000Z", durationMinutes: 20 },
    { id: "2", completedAt: "2025-01-07T18:00:00.000Z", durationMinutes: 20 },
  ]);
  const result = resolveRewardClaim(
    state,
    "weekly:2025-01-06:focus-sessions",
    "UTC",
    new Date("2025-01-08T12:00:00.000Z"),
  );
  assert.deepEqual(result, { ok: false, reason: "not-eligible" });
});

test("future, invalid, and duplicate sessions cannot earn weekly or pass tiers", () => {
  const state = snapshot([
    { id: "only-valid", completedAt: "2025-01-08T10:00:00.000Z", durationMinutes: 20 },
    { id: "only-valid", completedAt: "2025-01-08T11:00:00.000Z", durationMinutes: 20 },
    { id: "future", completedAt: "2025-01-08T13:00:00.000Z", durationMinutes: 20 },
    { id: "zero", completedAt: "2025-01-08T09:00:00.000Z", durationMinutes: 0 },
    { id: "negative", completedAt: "2025-01-08T09:00:00.000Z", durationMinutes: -20 },
    { id: "nan", completedAt: "2025-01-08T09:00:00.000Z", durationMinutes: Number.NaN },
  ]);
  const now = new Date("2025-01-08T12:00:00.000Z");
  assert.deepEqual(
    resolveRewardClaim(state, "weekly:2025-01-06:focus-sessions", "UTC", now),
    { ok: false, reason: "not-eligible" },
  );
  assert.deepEqual(
    resolveRewardClaim(state, "pass:2025-01:free:3", "UTC", now),
    { ok: false, reason: "not-eligible" },
  );
});

test("Stillness eligibility deduplicates equivalent instants and excludes the future", () => {
  const state = snapshot();
  state.rewards.stillnessEvents = [
    "2025-01-08T10:00:00.000Z",
    "2025-01-08T11:00:00.000+01:00",
    "2025-01-08T13:00:00.000Z",
  ];
  assert.deepEqual(
    resolveRewardClaim(
      state,
      "weekly:2025-01-06:stillness-sessions",
      "UTC",
      new Date("2025-01-08T12:00:00.000Z"),
    ),
    { ok: false, reason: "not-eligible" },
  );
});

test("Pass unlock claims also equip the unlocked breath or roast style", () => {
  const state = snapshot();
  state.rewards.equipped = { breath: "classic", roast: "classic" };
  const resolution = resolveRewardClaim(
    state,
    "pass:2025-01:premium:1",
    "UTC",
    new Date("2025-01-08T12:00:00.000Z"),
  );
  assert.equal(resolution.ok, true);
  if (!resolution.ok) return;
  const claimed = applyRewardClaim(state, resolution.claim);
  assert.deepEqual(claimed.rewards.unlockedRewards, ["breath-moonlight"]);
  assert.deepEqual(claimed.rewards.equipped, {
    breath: "moonlight",
    roast: "classic",
  });
});

test("a concurrent retry observes the CAS winner and cannot grant twice", () => {
  const state = snapshot([
    { id: "1", completedAt: "2025-01-06T18:00:00.000Z", durationMinutes: 20 },
    { id: "2", completedAt: "2025-01-07T18:00:00.000Z", durationMinutes: 20 },
    { id: "3", completedAt: "2025-01-08T18:00:00.000Z", durationMinutes: 20 },
  ]);
  const key = "weekly:2025-01-06:focus-sessions";
  const resolution = resolveRewardClaim(
    state,
    key,
    "UTC",
    new Date("2025-01-08T20:00:00.000Z"),
  );
  assert.equal(resolution.ok, true);
  if (!resolution.ok) return;

  assert.equal(classifyClaimAttempt(state, 4, 4, key), "proceed");
  const winner = applyRewardClaim(state, resolution.claim);
  assert.equal(classifyClaimAttempt(winner, 5, 4, key), "already-claimed");
  assert.equal(winner.rewards.leaves, 25);
});

test("a normal save unions server ledger keys instead of erasing them", () => {
  const current = snapshot();
  current.rewards.rewardClaimKeys = ["weekly:2025-01-06:focus-sessions"];
  const incoming = snapshot();
  incoming.rewards.rewardClaimKeys = ["pass:2025-01:free:1"];
  const merged = mergeRewardClaimKeys(incoming, current);
  assert.deepEqual(merged.rewards.rewardClaimKeys, [
    "weekly:2025-01-06:focus-sessions",
    "pass:2025-01:free:1",
  ]);
});
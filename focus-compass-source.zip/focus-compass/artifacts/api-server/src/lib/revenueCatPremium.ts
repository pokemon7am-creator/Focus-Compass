import { ReplitConnectors } from "@replit/connectors-sdk";

type ListPayload<T> = { items?: T[] };
type ActiveEntitlement = { entitlement_id?: unknown; expires_at?: unknown };
type Entitlement = { id?: unknown; lookup_key?: unknown; state?: unknown };

async function revenueCatGet(path: string, notFoundIsEmpty = false) {
  const response = await new ReplitConnectors().proxy("revenuecat", path, {
    method: "GET",
    headers: { Accept: "application/json" },
  });
  if (notFoundIsEmpty && response.status === 404) return { items: [] };
  if (!response.ok) {
    throw new Error(`RevenueCat verification failed with status ${response.status}`);
  }
  return response.json() as Promise<unknown>;
}

function listItems<T>(payload: unknown): T[] {
  return payload && typeof payload === "object" && Array.isArray((payload as ListPayload<T>).items)
    ? (payload as ListPayload<T>).items!
    : [];
}

async function premiumEntitlementIds(projectId: string) {
  const configuredId = process.env.REVENUECAT_PREMIUM_ENTITLEMENT_ID?.trim();
  if (configuredId) return new Set([configuredId]);

  const lookupKey = process.env.REVENUECAT_PREMIUM_ENTITLEMENT_LOOKUP_KEY?.trim() || "premium";
  const payload = await revenueCatGet(
    `/v2/projects/${encodeURIComponent(projectId)}/entitlements`,
  );
  return new Set(
    listItems<Entitlement>(payload)
      .filter((item) => item.state !== "inactive" && item.lookup_key === lookupKey)
      .map((item) => item.id)
      .filter((id): id is string => typeof id === "string"),
  );
}

export async function hasVerifiedPremiumEntitlement(clerkUserId: string) {
  const projectId = process.env.REVENUECAT_PROJECT_ID?.trim();
  if (!projectId) throw new Error("REVENUECAT_PROJECT_ID is not configured");

  const [activePayload, premiumIds] = await Promise.all([
    revenueCatGet(
      `/v2/projects/${encodeURIComponent(projectId)}/customers/${encodeURIComponent(clerkUserId)}/active_entitlements`,
      true,
    ),
    premiumEntitlementIds(projectId),
  ]);
  if (premiumIds.size === 0) {
    throw new Error("RevenueCat premium entitlement is not configured");
  }
  const now = Date.now();
  return listItems<ActiveEntitlement>(activePayload).some((item) =>
    typeof item.entitlement_id === "string" &&
    premiumIds.has(item.entitlement_id) &&
    (item.expires_at == null ||
      (typeof item.expires_at === "number" && item.expires_at > now)),
  );
}
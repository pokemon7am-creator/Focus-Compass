import { getAuth } from "@clerk/express";
import {
  ClaimPracticeRewardBody,
  ClaimPracticeRewardResponse,
  SavePracticeBody,
} from "@workspace/api-zod";
import { db, practiceStates, type StoredPracticeSnapshot } from "@workspace/db";
import { and, eq } from "drizzle-orm";
import { Router, type IRouter, type Request } from "express";
import {
  applyRewardClaim,
  classifyClaimAttempt,
  getRewardClaimKeys,
  mergeRewardClaimKeys,
  resolveRewardClaim,
} from "../lib/practiceRewards";
import { hasVerifiedPremiumEntitlement } from "../lib/revenueCatPremium";

const router: IRouter = Router();

function getUserId(req: Request) {
  return getAuth(req).userId;
}

function responseFor(row: typeof practiceStates.$inferSelect) {
  return {
    revision: row.revision,
    snapshot: row.snapshot,
    updatedAt: row.updatedAt.toISOString(),
  };
}

router.get("/practice", async (req, res) => {
  const userId = getUserId(req);
  if (!userId) return res.status(401).json({ message: "Sign in to sync your practice." });

  const [row] = await db
    .select()
    .from(practiceStates)
    .where(eq(practiceStates.userId, userId))
    .limit(1);

  if (!row) {
    return res.json({ revision: 0, snapshot: null, updatedAt: null });
  }

  return res.json(responseFor(row));
});

router.put("/practice", async (req, res) => {
  const userId = getUserId(req);
  if (!userId) return res.status(401).json({ message: "Sign in to sync your practice." });

  const parsed = SavePracticeBody.safeParse(req.body);
  if (!parsed.success || parsed.data.expectedRevision > 2_000_000_000) {
    return res.status(400).json({ message: "Invalid practice sync payload." });
  }
  const { expectedRevision } = parsed.data;
  let snapshot = parsed.data.snapshot as StoredPracticeSnapshot;

  if (expectedRevision === 0) {
    const [created] = await db
      .insert(practiceStates)
      .values({ userId, revision: 1, snapshot })
      .onConflictDoNothing({ target: practiceStates.userId })
      .returning();
    if (created) return res.json(responseFor(created));
  } else {
    const [current] = await db
      .select()
      .from(practiceStates)
      .where(eq(practiceStates.userId, userId))
      .limit(1);
    if (current?.revision === expectedRevision) {
      snapshot = mergeRewardClaimKeys(snapshot, current.snapshot);
    }
    const [updated] = await db
      .update(practiceStates)
      .set({
        revision: expectedRevision + 1,
        snapshot,
        updatedAt: new Date(),
      })
      .where(
        and(
          eq(practiceStates.userId, userId),
          eq(practiceStates.revision, expectedRevision),
        ),
      )
      .returning();
    if (updated) return res.json(responseFor(updated));
  }

  const [current] = await db
    .select()
    .from(practiceStates)
    .where(eq(practiceStates.userId, userId))
    .limit(1);

  if (!current) {
    return res.status(409).json({ revision: 0, snapshot: null, updatedAt: null });
  }
  return res.status(409).json(responseFor(current));
});

router.post("/practice/claims", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  if (!userId) {
    res.status(401).json({ message: "Sign in to claim practice rewards." });
    return;
  }

  const parsed = ClaimPracticeRewardBody.safeParse(req.body);
  if (!parsed.success || parsed.data.expectedRevision > 2_000_000_000) {
    res.status(400).json({ message: "Invalid reward claim payload." });
    return;
  }
  const { claimKey, expectedRevision, timeZone } = parsed.data;
  const [current] = await db
    .select()
    .from(practiceStates)
    .where(eq(practiceStates.userId, userId))
    .limit(1);

  if (!current) {
    if (expectedRevision !== 0) {
      res.status(409).json({ revision: 0, snapshot: null, updatedAt: null });
    } else {
      res.status(403).json({ message: "No synced practice progress is available." });
    }
    return;
  }

  const attempt = classifyClaimAttempt(
    current.snapshot,
    current.revision,
    expectedRevision,
    claimKey,
  );
  if (attempt === "already-claimed") {
    res.json(ClaimPracticeRewardResponse.parse({
      status: "already-claimed",
      practice: responseFor(current),
    }));
    return;
  }
  if (attempt === "revision-conflict") {
    res.status(409).json(responseFor(current));
    return;
  }

  const resolution = resolveRewardClaim(current.snapshot, claimKey, timeZone);
  if (!resolution.ok) {
    const status = resolution.reason === "not-eligible" ? 403 : 400;
    const message = resolution.reason === "not-eligible"
      ? "This reward has not been earned."
      : resolution.reason === "obsolete"
        ? "This reward claim is no longer current."
        : "Invalid reward claim.";
    res.status(status).json({ message });
    return;
  }

  if (resolution.claim.premium) {
    let isPremium: boolean;
    try {
      isPremium = await hasVerifiedPremiumEntitlement(userId);
    } catch (error) {
      req.log.error({ err: error, userId }, "Could not verify RevenueCat entitlement");
      res.status(503).json({ message: "Premium entitlement could not be verified." });
      return;
    }
    if (!isPremium) {
      res.status(403).json({ message: "An active Premium entitlement is required." });
      return;
    }
  }

  const snapshot = applyRewardClaim(current.snapshot, resolution.claim);
  const [updated] = await db
    .update(practiceStates)
    .set({
      revision: current.revision + 1,
      snapshot,
      updatedAt: new Date(),
    })
    .where(
      and(
        eq(practiceStates.userId, userId),
        eq(practiceStates.revision, current.revision),
      ),
    )
    .returning();

  if (updated) {
    res.json(ClaimPracticeRewardResponse.parse({
      status: "claimed",
      practice: responseFor(updated),
    }));
    return;
  }

  const [latest] = await db
    .select()
    .from(practiceStates)
    .where(eq(practiceStates.userId, userId))
    .limit(1);
  if (latest && getRewardClaimKeys(latest.snapshot).includes(claimKey)) {
    res.json(ClaimPracticeRewardResponse.parse({
      status: "already-claimed",
      practice: responseFor(latest),
    }));
    return;
  }
  res.status(409).json(
    latest ? responseFor(latest) : { revision: 0, snapshot: null, updatedAt: null },
  );
});

export default router;
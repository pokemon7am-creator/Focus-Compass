import { Router, type IRouter } from "express";
import {
  ExplainTutorQuestionBody,
  ExplainTutorQuestionResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();
const MODEL = "gpt-5.4-mini";

type TutorExplanation = {
  explanation: string;
  keyIdeas: string[];
  followUp: string;
};

function cleanText(value: unknown, min: number, max: number) {
  if (typeof value !== "string") return null;
  const cleaned = value.trim();
  return cleaned.length >= min && cleaned.length <= max ? cleaned : null;
}

function parseTutorExplanation(content: string | null): TutorExplanation {
  if (!content) throw new Error("The tutor returned an empty response.");

  const parsed: unknown = JSON.parse(content);
  if (!parsed || typeof parsed !== "object") {
    throw new Error("The tutor returned an invalid response.");
  }

  const response = parsed as Partial<TutorExplanation>;
  const explanation = cleanText(response.explanation, 1, 8000);
  const followUp = cleanText(response.followUp, 1, 1000);
  const keyIdeas = Array.isArray(response.keyIdeas)
    ? response.keyIdeas
        .map((idea) => cleanText(idea, 1, 500))
        .filter((idea): idea is string => Boolean(idea))
        .slice(0, 5)
    : [];

  if (!explanation || !followUp || keyIdeas.length === 0) {
    throw new Error("The tutor response was missing required fields.");
  }

  return ExplainTutorQuestionResponse.parse({ explanation, keyIdeas, followUp });
}

router.post("/tutor/explain", async (req, res): Promise<void> => {
  const body = ExplainTutorQuestionBody.safeParse(req.body);

  if (!body.success) {
    res.status(400).json({ message: "A subject and question are required." });
    return;
  }

  const subject = cleanText(body.data.subject, 1, 80);
  const materials = cleanText(body.data.materials, 0, 12000) ?? "";
  const question = cleanText(body.data.question, 1, 4000);
  const imageDataUrl = cleanText(body.data.imageDataUrl, 0, 5000000);

  if (!subject || !question) {
    res.status(400).json({ message: "A subject and question are required." });
    return;
  }

  if (!process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || !process.env.AI_INTEGRATIONS_OPENAI_API_KEY) {
    res.status(503).json({
      message: "The tutor provider is not available in this workspace yet.",
    });
    return;
  }

  const userText = [
    `Subject: ${subject}`,
    materials ? `Study materials:\n${materials}` : "No written study materials were provided.",
    `Student question:\n${question}`,
  ].join("\n\n");

  const userContent: Array<
    | { type: "text"; text: string }
    | { type: "image_url"; image_url: { url: string; detail: "auto" } }
  > = [{ type: "text", text: userText }];

  if (imageDataUrl) {
    userContent.push({
      type: "image_url",
      image_url: { url: imageDataUrl, detail: "auto" },
    });
  }

  try {
    // Load the provider only when a request needs it. The provider package
    // intentionally throws during initialization if its managed integration
    // is not provisioned; keeping that failure inside the request preserves
    // the API's explicit 503 response and lets the rest of the server start.
    const { openai } = await import("@workspace/integrations-openai-ai-server");
    const completion = await openai.chat.completions.create({
      model: MODEL,
      max_completion_tokens: 1200,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content: [
            "You are Focus Compass Tutor, a patient study coach for learners of varied ages.",
            "Explain the student's question accurately and in approachable language.",
            "Use supplied notes and images as context, but point out uncertainty instead of inventing unreadable or missing details.",
            "Teach the reasoning rather than merely giving an answer. For calculations, show concise steps.",
            "Return only JSON with exactly these fields:",
            '{"explanation":"string","keyIdeas":["string"],"followUp":"string"}',
            "Provide 2 to 5 short key ideas and one useful question that checks understanding or invites the next step.",
          ].join(" "),
        },
        { role: "user", content: userContent },
      ],
    });

    res.json(parseTutorExplanation(completion.choices[0]?.message?.content ?? null));
  } catch (error) {
    req.log?.error({ err: error }, "Tutor provider request failed");
    res.status(503).json({
      message: "The tutor provider is temporarily unavailable. Please try again.",
    });
  }
});

export default router;
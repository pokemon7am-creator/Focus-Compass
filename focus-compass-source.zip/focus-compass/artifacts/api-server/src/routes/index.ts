import { Router, type IRouter } from "express";
import healthRouter from "./health";
import leaderboardRouter from "./leaderboard";
import roastsRouter from "./roasts";
import tutorRouter from "./tutor";
import practiceRouter from "./practice";

const router: IRouter = Router();

router.use(healthRouter);
router.use(leaderboardRouter);
router.use(roastsRouter);
router.use(tutorRouter);
router.use(practiceRouter);

export default router;

import { Router, type IRouter } from "express";
import { db, leaderboardEntries } from "@workspace/db";
import { desc, eq, sql } from "drizzle-orm";

const router: IRouter = Router();

function cleanText(value: unknown, min: number, max: number) {
  if (typeof value !== "string") return null;
  const cleaned = value.trim().replace(/\s+/g, " ");
  return cleaned.length >= min && cleaned.length <= max ? cleaned : null;
}

function cleanMinutes(value: unknown) {
  return Number.isInteger(value) && Number(value) >= 0 && Number(value) <= 100000
    ? Number(value)
    : null;
}

router.get("/leaderboard", async (req, res) => {
  const areaKey = cleanText(req.query.areaKey, 2, 120);
  if (!areaKey) return res.status(400).json({ message: "A valid area is required." });

  const entries = await db
    .select({
      nickname: leaderboardEntries.nickname,
      focusMinutes: leaderboardEntries.focusMinutes,
      stillnessMinutes: leaderboardEntries.stillnessMinutes,
      totalMinutes: sql<number>`${leaderboardEntries.focusMinutes} + ${leaderboardEntries.stillnessMinutes}`,
      updatedAt: leaderboardEntries.updatedAt,
      areaLabel: leaderboardEntries.areaLabel,
    })
    .from(leaderboardEntries)
    .where(eq(leaderboardEntries.areaKey, areaKey))
    .orderBy(
      desc(sql`${leaderboardEntries.focusMinutes} + ${leaderboardEntries.stillnessMinutes}`),
      desc(leaderboardEntries.updatedAt),
    )
    .limit(20);

  return res.json({
    areaLabel: entries[0]?.areaLabel ?? areaKey,
    entries: entries.map(({ areaLabel: _areaLabel, ...entry }) => ({
      ...entry,
      updatedAt: entry.updatedAt.toISOString(),
    })),
  });
});

router.post("/leaderboard", async (req, res) => {
  const installationId = cleanText(req.body.installationId, 8, 128);
  const nickname = cleanText(req.body.nickname, 2, 40);
  const areaKey = cleanText(req.body.areaKey, 2, 120);
  const areaLabel = cleanText(req.body.areaLabel, 2, 120);
  const focusMinutes = cleanMinutes(req.body.focusMinutes);
  const stillnessMinutes = cleanMinutes(req.body.stillnessMinutes);

  if (!installationId || !nickname || !areaKey || !areaLabel || focusMinutes === null || stillnessMinutes === null) {
    return res.status(400).json({ message: "Invalid leaderboard activity." });
  }

  const [entry] = await db
    .insert(leaderboardEntries)
    .values({ installationId, nickname, areaKey, areaLabel, focusMinutes, stillnessMinutes })
    .onConflictDoUpdate({
      target: [leaderboardEntries.installationId, leaderboardEntries.areaKey],
      set: { nickname, areaLabel, focusMinutes, stillnessMinutes, updatedAt: new Date() },
    })
    .returning();

  return res.json({
    nickname: entry.nickname,
    focusMinutes: entry.focusMinutes,
    stillnessMinutes: entry.stillnessMinutes,
    totalMinutes: entry.focusMinutes + entry.stillnessMinutes,
    updatedAt: entry.updatedAt.toISOString(),
  });
});

export default router;
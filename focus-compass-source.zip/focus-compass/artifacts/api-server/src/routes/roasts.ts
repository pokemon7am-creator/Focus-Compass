import { openai } from "@workspace/integrations-openai-ai-server";
import { Router, type IRouter } from "express";

const router: IRouter = Router();
const MODEL = "gpt-5.4-mini";
const roastStyles = new Set(["classic", "bold", "dry", "chaos", "margin-notes"]);
const roastModes = new Set(["override", "app-switch", "end-session"]);

function cleanEnum(value: unknown, allowed: Set<string>) {
  return typeof value === "string" && allowed.has(value) ? value : null;
}

function cleanCount(value: unknown, max: number) {
  return typeof value === "number" && Number.isInteger(value) && value >= 0 && value <= max
    ? value
    : null;
}

router.post("/roasts/generate", async (req, res) => {
  const style = cleanEnum(req.body?.style, roastStyles);
  const mode = cleanEnum(req.body?.mode, roastModes);
  const elapsedMinutes = cleanCount(req.body?.elapsedMinutes, 1440);
  const overrideCount = cleanCount(req.body?.overrideCount, 1000);

  if (!style || !mode || elapsedMinutes === null || overrideCount === null) {
    return res.status(400).json({ message: "Valid roast context is required." });
  }

  if (!process.env.AI_INTEGRATIONS_OPENAI_BASE_URL || !process.env.AI_INTEGRATIONS_OPENAI_API_KEY) {
    return res.status(503).json({ message: "The roast provider is unavailable." });
  }

  try {
    const intensity =
      elapsedMinutes >= 45 ? "most intense" :
      elapsedMinutes >= 25 ? "strong" :
      elapsedMinutes >= 10 ? "medium" :
      "light";
    const completion = await openai.chat.completions.create({
      model: MODEL,
      max_completion_tokens: 180,
      response_format: { type: "json_object" },
      messages: [
        {
          role: "system",
          content: [
            "You write brief, playful focus-app roasts that help a person reconsider abandoning a focus session.",
            "Keep the tone witty, motivating, and PG. Never insult appearance, intelligence, identity, disability, mental health, or protected traits.",
            "Never use threats, shame, profanity, sexual content, self-harm references, or cruel language.",
            "For margin-notes style, use a clever bookish footnote or annotation reference.",
            "Scale the roast's wit to the supplied intensity: light is gentle, medium is pointed, strong is sharper, and most intense is the savagest allowed by these safety rules.",
            "Write one sentence under 180 characters. Do not use quotation marks.",
            'Return only JSON in this exact shape: {"roast":"string"}',
          ].join(" "),
        },
        {
          role: "user",
          content: [
            `Roast style: ${style}.`,
            `Event: ${mode}.`,
            `Completed focus minutes: ${elapsedMinutes}.`,
            `Roast intensity: ${intensity}.`,
            `Overrides today: ${overrideCount}.`,
            "Make it specific to this event without overstating what the app can detect.",
          ].join(" "),
        },
      ],
    });

    const content = completion.choices[0]?.message?.content;
    const parsed: unknown = content ? JSON.parse(content) : null;
    const roast =
      parsed && typeof parsed === "object" && typeof (parsed as { roast?: unknown }).roast === "string"
        ? (parsed as { roast: string }).roast.trim()
        : "";

    if (!roast || roast.length > 240) {
      throw new Error("The roast provider returned an invalid response.");
    }

    return res.json({ roast });
  } catch (error) {
    req.log?.error({ err: error }, "Roast provider request failed");
    return res.status(503).json({
      message: "The roast provider is temporarily unavailable. Please try again.",
    });
  }
});

export default router;
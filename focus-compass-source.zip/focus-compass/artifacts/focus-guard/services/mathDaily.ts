export function localCalendarDay(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function isCompletedForLocalDay(storedDay: string | null, now = new Date()) {
  return storedDay === localCalendarDay(now);
}

export function legacyMathWasCompletedOnDay(history: string[], day: string) {
  return legacyFrictionWasCompletedOnDay(history, 'math', day);
}

export function legacyFrictionWasCompletedOnDay(
  history: string[],
  kind: 'math' | 'physical',
  day: string,
) {
  return history.some((entry) => {
    const match = new RegExp(`^${kind}:[1-4]:(.+)$`).exec(entry);
    if (!match) return false;
    const completedAt = new Date(match[1]);
    return !Number.isNaN(completedAt.getTime()) && localCalendarDay(completedAt) === day;
  });
}
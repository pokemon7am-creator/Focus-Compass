import type { Soundscape } from '@/context/RewardsContext';

export const ambientAudioSources: Record<Exclude<Soundscape, 'none'>, string> = {
  'rainy-library': require('../assets/audio/lofi-rainy-library.wav'),
  'quiet-spacecraft': require('../assets/audio/lofi-night-train.wav'),
  'turning-pages': require('../assets/audio/lofi-cafe-beats.wav'),
  'greenhouse-rain': require('../assets/audio/lofi-greenhouse-guitar.wav'),
  'misty-window': require('../assets/audio/lofi-misty-window.wav'),
  'sunday-vinyl': require('../assets/audio/lofi-sunday-vinyl.wav'),
  'ocean-desk': require('../assets/audio/lofi-ocean-desk.wav'),
  'library-lamp': require('../assets/audio/lofi-library-lamp.wav'),
};

export const soundscapeLabels: Record<Soundscape, string> = {
  none: 'None',
  'rainy-library': 'Lofi Rainy Library',
  'quiet-spacecraft': 'Lofi Night Train',
  'turning-pages': 'Lofi Café Beats',
  'greenhouse-rain': 'Lofi Greenhouse Guitar',
  'misty-window': 'Lofi Misty Window',
  'sunday-vinyl': 'Lofi Sunday Vinyl',
  'ocean-desk': 'Lofi Ocean Desk',
  'library-lamp': 'Lofi Library Lamp',
};
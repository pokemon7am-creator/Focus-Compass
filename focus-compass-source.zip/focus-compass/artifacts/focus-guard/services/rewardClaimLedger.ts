/** Amount embedded in a claim, used only to reconcile already-awarded histories. */
export function claimLeafAmount(key: string): number {
  if (/^weekly:\d{4}-\d{2}-\d{2}:focus-sessions$/.test(key)) return 25;
  if (/^weekly:\d{4}-\d{2}-\d{2}:focus-minutes$/.test(key)) return 30;
  const pass = /^pass:\d{4}-\d{2}:(free|premium):([1-9]\d*)$/.exec(key);
  if (!pass) return 0;
  const tier = Number(pass[2]);
  if (tier > 50 || (pass[1] === 'premium' && tier <= 7)) return 0;
  return Math.min(50, 5 + Math.floor((tier - 1) / 5) * 5);
}

/** Two guest devices or a lost acknowledgment may contain the same grant. */
export function duplicateClaimLeaves(local: string[], remote: string[], base: string[]) {
  const remoteSet = new Set(remote);
  const baseSet = new Set(base);
  return [...new Set(local)].reduce((total, key) =>
    total + (remoteSet.has(key) && !baseSet.has(key) ? claimLeafAmount(key) : 0), 0);
}
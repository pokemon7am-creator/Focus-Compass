import {
  isCompletedForLocalDay,
  legacyFrictionWasCompletedOnDay,
  legacyMathWasCompletedOnDay,
  localCalendarDay,
} from './mathDaily';

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

/**
 * Pure daily-calendar regression cases. This project does not ship a test
 * framework, so a project harness can invoke this runner without mounting RN.
 */
export function runMathDailyRegressionTests() {
  const lateToday = new Date(2025, 4, 8, 23, 59, 59);
  const tomorrow = new Date(2025, 4, 9, 0, 0, 1);
  const today = localCalendarDay(lateToday);

  assert(today === '2025-05-08', 'completion keys must use the device-local calendar date');
  assert(isCompletedForLocalDay(today, lateToday), 'the completion must remain consumed that day');
  assert(!isCompletedForLocalDay(today, tomorrow), 'the completion must reset at local midnight');

  const matchingIso = lateToday.toISOString();
  assert(
    legacyMathWasCompletedOnDay([`math:2:${matchingIso}`], today),
    'a valid legacy guest math completion must remain trustworthy',
  );
  assert(
    !legacyMathWasCompletedOnDay([`physical:2:${matchingIso}`, 'math:2:not-a-date'], today),
    'physical and malformed legacy records must not consume the math day',
  );
  assert(
    legacyFrictionWasCompletedOnDay([`physical:2:${matchingIso}`], 'physical', today),
    'a valid legacy guest physical completion can migrate',
  );
  assert(
    !legacyFrictionWasCompletedOnDay([`math:2:${matchingIso}`], 'physical', today),
    'math completion must not consume the physical day',
  );
}
import {
  createWeeklyMissions,
  getCollectibleForWeek,
  getLocalWeekKey,
  getWeeklyMissionProgress,
  WeeklyFocusSession,
} from './weeklyMissions';

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

function session(
  id: string,
  completedAt: Date | string,
  durationMinutes: number,
): WeeklyFocusSession {
  return {
    id,
    completedAt:
      typeof completedAt === 'string' ? completedAt : completedAt.toISOString(),
    durationMinutes,
  };
}

/**
 * Pure weekly-calendar regression cases. A project harness can invoke this
 * runner without mounting React Native.
 */
export function runWeeklyMissionsRegressionTests() {
  const monday = new Date(2025, 4, 5, 12);
  const previousSunday = new Date(2025, 4, 4, 23, 59, 59);
  const mondayStart = new Date(2025, 4, 5, 0, 0, 0);
  const nextSunday = new Date(2025, 4, 11, 23, 59, 59);

  assert(getLocalWeekKey(monday) === '2025-05-05', 'weeks must start on Monday');
  assert(
    getLocalWeekKey(previousSunday) === '2025-04-28',
    'Sunday must remain in the preceding local week',
  );
  assert(
    getLocalWeekKey(new Date(2025, 0, 1, 12)) === '2024-12-30',
    'week keys must cross year boundaries using the Monday year',
  );
  assert(
    getLocalWeekKey(new Date(2025, 5, 1, 12)) === '2025-05-26',
    'week keys must cross month boundaries using the Monday month',
  );

  const progress = getWeeklyMissionProgress(
    [
      session('sunday', previousSunday, 50),
      session('monday', mondayStart, 20),
      session('sunday-end', nextSunday, 15),
      session('invalid-time', 'not-a-timestamp', 100),
    ],
    [
      previousSunday.toISOString(),
      mondayStart.toISOString(),
      nextSunday.toISOString(),
      'not-a-timestamp',
    ],
    monday,
  );
  assert(progress.focusSessions === 2, 'the previous Sunday and invalid timestamps must be excluded');
  assert(progress.focusMinutes === 35, 'only minutes completed in the Monday-based week must count');
  assert(progress.stillnessSessions === 2, 'invalid and previous-week Stillness events must be excluded');

  const cappedProgress = getWeeklyMissionProgress(
    [
      session('one', mondayStart, 30),
      session('two', mondayStart, 30),
      session('three', mondayStart, 30),
      session('four', mondayStart, 30),
      session('bad-duration', mondayStart, Number.NaN),
    ],
    [mondayStart.toISOString(), mondayStart.toISOString(), mondayStart.toISOString()],
    monday,
  );
  assert(cappedProgress.focusSessions === 3, 'focus-session progress must cap at three');
  assert(cappedProgress.focusMinutes === 60, 'focus-minute progress must cap at sixty');
  assert(cappedProgress.stillnessSessions === 2, 'Stillness progress must cap at two');

  const eligibilityNow = new Date(2025, 4, 7, 12);
  const eligibleTimestamp = new Date(2025, 4, 6, 12);
  const futureTimestamp = new Date(2025, 4, 8, 12);
  const eligibleProgress = getWeeklyMissionProgress(
    [
      session('eligible', eligibleTimestamp, 15),
      session('eligible', eligibleTimestamp, 15),
      session('future', futureTimestamp, 20),
      session('zero', eligibleTimestamp, 0),
      session('negative', eligibleTimestamp, -5),
      session('infinite', eligibleTimestamp, Number.POSITIVE_INFINITY),
      session('not-a-number', eligibleTimestamp, Number.NaN),
    ],
    [
      eligibleTimestamp.toISOString(),
      eligibleTimestamp.toISOString(),
      futureTimestamp.toISOString(),
    ],
    eligibilityNow,
  );
  assert(
    eligibleProgress.focusSessions === 1 && eligibleProgress.focusMinutes === 15,
    'duplicate IDs, future sessions, and sessions with invalid durations must not count',
  );
  assert(
    eligibleProgress.stillnessSessions === 1,
    'duplicate and future Stillness timestamps must not count',
  );

  const missions = createWeeklyMissions([], [], monday);
  const sessionsMission = missions.find((item) => item.id === 'focus-sessions');
  const minutesMission = missions.find((item) => item.id === 'focus-minutes');
  const stillnessMission = missions.find((item) => item.id === 'stillness-sessions');
  assert(
    sessionsMission?.rewardKind === 'leaves' && sessionsMission.rewardAmount === 25,
    'three focus sessions must reward 25 Leaves',
  );
  assert(
    minutesMission?.rewardKind === 'leaves' && minutesMission.rewardAmount === 30,
    'sixty focus minutes must reward 30 Leaves',
  );
  assert(
    stillnessMission?.rewardKind === 'collectible' &&
      stillnessMission.collectibleId === getCollectibleForWeek(monday),
    'two Stillness sessions must reward the rotating Paper Planet',
  );

  const dstWeekMondayMorning = new Date(2025, 2, 10, 0, 1);
  const dstWeekMondayEvening = new Date(2025, 2, 10, 23, 59);
  const dstWeekSundayEvening = new Date(2025, 2, 16, 23, 59);
  const dstCollectible = getCollectibleForWeek(dstWeekMondayMorning);
  assert(
    getCollectibleForWeek(dstWeekMondayEvening) === dstCollectible &&
      getCollectibleForWeek(dstWeekSundayEvening) === dstCollectible,
    'the collectible must be stable across time-of-day and a DST-adjacent week',
  );

  let invalidDateRejected = false;
  try {
    getLocalWeekKey(new Date('not-a-timestamp'));
  } catch (error) {
    invalidDateRejected = error instanceof RangeError;
  }
  assert(invalidDateRejected, 'an invalid reference date must be rejected explicitly');
}
export type WeeklyFocusSession = {
  id: string;
  completedAt: string;
  durationMinutes: number;
};

export type WeeklyMissionId =
  | 'focus-sessions'
  | 'focus-minutes'
  | 'stillness-sessions';

export type WeeklyCollectibleId =
  | 'paper-folded-comet'
  | 'paper-notebook-moon'
  | 'paper-origami-rocket'
  | 'paper-constellation-page';

export type WeeklyCollectible = {
  id: WeeklyCollectibleId;
  title: string;
};

export type WeeklyMission = {
  id: WeeklyMissionId;
  title: string;
  description: string;
  goal: number;
  progress: number;
  rewardLabel: string;
  rewardKind: 'leaves' | 'collectible';
  rewardAmount?: number;
  collectibleId?: WeeklyCollectibleId;
};

export type WeeklyMissionProgress = {
  focusSessions: number;
  focusMinutes: number;
  stillnessSessions: number;
};

export const WEEKLY_COLLECTIBLES: readonly WeeklyCollectible[] = [
  { id: 'paper-folded-comet', title: 'Folded Comet' },
  { id: 'paper-notebook-moon', title: 'Notebook Moon' },
  { id: 'paper-origami-rocket', title: 'Origami Rocket' },
  { id: 'paper-constellation-page', title: 'Constellation Page' },
];

const FOCUS_SESSION_GOAL = 3;
const FOCUS_MINUTES_GOAL = 60;
const STILLNESS_SESSION_GOAL = 2;
const DAYS_PER_WEEK = 7;
const MILLISECONDS_PER_DAY = 24 * 60 * 60 * 1000;

function assertValidDate(date: Date) {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) {
    throw new RangeError('A valid date is required');
  }
}

function getLocalMonday(date: Date) {
  assertValidDate(date);
  const monday = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const daysSinceMonday = (monday.getDay() + 6) % DAYS_PER_WEEK;
  monday.setDate(monday.getDate() - daysSinceMonday);
  return monday;
}

/**
 * Returns the device-local Monday that owns `date`, formatted as YYYY-MM-DD.
 */
export function getLocalWeekKey(date = new Date()) {
  const monday = getLocalMonday(date);
  const year = monday.getFullYear();
  const month = String(monday.getMonth() + 1).padStart(2, '0');
  const day = String(monday.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function getEligibleTimestamp(
  timestamp: string,
  weekKey: string,
  nowTime: number,
) {
  const date = new Date(timestamp);
  const time = date.getTime();
  return !Number.isNaN(time) && time <= nowTime && getLocalWeekKey(date) === weekKey
    ? time
    : null;
}

/**
 * Selects a collectible from the local Monday's civil date. Converting only
 * that date to UTC keeps rotation independent of local time-of-day and DST.
 */
export function getCollectibleForWeek(date = new Date()): WeeklyCollectibleId {
  const monday = getLocalMonday(date);
  const civilDay = Math.floor(
    Date.UTC(monday.getFullYear(), monday.getMonth(), monday.getDate()) /
      MILLISECONDS_PER_DAY,
  );
  const weekNumber = Math.floor(civilDay / DAYS_PER_WEEK);
  const index =
    ((weekNumber % WEEKLY_COLLECTIBLES.length) + WEEKLY_COLLECTIBLES.length) %
    WEEKLY_COLLECTIBLES.length;
  return WEEKLY_COLLECTIBLES[index].id;
}

export function getWeeklyMissionProgress(
  sessions: readonly WeeklyFocusSession[],
  stillnessEvents: readonly string[],
  date = new Date(),
): WeeklyMissionProgress {
  const weekKey = getLocalWeekKey(date);
  const nowTime = date.getTime();
  const countedSessionIds = new Set<string>();
  let focusSessions = 0;
  let focusMinutes = 0;

  for (const session of sessions) {
    if (
      countedSessionIds.has(session.id) ||
      !Number.isFinite(session.durationMinutes) ||
      session.durationMinutes <= 0 ||
      getEligibleTimestamp(session.completedAt, weekKey, nowTime) === null
    ) {
      continue;
    }
    countedSessionIds.add(session.id);
    focusSessions += 1;
    focusMinutes += session.durationMinutes;
  }

  const stillnessTimestamps = new Set<number>();
  for (const timestamp of stillnessEvents) {
    const eligibleTimestamp = getEligibleTimestamp(timestamp, weekKey, nowTime);
    if (eligibleTimestamp !== null) stillnessTimestamps.add(eligibleTimestamp);
  }

  return {
    focusSessions: Math.min(FOCUS_SESSION_GOAL, focusSessions),
    focusMinutes: Math.min(FOCUS_MINUTES_GOAL, focusMinutes),
    stillnessSessions: Math.min(STILLNESS_SESSION_GOAL, stillnessTimestamps.size),
  };
}

export function createWeeklyMissions(
  sessions: readonly WeeklyFocusSession[],
  stillnessEvents: readonly string[],
  date = new Date(),
): WeeklyMission[] {
  const progress = getWeeklyMissionProgress(sessions, stillnessEvents, date);
  const collectibleId = getCollectibleForWeek(date);
  const collectible = WEEKLY_COLLECTIBLES.find((item) => item.id === collectibleId);

  return [
    {
      id: 'focus-sessions',
      title: 'Three focus sessions',
      description: 'Complete three verified focus sessions this week.',
      goal: FOCUS_SESSION_GOAL,
      progress: progress.focusSessions,
      rewardLabel: '25 Leaves',
      rewardKind: 'leaves',
      rewardAmount: 25,
    },
    {
      id: 'focus-minutes',
      title: '60 focused minutes',
      description: 'Spend 60 real minutes in Focus this week.',
      goal: FOCUS_MINUTES_GOAL,
      progress: progress.focusMinutes,
      rewardLabel: '30 Leaves',
      rewardKind: 'leaves',
      rewardAmount: 30,
    },
    {
      id: 'stillness-sessions',
      title: 'Two Stillness sessions',
      description: 'Finish two Stillness sessions and keep your orbit gentle.',
      goal: STILLNESS_SESSION_GOAL,
      progress: progress.stillnessSessions,
      rewardLabel: collectible?.title ?? 'Paper Planets collectible',
      rewardKind: 'collectible',
      collectibleId,
    },
  ];
}
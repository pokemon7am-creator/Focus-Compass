import { requireOptionalNativeModule } from 'expo';
import { DeviceEventEmitter, Linking, Platform } from 'react-native';

export type BlockingStatus = 'unsupported' | 'needs-permission' | 'ready' | 'active';

export type NativeSelectedApp = {
  id: string;
  name: string;
  category?: string;
};

type NativeAppBlocker = {
  getStatus?: () => Promise<BlockingStatus>;
  requestPermission?: () => Promise<boolean>;
  pickApps?: () => Promise<NativeSelectedApp[]>;
  startBlocking?: (appIds: string[], durationSeconds: number) => Promise<void>;
  stopBlocking?: () => Promise<void>;
};

type BlockedAppAttempt = {
  appId?: string;
};

// The first iOS release excludes Screen Time pending distribution approval.
const nativeBlocker = Platform.OS === 'android'
  ? requireOptionalNativeModule<NativeAppBlocker>('SpaceAppBlocker') ?? undefined
  : undefined;

const androidPackages: Record<string, string> = {
  instagram: 'com.instagram.android',
  tiktok: 'com.zhiliaoapp.musically',
  youtube: 'com.google.android.youtube',
  reddit: 'com.reddit.frontpage',
  shopping: 'com.amazon.mShop.android.shopping',
};

export function isNativeBlockingAvailable() {
  return Platform.OS !== 'web' && Boolean(nativeBlocker);
}

export function isSelectedAppAttempt(selectedId: string, attemptedId: string) {
  return selectedId === attemptedId || androidPackages[selectedId] === attemptedId;
}

export function subscribeToBlockedAppAttempts(
  listener: (attempt: { appId: string }) => void,
) {
  if (!isNativeBlockingAvailable()) return () => undefined;

  const subscription = DeviceEventEmitter.addListener(
    'SpaceBlockedAppAttempt',
    (attempt: BlockedAppAttempt) => {
      const appId = typeof attempt?.appId === 'string' ? attempt.appId.trim() : '';
      if (appId) listener({ appId });
    },
  );

  return () => subscription.remove();
}

export async function getBlockingStatus(): Promise<BlockingStatus> {
  if (!isNativeBlockingAvailable() || !nativeBlocker?.getStatus) return 'unsupported';
  try {
    return await nativeBlocker.getStatus();
  } catch {
    return 'unsupported';
  }
}

export async function requestBlockingPermission() {
  if (!isNativeBlockingAvailable() || !nativeBlocker?.requestPermission) return false;
  try {
    return await nativeBlocker.requestPermission();
  } catch {
    return false;
  }
}

export async function pickApps(): Promise<NativeSelectedApp[] | null> {
  if (!isNativeBlockingAvailable() || !nativeBlocker?.pickApps) return null;
  try {
    const selected = await nativeBlocker.pickApps();
    return selected
      .filter((app) => typeof app?.id === 'string' && typeof app?.name === 'string')
      .map((app) => ({
        id: app.id.trim(),
        name: app.name.trim(),
        category: app.category?.trim() || 'App',
      }))
      .filter((app) => app.id.length > 0 && app.name.length > 0);
  } catch {
    return null;
  }
}

export async function startBlocking(appIds: string[], durationSeconds: number) {
  if (!isNativeBlockingAvailable() || !nativeBlocker?.startBlocking) return false;
  if (!Number.isFinite(durationSeconds) || durationSeconds <= 0) return false;
  const selectedIds = [...new Set(appIds)]
    .filter((id): id is string => typeof id === 'string')
    .map((id) => id.trim())
    .filter(Boolean);
  if (selectedIds.length === 0) {
    try {
      // Never let an empty selection mean “block everything” in native code.
      // It also clears a previous session if the user turns off the last item.
      await nativeBlocker.stopBlocking?.();
    } catch {
      return false;
    }
    return false;
  }

  const nativeIds = Platform.OS === 'android'
    ? selectedIds.map((id) => androidPackages[id] ?? id)
    : selectedIds;
  try {
    await nativeBlocker.startBlocking(nativeIds, durationSeconds);
    return true;
  } catch {
    return false;
  }
}

export async function stopBlocking() {
  if (!isNativeBlockingAvailable() || !nativeBlocker?.stopBlocking) return false;
  try {
    await nativeBlocker.stopBlocking();
    return true;
  } catch {
    return false;
  }
}

export async function openBlockingSettings() {
  if (isNativeBlockingAvailable() && nativeBlocker?.requestPermission) {
    // Respect a declined Accessibility disclosure instead of opening a
    // different settings screen after the user chose “Not now”.
    return requestBlockingPermission();
  }

  if (Platform.OS !== 'web' && Platform.OS !== 'android') {
    await Linking.openSettings();
    return true;
  }

  return false;
}

import { OperationTimeoutError, withTimeout } from './asyncTimeout';

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

async function captureFailure(operation: Promise<unknown>) {
  try {
    await operation;
    throw new Error('Expected operation to reject.');
  } catch (error) {
    return error;
  }
}

async function runAsyncTimeoutRegressionTests() {
  assert(
    await withTimeout(Promise.resolve('ready'), 50, 'too slow') === 'ready',
    'a completed operation must return its value',
  );

  const timeout = await captureFailure(
    withTimeout(new Promise<never>(() => undefined), 5, 'status timed out'),
  );
  assert(
    timeout instanceof OperationTimeoutError && timeout.message === 'status timed out',
    'a stalled operation must reject with the configured timeout error',
  );

  const failure = new Error('storage failed');
  assert(
    await captureFailure(withTimeout(Promise.reject(failure), 50, 'too slow')) === failure,
    'an operation error must be preserved',
  );
}

void runAsyncTimeoutRegressionTests();
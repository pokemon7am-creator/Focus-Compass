import { claimLeafAmount, duplicateClaimLeaves } from './rewardClaimLedger';

const assert = { equal(actual: unknown, expected: unknown) {
  if (actual !== expected) throw new Error(`Expected ${String(expected)}, received ${String(actual)}`);
} };
function test(_name: string, run: () => void) { run(); }

test('weekly claims merged from two guest devices contribute only once', () => {
  const keys = ['weekly:2026-09-14:focus-sessions', 'weekly:2026-09-14:focus-minutes'];
  assert.equal(duplicateClaimLeaves(keys, keys, []), 55);
  assert.equal(110 - duplicateClaimLeaves(keys, keys, []), 55);
});

test('acknowledged and non-overlapping rewards are not subtracted', () => {
  const key = 'pass:2026-09:free:1';
  assert.equal(duplicateClaimLeaves([key], [key], [key]), 0);
  assert.equal(duplicateClaimLeaves([key], [], []), 0);
  assert.equal(duplicateClaimLeaves([key, key], [key], []), 5);
});

test('unlocks and collectibles do not contain Leaf awards', () => {
  assert.equal(claimLeafAmount('pass:2026-09:premium:1'), 0);
  assert.equal(claimLeafAmount('weekly:2026-09-14:stillness-sessions'), 0);
  assert.equal(claimLeafAmount('pass:2026-09:free:50'), 50);
  assert.equal(claimLeafAmount('pass:2026-09:premium:8'), 10);
  assert.equal(claimLeafAmount('pass:2026-09:free:51'), 0);
});
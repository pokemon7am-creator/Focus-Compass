const {
  withEntitlementsPlist,
  withInfoPlist,
} = require('@expo/config-plugins');

module.exports = function withSpaceAppBlocker(config) {
  config = withEntitlementsPlist(config, (mod) => {
    mod.modResults['com.apple.developer.family-controls'] = true;
    return mod;
  });
  config = withInfoPlist(config, (mod) => {
    mod.modResults.NSFamilyControlsUsageDescription =
      'Space uses Screen Time access to shield the apps you choose during focus sessions.';
    return mod;
  });
  return config;
};
const { withInfoPlist } = require('@expo/config-plugins');

// Installed Expo packages can add default permission descriptions even when
// their protected APIs are unused. Keep the release limited to actual features.
// Location (including CoreMotion) and image-picker must also remain excluded
// from iOS autolinking: deleting strings alone does not remove native API use.
const unusedPermissions = [
  'NSLocationAlwaysAndWhenInUseUsageDescription',
  'NSLocationAlwaysUsageDescription',
  'NSLocationWhenInUseUsageDescription',
  'NSMotionUsageDescription',
  'NSPhotoLibraryUsageDescription',
  'NSPhotoLibraryAddUsageDescription',
  'NSFaceIDUsageDescription',
  'NSMicrophoneUsageDescription',
];

module.exports = function withRequiredPermissions(config) {
  return withInfoPlist(config, (mod) => {
    for (const permission of unusedPermissions) {
      delete mod.modResults[permission];
    }
    return mod;
  });
};
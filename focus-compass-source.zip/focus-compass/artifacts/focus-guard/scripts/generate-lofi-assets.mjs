import fs from 'node:fs';
import path from 'node:path';

const sampleRate = 22050;
const durationSeconds = 32;
const sampleCount = sampleRate * durationSeconds;
const outputDir = path.resolve('assets/audio');

const tracks = [
  {
    file: 'lofi-rainy-library.wav',
    seed: 17,
    bpm: 76,
    chords: [[57, 60, 64], [53, 57, 60], [60, 64, 67], [55, 59, 62]],
    melody: [76, null, 72, 71, null, 67, 69, null],
    character: 'rain',
  },
  {
    file: 'lofi-cafe-beats.wav',
    seed: 41,
    bpm: 82,
    chords: [[62, 65, 69], [57, 60, 64], [65, 69, 72], [60, 64, 67]],
    melody: [74, 76, null, 72, 69, null, 67, 69],
    character: 'cafe',
  },
  {
    file: 'lofi-greenhouse-guitar.wav',
    seed: 83,
    bpm: 72,
    chords: [[52, 55, 59], [48, 52, 55], [55, 59, 62], [50, 54, 57]],
    melody: [71, null, 69, 67, null, 64, 66, null],
    character: 'garden',
  },
  {
    file: 'lofi-night-train.wav',
    seed: 127,
    bpm: 68,
    chords: [[50, 53, 57], [46, 50, 53], [53, 57, 60], [48, 52, 55]],
    melody: [74, null, 69, null, 67, 65, null, 62],
    character: 'night',
  },
  {
    file: 'lofi-misty-window.wav',
    seed: 191,
    bpm: 70,
    chords: [[59, 62, 66], [55, 59, 62], [62, 66, 69], [57, 60, 64]],
    melody: [78, null, 74, 72, null, 69, 71, null],
    character: 'rain',
  },
  {
    file: 'lofi-sunday-vinyl.wav',
    seed: 233,
    bpm: 79,
    chords: [[55, 59, 62], [50, 54, 57], [57, 60, 64], [52, 55, 59]],
    melody: [72, 74, null, 71, 67, null, 69, 71],
    character: 'cafe',
  },
  {
    file: 'lofi-ocean-desk.wav',
    seed: 277,
    bpm: 66,
    chords: [[48, 52, 55], [45, 48, 52], [52, 55, 59], [47, 50, 54]],
    melody: [69, null, 67, 64, null, 62, 64, null],
    character: 'garden',
  },
  {
    file: 'lofi-library-lamp.wav',
    seed: 311,
    bpm: 74,
    chords: [[53, 57, 60], [49, 53, 56], [56, 60, 63], [51, 55, 58]],
    melody: [76, null, 72, 69, null, 67, 69, null],
    character: 'night',
  },
];

function midiToFrequency(note) {
  return 440 * 2 ** ((note - 69) / 12);
}

function noiseGenerator(seed) {
  let state = seed >>> 0;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return (state / 0xffffffff) * 2 - 1;
  };
}

function envelope(time, duration, attack = 0.02, release = 0.18) {
  const inGain = Math.min(1, time / attack);
  const outGain = Math.min(1, Math.max(0, (duration - time) / release));
  return inGain * outGain;
}

function addNote(buffer, start, length, note, gain, wave, seed) {
  const frequency = midiToFrequency(note);
  const startIndex = Math.max(0, Math.floor(start * sampleRate));
  const endIndex = Math.min(buffer.length, Math.ceil((start + length) * sampleRate));
  for (let index = startIndex; index < endIndex; index += 1) {
    const time = index / sampleRate - start;
    const phase = Math.PI * 2 * frequency * time;
    const tone = wave === 'triangle'
      ? 2 * Math.abs(2 * ((frequency * time) % 1) - 1) - 1
      : Math.sin(phase) + 0.18 * Math.sin(phase * 2.01);
    const wobble = 1 + Math.sin((time + seed) * 2.3) * 0.012;
    buffer[index] += tone * gain * envelope(time, length) * wobble;
  }
}

function addDrum(buffer, start, length, gain, kind, random) {
  const startIndex = Math.max(0, Math.floor(start * sampleRate));
  const endIndex = Math.min(buffer.length, Math.ceil((start + length) * sampleRate));
  let previous = 0;
  for (let index = startIndex; index < endIndex; index += 1) {
    const time = index / sampleRate - start;
    const decay = Math.exp(-time * (kind === 'kick' ? 18 : kind === 'snare' ? 28 : 70));
    const white = random();
    previous = previous * 0.75 + white * 0.25;
    const value = kind === 'kick'
      ? Math.sin(Math.PI * 2 * (82 - time * 42) * time) * decay
      : kind === 'snare'
        ? (white * 0.75 + previous * 0.35) * decay
        : white * decay;
    buffer[index] += value * gain;
  }
}

function writeWav(filePath, samples) {
  const bytes = Buffer.alloc(44 + samples.length * 2);
  bytes.write('RIFF', 0);
  bytes.writeUInt32LE(36 + samples.length * 2, 4);
  bytes.write('WAVEfmt ', 8);
  bytes.writeUInt32LE(16, 16);
  bytes.writeUInt16LE(1, 20);
  bytes.writeUInt16LE(1, 22);
  bytes.writeUInt32LE(sampleRate, 24);
  bytes.writeUInt32LE(sampleRate * 2, 28);
  bytes.writeUInt16LE(2, 32);
  bytes.writeUInt16LE(16, 34);
  bytes.write('data', 36);
  bytes.writeUInt32LE(samples.length * 2, 40);
  samples.forEach((sample, index) => {
    const normalized = Math.max(-1, Math.min(1, sample));
    bytes.writeInt16LE(Math.round(normalized * 32767), 44 + index * 2);
  });
  fs.writeFileSync(filePath, bytes);
}

function renderTrack(track) {
  const buffer = new Float32Array(sampleCount);
  const random = noiseGenerator(track.seed);
  const beat = 60 / track.bpm;
  const bar = beat * 4;
  const totalBars = Math.ceil(durationSeconds / bar);

  for (let barIndex = 0; barIndex < totalBars; barIndex += 1) {
    const barStart = barIndex * bar;
    const chord = track.chords[barIndex % track.chords.length];
    chord.forEach((note, noteIndex) => {
      addNote(buffer, barStart + noteIndex * 0.025, bar * 0.92, note, 0.045, 'sine', track.seed + noteIndex);
      addNote(buffer, barStart + noteIndex * 0.025, bar * 0.92, note + 12, 0.018, 'triangle', track.seed + noteIndex);
    });
    chord.forEach((note, noteIndex) => {
      addNote(buffer, barStart + beat * (noteIndex === 1 ? 2 : 0), beat * 0.8, note + 12, 0.055, 'sine', track.seed);
    });

    for (let step = 0; step < 8; step += 1) {
      const start = barStart + step * beat / 2;
      const note = track.melody[(barIndex * 2 + step) % track.melody.length];
      if (note !== null) addNote(buffer, start, beat * 0.72, note, 0.055, 'triangle', track.seed);
    }

    addNote(buffer, barStart, bar * 0.8, chord[0] - 12, 0.08, 'sine', track.seed);
    addNote(buffer, barStart + beat * 2, bar * 0.8, chord[1] - 12, 0.06, 'sine', track.seed);
    for (let beatIndex = 0; beatIndex < 4; beatIndex += 1) {
      const start = barStart + beatIndex * beat;
      addDrum(buffer, start, 0.22, 0.14, 'kick', random);
      addDrum(buffer, start + beat / 2, 0.16, 0.045, 'hat', random);
      addDrum(buffer, start + beat / 4, 0.1, 0.03, 'hat', random);
      if (beatIndex === 1 || beatIndex === 3) addDrum(buffer, start, 0.25, 0.075, 'snare', random);
    }
  }

  for (let index = 0; index < buffer.length; index += 1) {
    const time = index / sampleRate;
    const filteredNoise = random() * 0.007;
    const ambience = track.character === 'rain'
      ? Math.sin(time * 17.1) * 0.006 + random() * 0.012
      : track.character === 'cafe'
        ? Math.sin(time * 2.8) * 0.006 + random() * 0.004
        : track.character === 'garden'
          ? Math.sin(time * 0.8) * 0.006 + random() * 0.006
          : Math.sin(time * 0.35) * 0.008 + random() * 0.003;
    const edgeFade = Math.min(1, index / (sampleRate * 0.6), (buffer.length - index) / (sampleRate * 0.6));
    buffer[index] = (buffer[index] * 0.72 + filteredNoise + ambience) * edgeFade;
  }
  return buffer;
}

fs.mkdirSync(outputDir, { recursive: true });
for (const track of tracks) {
  writeWav(path.join(outputDir, track.file), renderTrack(track));
  console.log(`created ${track.file}`);
}
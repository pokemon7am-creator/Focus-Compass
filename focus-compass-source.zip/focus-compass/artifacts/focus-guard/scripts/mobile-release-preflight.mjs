import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const appDir = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const PRODUCTION_HOST = 'flow-app.replit.app';

function readJson(name) {
  return JSON.parse(readFileSync(resolve(appDir, name), 'utf8'));
}

function pluginOptions(plugins, name) {
  const plugin = plugins.find((entry) => entry === name || (Array.isArray(entry) && entry[0] === name));
  assert.ok(plugin, `${name} must be configured in app.json`);
  return Array.isArray(plugin) ? (plugin[1] ?? {}) : {};
}

export function validateProductionEnvironment(env) {
  assert.equal(
    env.EXPO_PUBLIC_DOMAIN,
    PRODUCTION_HOST,
    `EXPO_PUBLIC_DOMAIN must be the host ${PRODUCTION_HOST} (without https://)`,
  );

  const clerkKey = env.EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY ?? '';
  assert.ok(
    /^pk_live_[A-Za-z0-9_+/=-]{20,}$/.test(clerkKey),
    'EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY must be a non-empty Clerk production publishable key (pk_live_...), not pk_test',
  );

  const revenueCatKey = env.EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY ?? '';
  assert.ok(
    /^goog_[A-Za-z0-9]{10,}$/.test(revenueCatKey),
    'EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY must be a valid Android RevenueCat public SDK key (goog_...), not a secret key',
  );
}

export function validateStaticConfig(appJson, easJson) {
  const expo = appJson.expo;
  assert.equal(expo.android.package, 'com.focusguard.app');
  assert.ok(Number.isInteger(expo.android.versionCode) && expo.android.versionCode > 0);
  assert.ok(
    expo.android.blockedPermissions?.includes('android.permission.RECORD_AUDIO'),
    'Android RECORD_AUDIO must remain blocked',
  );

  const camera = pluginOptions(expo.plugins, 'expo-camera');
  assert.equal(camera.recordAudioAndroid, false, 'expo-camera recordAudioAndroid must be false');
  const audio = pluginOptions(expo.plugins, 'expo-audio');
  assert.equal(audio.microphonePermission, false, 'expo-audio microphonePermission must be false');
  assert.equal(audio.recordAudioAndroid, false, 'expo-audio recordAudioAndroid must be false');

  assert.equal(easJson.cli.appVersionSource, 'remote');
  assert.equal(easJson.build.preview.distribution, 'internal');
  assert.equal(easJson.build.preview.android.buildType, 'apk');
  assert.equal(easJson.build.production.android.buildType, 'app-bundle');
  assert.equal(easJson.build.production.autoIncrement, true);
  assert.equal(easJson.build.production.env.EXPO_PUBLIC_DOMAIN, PRODUCTION_HOST);
  assert.equal(easJson.build.preview.env.EXPO_PUBLIC_DOMAIN, PRODUCTION_HOST);

  assert.ok(
    !expo.plugins.some((entry) => {
      const name = Array.isArray(entry) ? entry[0] : entry;
      return name === '@bacons/apple-targets' || String(name).includes('withSpaceAppBlocker');
    }),
    'iOS FamilyControls/apple-targets must remain disabled',
  );
}

export function resolveAndroidModules() {
  const output = execFileSync(
    'pnpm',
    ['exec', 'expo-modules-autolinking', 'resolve', '--platform', 'android', '--json'],
    { cwd: appDir, encoding: 'utf8', stdio: ['ignore', 'pipe', 'inherit'], shell: process.platform === 'win32' },
  );
  const result = JSON.parse(output);
  const module = result.modules.find((entry) => entry.packageName === 'space-app-blocker');
  assert.ok(module, 'Expo Android autolinking did not discover modules/space-app-blocker');
  assert.ok(
    module.projects?.some((project) =>
      project.modules?.some(
        (entry) => entry.classifier === 'com.focusguard.appblocker.SpaceAppBlockerModule',
      ),
    ),
    'Expo Android autolinking did not resolve SpaceAppBlockerModule',
  );
}

function main() {
  const args = new Set(process.argv.slice(2));
  if (args.has('--config')) validateStaticConfig(readJson('app.json'), readJson('eas.json'));
  if (args.has('--autolink')) resolveAndroidModules();

  const easProfile = process.env.EAS_BUILD_PROFILE;
  const production = args.has('--production') || (
    args.has('--eas') && easProfile === 'production' && process.env.EAS_BUILD_PLATFORM !== 'ios'
  );
  if (production) validateProductionEnvironment(process.env);

  console.log(
    `Mobile release preflight passed${production ? ' for production' : ''}` +
      `${args.has('--autolink') ? ' (Android local module resolved)' : ''}.`,
  );
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    main();
  } catch (error) {
    console.error(`Mobile release preflight failed: ${error.message}`);
    process.exitCode = 1;
  }
}
import assert from 'node:assert/strict';
import test from 'node:test';
import {
  validateProductionEnvironment,
  validateStaticConfig,
} from './mobile-release-preflight.mjs';
import { readFileSync } from 'node:fs';

const readJson = (name) => JSON.parse(readFileSync(new URL(`../${name}`, import.meta.url), 'utf8'));

test('static Android release configuration is safe', () => {
  validateStaticConfig(readJson('app.json'), readJson('eas.json'));
});

test('production rejects missing or development client keys', () => {
  assert.throws(
    () =>
      validateProductionEnvironment({
        EXPO_PUBLIC_DOMAIN: 'flow-app.replit.app',
        EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY: 'pk_test_development',
      }),
    /production publishable key/,
  );
  assert.throws(
    () =>
      validateProductionEnvironment({
        EXPO_PUBLIC_DOMAIN: 'flow-app.replit.app',
        EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY: 'pk_live_dGVzdC5jbGVyay5hY2NvdW50cy5kZXYk',
        EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY: 'appl_wrong_platform',
      }),
    /Android RevenueCat public SDK key/,
  );
});

test('production accepts public Android client configuration', () => {
  validateProductionEnvironment({
    EXPO_PUBLIC_DOMAIN: 'flow-app.replit.app',
    EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY: 'pk_live_dGVzdC5jbGVyay5hY2NvdW50cy5kZXYk',
    EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY: 'goog_examplepublickey123',
  });
});
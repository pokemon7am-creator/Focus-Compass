import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '@clerk/expo';
import * as Haptics from 'expo-haptics';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { AppState } from 'react-native';
import {
  BlockingStatus,
  getBlockingStatus,
  pickApps,
  openBlockingSettings,
  requestBlockingPermission,
  startBlocking,
  stopBlocking,
} from '@/services/appBlocking';
import { practiceDirtyKey } from '@/services/practiceStorage';
import {
  appendSessionIfMissing,
  getBoundedElapsedSeconds,
  getCompletionTimestamp,
  getRecordedMinutes,
  getRemainingSeconds,
  getResumeDeadline,
} from '@/context/focusTimer';

export type GuardedApp = {
  id: string;
  name: string;
  category: string;
  active: boolean;
};

export type SessionReflection = {
  feeling: 'clear' | 'okay' | 'scattered';
  note?: string;
};

export type SessionRecord = {
  id: string;
  /** The time this timer was recorded as completed, used for local-day totals. */
  completedAt: string;
  /** Whole minutes recorded for this timer; this is not an attention estimate. */
  durationMinutes: number;
  reflection?: SessionReflection;
};

export type FrictionKind = 'physical' | 'math';

export type FrictionCheck = {
  required: boolean;
  selected: FrictionKind | null;
  completed: boolean;
};

export type FocusSyncSnapshot = {
  apps: GuardedApp[];
  sessions: SessionRecord[];
  overrideEvents: string[];
  pendingReflectionId: string | null;
  stasisTokens: number;
  protectedDateKeys: string[];
};

type FocusState = {
  apps: GuardedApp[];
  sessionSeconds: number;
  remainingSeconds: number;
  isRunning: boolean;
  hasActiveSession: boolean;
  completedSessions: number;
  sessionsThisWeek: number;
  streakDays: number;
  minutesFocused: number;
  minutesFocusedThisMonth: number;
  minutesFocusedThisWeek: number;
  overridesToday: number;
  weeklyMinutes: { dateKey: string; day: string; date: string; minutes: number }[];
  reflectionSummary: { clear: number; okay: number; scattered: number };
  latestReflectionNote: string | null;
  pendingReflectionId: string | null;
  stasisTokens: number;
  latestProtectedDate: string | null;
  todaySessions: SessionRecord[];
  hydrated: boolean;
  blockingStatus: BlockingStatus;
  startSession: (minutes: number) => void;
  toggleSession: () => void;
  endSession: () => string | null;
  saveReflection: (reflection: SessionReflection) => boolean;
  skipReflection: () => void;
  grantStasisTokens: (amount: number) => void;
  toggleApp: (id: string) => void;
  chooseAppsFromDevice: () => Promise<'permission-denied' | 'unavailable' | 'cancelled' | 'updated'>;
  recordOverride: () => void;
  frictionCheck: FrictionCheck;
  beginFrictionCheck: () => void;
  selectFrictionPath: (kind: FrictionKind) => void;
  completeFrictionPath: (kind: FrictionKind) => void;
  clearFrictionCheck: () => void;
  setupDeviceBlocking: () => Promise<boolean>;
  syncSnapshot: FocusSyncSnapshot;
  applySyncedSnapshot: (snapshot: FocusSyncSnapshot) => void;
  dailyGoalMinutes: number;
  setDailyGoalMinutes: (minutes: number) => void;
  minutesFocusedToday: number;
};

type PersistedState = {
  apps: GuardedApp[];
  sessions: SessionRecord[];
  overrideEvents: string[];
  sessionSeconds?: number;
  elapsedSeconds?: number;
  remainingSeconds?: number;
  isRunning?: boolean;
  hasActiveSession?: boolean;
  targetEndAt?: number | null;
  activeSessionId?: string | null;
  pendingReflectionId?: string | null;
  stasisTokens?: number;
  protectedDateKeys?: string[];
  dailyGoalMinutes?: number;
};

const LEGACY_STORAGE_KEY = 'focus-guard-state-v2';
const MIGRATION_OWNER_KEY = 'focus-guard-state-v2-migration-owner';

const defaultApps: GuardedApp[] = [];
const legacyPlaceholderAppIds = ['instagram', 'tiktok', 'youtube', 'reddit', 'shopping'];
const defaultFrictionCheck: FrictionCheck = {
  required: false,
  selected: null,
  completed: false,
};

function removeLegacyPlaceholderList(apps: GuardedApp[]) {
  const ids = apps.map((app) => app.id).sort();
  return ids.length === legacyPlaceholderAppIds.length &&
    ids.every((id, index) => id === [...legacyPlaceholderAppIds].sort()[index])
    ? []
    : apps;
}

export const defaultFocusSyncSnapshot: FocusSyncSnapshot = {
  apps: defaultApps,
  sessions: [],
  overrideEvents: [],
  pendingReflectionId: null,
  stasisTokens: 0,
  protectedDateKeys: [],
};

const FocusContext = createContext<FocusState | null>(null);

function localDateKey(date: Date) {
  return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`;
}

function localMonthKey(date: Date) {
  return `${date.getFullYear()}-${date.getMonth() + 1}`;
}

function createSessionId() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function getWeekDays() {
  const today = new Date();
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(today);
    date.setDate(today.getDate() - (6 - index));
    return date;
  });
}

function getStreakCandidate(sessions: SessionRecord[], protectedDateKeys: string[]) {
  const completedDays = new Set(sessions.map((session) => localDateKey(new Date(session.completedAt))));
  const protectedDays = new Set(protectedDateKeys);
  const today = new Date();
  const todayKey = localDateKey(today);
  if (completedDays.has(todayKey) || protectedDays.has(todayKey)) return null;

  const previousDay = new Date(today);
  previousDay.setDate(previousDay.getDate() - 1);
  const previousDayKey = localDateKey(previousDay);
  return completedDays.has(previousDayKey) || protectedDays.has(previousDayKey) ? todayKey : null;
}

function calculateStreak(sessions: SessionRecord[], protectedDateKeys: string[]) {
  const completedDays = new Set(sessions.map((session) => localDateKey(new Date(session.completedAt))));
  const protectedDays = new Set(protectedDateKeys);
  const cursor = new Date();
  if (!completedDays.has(localDateKey(cursor)) && !protectedDays.has(localDateKey(cursor))) {
    cursor.setDate(cursor.getDate() - 1);
  }

  let streak = 0;
  while (completedDays.has(localDateKey(cursor)) || protectedDays.has(localDateKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

export function FocusProvider({ children }: { children: React.ReactNode }) {
  const { isLoaded, userId } = useAuth();
  const storageKey = userId ? `${LEGACY_STORAGE_KEY}:user:${userId}` : LEGACY_STORAGE_KEY;
  const [apps, setApps] = useState<GuardedApp[]>(defaultApps);
  const [sessionSeconds, setSessionSeconds] = useState(25 * 60);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [remainingSeconds, setRemainingSeconds] = useState(25 * 60);
  const [isRunning, setIsRunning] = useState(false);
  const [hasActiveSession, setHasActiveSession] = useState(false);
  const [targetEndAt, setTargetEndAt] = useState<number | null>(null);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [overrideEvents, setOverrideEvents] = useState<string[]>([]);
  const [frictionCheck, setFrictionCheck] = useState<FrictionCheck>(defaultFrictionCheck);
  const [pendingReflectionId, setPendingReflectionId] = useState<string | null>(null);
  const [stasisTokens, setStasisTokens] = useState(0);
  const [protectedDateKeys, setProtectedDateKeys] = useState<string[]>([]);
  const [dailyGoalMinutes, setDailyGoalMinutes] = useState(25);
  const [blockingStatus, setBlockingStatus] = useState<BlockingStatus>('unsupported');
  const [hydratedStorageKey, setHydratedStorageKey] = useState<string | null>(null);
  const hydrated = isLoaded && hydratedStorageKey === storageKey;
  const stasisProtectionDateRef = useRef<string | null>(null);
  const activeSessionIdRef = useRef<string | null>(null);
  const elapsedSecondsRef = useRef(0);
  const recordedSessionIdsRef = useRef(new Set<string>());
  const handledActiveSessionIdsRef = useRef(new Set<string>());
  const skipNextPersistenceFor = useRef<string | null>(null);
  const [calendarDay, setCalendarDay] = useState(() => localDateKey(new Date()));

  useEffect(() => {
    const refreshDay = () => setCalendarDay(localDateKey(new Date()));
    const interval = setInterval(refreshDay, 1000);
    const subscription = AppState.addEventListener('change', (nextAppState) => {
      if (nextAppState === 'active') refreshDay();
    });
    return () => {
      clearInterval(interval);
      subscription.remove();
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setHydratedStorageKey(null);
    setApps(defaultApps);
    setSessionSeconds(25 * 60);
    elapsedSecondsRef.current = 0;
    setElapsedSeconds(0);
    setRemainingSeconds(25 * 60);
    setIsRunning(false);
    setHasActiveSession(false);
    setTargetEndAt(null);
    setActiveSessionId(null);
    activeSessionIdRef.current = null;
    setSessions([]);
    recordedSessionIdsRef.current.clear();
    handledActiveSessionIdsRef.current.clear();
    setOverrideEvents([]);
    setPendingReflectionId(null);
    setStasisTokens(0);
    setProtectedDateKeys([]);
    setDailyGoalMinutes(25);
    skipNextPersistenceFor.current = null;

    if (!isLoaded) {
      return () => {
        cancelled = true;
      };
    }

    const hydrate = async () => {
      let restoredBlockingAppIds: string[] = [];
      let restoredBlockingSeconds = 0;
      let raw = await AsyncStorage.getItem(storageKey);
      if (userId) {
        const [legacy, migrationOwner] = await Promise.all([
          AsyncStorage.getItem(LEGACY_STORAGE_KEY),
          AsyncStorage.getItem(MIGRATION_OWNER_KEY),
        ]);
        if (legacy && !migrationOwner) {
          if (raw) {
            await AsyncStorage.setItem(MIGRATION_OWNER_KEY, userId);
          } else {
            await AsyncStorage.multiSet([
              [storageKey, legacy],
              [MIGRATION_OWNER_KEY, userId],
              [practiceDirtyKey(userId), '1'],
            ]);
            raw = legacy;
          }
          await AsyncStorage.removeItem(LEGACY_STORAGE_KEY);
        }
      }

      if (cancelled) return;
      if (raw) {
        if (!raw) return;
        const saved = JSON.parse(raw) as Partial<PersistedState>;
        const restoredApps = saved.apps ? removeLegacyPlaceholderList(saved.apps) : defaultApps;
        setApps(restoredApps);
        if (saved.sessions) {
          saved.sessions.forEach((session) => recordedSessionIdsRef.current.add(session.id));
          setSessions(saved.sessions);
        }
        if (saved.overrideEvents) setOverrideEvents(saved.overrideEvents);
        const restoredSessionSeconds =
          typeof saved.sessionSeconds === 'number' && Number.isFinite(saved.sessionSeconds)
            ? Math.max(1, saved.sessionSeconds)
            : 25 * 60;
        const restoredRemainingSeconds =
          typeof saved.remainingSeconds === 'number' && Number.isFinite(saved.remainingSeconds)
            ? Math.max(0, saved.remainingSeconds)
            : restoredSessionSeconds;
        const restoredTargetEndAt =
          typeof saved.targetEndAt === 'number' && Number.isFinite(saved.targetEndAt)
            ? saved.targetEndAt
            : null;
        const restoredIsRunning = saved.isRunning === true && restoredTargetEndAt !== null;
        const restoredHasActiveSession = saved.hasActiveSession === true;
        const restoredElapsedSeconds =
          typeof saved.elapsedSeconds === 'number' && Number.isFinite(saved.elapsedSeconds)
            ? Math.min(restoredSessionSeconds, Math.max(0, saved.elapsedSeconds))
            : restoredIsRunning && restoredTargetEndAt !== null
              ? getBoundedElapsedSeconds(restoredSessionSeconds, restoredTargetEndAt, Date.now())
              : Math.min(
                  restoredSessionSeconds,
                  Math.max(0, restoredSessionSeconds - restoredRemainingSeconds),
                );

        elapsedSecondsRef.current = restoredElapsedSeconds;
        setSessionSeconds(restoredSessionSeconds);
        setElapsedSeconds(restoredElapsedSeconds);
        setRemainingSeconds(
          restoredIsRunning && restoredTargetEndAt !== null
            ? getRemainingSeconds(restoredSessionSeconds, restoredElapsedSeconds)
            : restoredRemainingSeconds,
        );
        setIsRunning(restoredIsRunning);
        setHasActiveSession(restoredHasActiveSession);
        setTargetEndAt(restoredTargetEndAt);
        if (
          restoredIsRunning &&
          restoredHasActiveSession &&
          restoredTargetEndAt !== null &&
          restoredTargetEndAt > Date.now()
        ) {
          restoredBlockingAppIds = restoredApps
            .filter((app) => app.active)
            .map((app) => app.id);
          restoredBlockingSeconds = (restoredTargetEndAt - Date.now()) / 1000;
        }
        if (restoredHasActiveSession) {
          const restoredId =
            typeof saved.activeSessionId === 'string' && saved.activeSessionId.length > 0
              ? saved.activeSessionId
              : createSessionId();
          activeSessionIdRef.current = restoredId;
          setActiveSessionId(restoredId);
        }
        if (
          typeof saved.pendingReflectionId === 'string' &&
          saved.sessions?.some((session) => session.id === saved.pendingReflectionId)
        ) {
          setPendingReflectionId(saved.pendingReflectionId);
        }
        if (typeof saved.stasisTokens === 'number') setStasisTokens(Math.max(0, saved.stasisTokens));
        if (Array.isArray(saved.protectedDateKeys)) setProtectedDateKeys(saved.protectedDateKeys);
        if (typeof saved.dailyGoalMinutes === 'number' && Number.isFinite(saved.dailyGoalMinutes)) {
          setDailyGoalMinutes(Math.max(1, saved.dailyGoalMinutes));
        }
      }
      if (!cancelled) {
        if (restoredBlockingAppIds.length > 0 && restoredBlockingSeconds > 0) {
          const started = await startBlocking(restoredBlockingAppIds, restoredBlockingSeconds);
          if (cancelled) return;
          setBlockingStatus(started ? 'active' : await getBlockingStatus());
        } else {
          await stopBlocking();
          if (cancelled) return;
          setBlockingStatus(await getBlockingStatus());
        }
        if (cancelled) return;
        skipNextPersistenceFor.current = storageKey;
        setHydratedStorageKey(storageKey);
      }
    };

    hydrate().catch(async () => {
      await stopBlocking();
      const status = await getBlockingStatus();
      if (!cancelled) {
        setBlockingStatus(status);
        skipNextPersistenceFor.current = storageKey;
        setHydratedStorageKey(storageKey);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [isLoaded, storageKey, userId]);

  useEffect(() => {
    sessions.forEach((session) => recordedSessionIdsRef.current.add(session.id));
  }, [sessions]);

  useEffect(() => {
    if (!hydrated) return;
    if (skipNextPersistenceFor.current === storageKey) {
      skipNextPersistenceFor.current = null;
      return;
    }
    const state: PersistedState = {
      apps,
      sessions,
      overrideEvents,
      sessionSeconds,
      elapsedSeconds,
      remainingSeconds,
      isRunning,
      hasActiveSession,
      targetEndAt,
      activeSessionId,
      pendingReflectionId,
      stasisTokens,
      protectedDateKeys,
      dailyGoalMinutes,
    };
    const writes: [string, string][] = [[storageKey, JSON.stringify(state)]];
    if (userId) writes.push([practiceDirtyKey(userId), '1']);
    AsyncStorage.multiSet(writes).catch(() => undefined);
  }, [
    apps,
    sessions,
    overrideEvents,
    sessionSeconds,
    elapsedSeconds,
    remainingSeconds,
    isRunning,
    hasActiveSession,
    targetEndAt,
    activeSessionId,
    pendingReflectionId,
    stasisTokens,
    protectedDateKeys,
    dailyGoalMinutes,
    hydrated,
    storageKey,
    userId,
  ]);

  useEffect(() => {
    if (!hydrated || stasisTokens <= 0) return;
    const calculationDate = localDateKey(new Date());
    if (stasisProtectionDateRef.current === calculationDate) return;
    const candidate = getStreakCandidate(sessions, protectedDateKeys);
    if (!candidate) return;

    stasisProtectionDateRef.current = calculationDate;
    setStasisTokens((tokens) => (tokens > 0 ? tokens - 1 : tokens));
    setProtectedDateKeys((keys) => (keys.includes(candidate) ? keys : [...keys, candidate]));
  }, [hydrated, protectedDateKeys, sessions, stasisTokens]);

  const recordSession = useCallback((id: string, elapsed: number, completedAt: number) => {
    const durationMinutes = getRecordedMinutes(elapsed);
    if (durationMinutes < 1 || recordedSessionIdsRef.current.has(id)) return null;

    recordedSessionIdsRef.current.add(id);
    setSessions((items) =>
      appendSessionIfMissing(items, {
        id,
        completedAt: new Date(completedAt).toISOString(),
        durationMinutes,
      }),
    );
    setPendingReflectionId(id);
    return id;
  }, []);

  const finishActiveSession = useCallback(
    (completedAt: number, elapsedOverride?: number, notifySuccess = false) => {
      const currentActiveSessionId = activeSessionIdRef.current ?? activeSessionId;
      if (
        !currentActiveSessionId ||
        handledActiveSessionIdsRef.current.has(currentActiveSessionId)
      ) {
        return null;
      }

      handledActiveSessionIdsRef.current.add(currentActiveSessionId);
      const elapsed =
        elapsedOverride ??
        (targetEndAt !== null
          ? getBoundedElapsedSeconds(sessionSeconds, targetEndAt, completedAt)
          : elapsedSecondsRef.current);
      const sessionId = recordSession(currentActiveSessionId, elapsed, completedAt);
      setIsRunning(false);
      setHasActiveSession(false);
      setTargetEndAt(null);
      activeSessionIdRef.current = null;
      setActiveSessionId(null);
      elapsedSecondsRef.current = 0;
      setElapsedSeconds(0);
      setRemainingSeconds(elapsed >= sessionSeconds ? 0 : sessionSeconds);
      void stopBlocking();
      void getBlockingStatus().then(setBlockingStatus);
      if (notifySuccess) Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return sessionId;
    },
    [activeSessionId, recordSession, sessionSeconds, targetEndAt],
  );

  useEffect(() => {
    if (!hydrated || !isRunning || targetEndAt === null) return;
    const tick = () => {
      const now = Date.now();
      const elapsed = getBoundedElapsedSeconds(sessionSeconds, targetEndAt, now);
      const next = getRemainingSeconds(sessionSeconds, elapsed);
      elapsedSecondsRef.current = elapsed;
      setElapsedSeconds(elapsed);
      setRemainingSeconds(next);
      if (now < targetEndAt) return;

      clearInterval(timer);
      finishActiveSession(targetEndAt, sessionSeconds, true);
    };
    const timer = setInterval(tick, 250);
    tick();
    return () => clearInterval(timer);
  }, [finishActiveSession, hydrated, isRunning, sessionSeconds, targetEndAt]);

  const startSession = useCallback((minutes: number) => {
    if (hasActiveSession || activeSessionIdRef.current) return;
    const seconds = minutes * 60;
    const id = createSessionId();
    setSessionSeconds(seconds);
    elapsedSecondsRef.current = 0;
    setElapsedSeconds(0);
    setRemainingSeconds(seconds);
    setIsRunning(true);
    setHasActiveSession(true);
    activeSessionIdRef.current = id;
    setActiveSessionId(id);
    setTargetEndAt(Date.now() + seconds * 1000);
    void startBlocking(
      apps.filter((app) => app.active).map((app) => app.id),
      seconds,
    ).then((started) => {
      if (started) setBlockingStatus('active');
    });
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
  }, [apps, hasActiveSession]);

  const toggleSession = useCallback(() => {
    if (isRunning && targetEndAt !== null) {
      const now = Date.now();
      if (now >= targetEndAt) {
        finishActiveSession(targetEndAt, sessionSeconds, true);
      } else {
        const elapsed = getBoundedElapsedSeconds(sessionSeconds, targetEndAt, now);
        elapsedSecondsRef.current = elapsed;
        setElapsedSeconds(elapsed);
        setRemainingSeconds(getRemainingSeconds(sessionSeconds, elapsed));
        setTargetEndAt(null);
        setIsRunning(false);
        void stopBlocking();
        void getBlockingStatus().then(setBlockingStatus);
      }
    } else if (hasActiveSession && getRemainingSeconds(sessionSeconds, elapsedSeconds) > 0) {
      const nextDeadline = getResumeDeadline(Date.now(), sessionSeconds, elapsedSeconds);
      setTargetEndAt(nextDeadline);
      setIsRunning(true);
      void startBlocking(
        apps.filter((app) => app.active).map((app) => app.id),
        getRemainingSeconds(sessionSeconds, elapsedSeconds),
      ).then((started) => {
        if (started) setBlockingStatus('active');
      });
    }
    Haptics.selectionAsync();
  }, [
    apps,
    elapsedSeconds,
    finishActiveSession,
    hasActiveSession,
    isRunning,
    remainingSeconds,
    sessionSeconds,
    targetEndAt,
  ]);

  const endSession = useCallback(() => {
    const currentActiveSessionId = activeSessionIdRef.current ?? activeSessionId;
    if (!hasActiveSession || !currentActiveSessionId) return null;

    const now = Date.now();
    const isExpired = isRunning && targetEndAt !== null && now >= targetEndAt;
    const elapsed = isRunning && targetEndAt !== null
      ? getBoundedElapsedSeconds(sessionSeconds, targetEndAt, now)
      : elapsedSeconds;
    const completionAt = isExpired && targetEndAt !== null
      ? getCompletionTimestamp(targetEndAt, now)
      : now;
    const sessionId = finishActiveSession(completionAt, elapsed);
    Haptics.selectionAsync();
    return sessionId;
  }, [
    activeSessionId,
    elapsedSeconds,
    finishActiveSession,
    hasActiveSession,
    isRunning,
    sessionSeconds,
    targetEndAt,
  ]);

  const saveReflection = useCallback((reflection: SessionReflection) => {
    if (!pendingReflectionId) return false;
    setSessions((items) =>
      items.map((session) => (session.id === pendingReflectionId ? { ...session, reflection } : session)),
    );
    setPendingReflectionId(null);
    return true;
  }, [pendingReflectionId]);

  const skipReflection = useCallback(() => {
    setPendingReflectionId(null);
  }, []);

  const grantStasisTokens = useCallback((amount: number) => {
    if (amount > 0) setStasisTokens((tokens) => tokens + amount);
  }, []);

  const toggleApp = useCallback((id: string) => {
    setApps((items) => {
      const nextItems = items.map((item) => (item.id === id ? { ...item, active: !item.active } : item));
      if (isRunning && targetEndAt !== null) {
        const seconds = getRemainingSeconds(
          sessionSeconds,
          getBoundedElapsedSeconds(sessionSeconds, targetEndAt, Date.now()),
        );
        void startBlocking(
          nextItems.filter((app) => app.active).map((app) => app.id),
          seconds,
        );
      }
      return nextItems;
    });
    Haptics.selectionAsync();
  }, [isRunning, sessionSeconds, targetEndAt]);

  const chooseAppsFromDevice = useCallback(async () => {
    const currentStatus = await getBlockingStatus();
    setBlockingStatus(currentStatus);
    if (currentStatus === 'unsupported') return 'unavailable' as const;

    if (currentStatus === 'needs-permission') {
      const permissionGranted = await requestBlockingPermission();
      const nextStatus = await getBlockingStatus();
      setBlockingStatus(nextStatus);
      if (!permissionGranted || nextStatus === 'needs-permission') {
        return 'permission-denied' as const;
      }
    }

    const selected = await pickApps();
    if (selected === null) return 'unavailable' as const;
    if (selected.length === 0) return 'cancelled' as const;

    const nextApps: GuardedApp[] = selected.map((app) => ({
      id: app.id,
      name: app.name,
      category: app.category ?? 'App',
      active: true,
    }));
    setApps(nextApps);

    if (isRunning && targetEndAt !== null) {
      const seconds = getRemainingSeconds(
        sessionSeconds,
        getBoundedElapsedSeconds(sessionSeconds, targetEndAt, Date.now()),
      );
      void startBlocking(nextApps.map((app) => app.id), seconds);
    }

    return 'updated' as const;
  }, [isRunning, sessionSeconds, targetEndAt]);

  const setupDeviceBlocking = useCallback(async () => {
    const openedSettings = await openBlockingSettings();
    const nextStatus = await getBlockingStatus();
    setBlockingStatus(nextStatus);
    return openedSettings && nextStatus !== 'unsupported';
  }, []);

  const recordOverride = useCallback(() => {
    setOverrideEvents((items) => [...items, new Date().toISOString()]);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
  }, []);

  const beginFrictionCheck = useCallback(() => {
    setFrictionCheck((current) => current.required ? current : {
      required: true,
      selected: null,
      completed: false,
    });
  }, []);

  const selectFrictionPath = useCallback((kind: FrictionKind) => {
    setFrictionCheck({
      required: true,
      selected: kind,
      completed: false,
    });
  }, []);

  const completeFrictionPath = useCallback((kind: FrictionKind) => {
    setFrictionCheck((current) => (
      current.required && current.selected === kind
        ? { ...current, completed: true }
        : current
    ));
  }, []);

  const clearFrictionCheck = useCallback(() => {
    setFrictionCheck(defaultFrictionCheck);
  }, []);

  const applySyncedSnapshot = useCallback((snapshot: FocusSyncSnapshot) => {
    setApps(removeLegacyPlaceholderList(snapshot.apps));
    setSessions((current) => {
      const incoming = new Map(snapshot.sessions.map((session) => [session.id, session]));
      for (const session of current) {
        if (!incoming.has(session.id)) incoming.set(session.id, session);
      }
      return [...incoming.values()];
    });
    setOverrideEvents(snapshot.overrideEvents);
    setPendingReflectionId(snapshot.pendingReflectionId);
    setStasisTokens(Math.max(0, snapshot.stasisTokens));
    setProtectedDateKeys(snapshot.protectedDateKeys);
  }, []);

  const value = useMemo(() => {
    const todayKey = calendarDay;
    const weekDays = getWeekDays();
    const weekKeys = new Set(weekDays.map(localDateKey));
    const weeklyMinutes = weekDays.map((date) => ({
      dateKey: localDateKey(date),
      day: date.toLocaleDateString(undefined, { weekday: 'short' }),
      date: String(date.getDate()),
      minutes: sessions
        .filter((session) => localDateKey(new Date(session.completedAt)) === localDateKey(date))
        .reduce((sum, session) => sum + session.durationMinutes, 0),
    }));

    const sessionsThisWeek = sessions.filter((session) =>
      weekKeys.has(localDateKey(new Date(session.completedAt))),
    );
    const reflectedSessionsThisWeek = sessionsThisWeek.filter((session) => session.reflection);
    const reflectionSummary = reflectedSessionsThisWeek.reduce(
      (summary, session) => {
        if (session.reflection) summary[session.reflection.feeling] += 1;
        return summary;
      },
      { clear: 0, okay: 0, scattered: 0 },
    );
    const latestReflectionNote =
      [...sessions]
        .reverse()
        .find((session) => session.reflection?.note)
        ?.reflection?.note ?? null;

    const sessionsToday = sessions.filter(
      (session) => localDateKey(new Date(session.completedAt)) === todayKey
    );
    const minutesFocusedToday = sessionsToday.reduce((sum, session) => sum + session.durationMinutes, 0);

    return {
      apps,
      sessionSeconds,
      remainingSeconds,
      isRunning,
      hasActiveSession,
      completedSessions: sessions.filter(
        (session) => localDateKey(new Date(session.completedAt)) === todayKey,
      ).length,
      sessionsThisWeek: sessionsThisWeek.length,
      streakDays: calculateStreak(sessions, protectedDateKeys),
      minutesFocusedToday,
      todaySessions: sessionsToday,
      minutesFocused: sessions.reduce((sum, session) => sum + session.durationMinutes, 0),
      minutesFocusedThisMonth: sessions
        .filter((session) => localMonthKey(new Date(session.completedAt)) === localMonthKey(new Date()))
        .reduce((sum, session) => sum + session.durationMinutes, 0),
      minutesFocusedThisWeek: sessionsThisWeek.reduce((sum, session) => sum + session.durationMinutes, 0),
      overridesToday: overrideEvents.filter((event) => localDateKey(new Date(event)) === todayKey).length,
      weeklyMinutes,
      reflectionSummary,
      latestReflectionNote,
      pendingReflectionId,
      stasisTokens,
      latestProtectedDate: protectedDateKeys.length
        ? [...protectedDateKeys].sort((a, b) => {
            const aParts = a.split('-').map(Number);
            const bParts = b.split('-').map(Number);
            return new Date(aParts[0], aParts[1] - 1, aParts[2]).getTime() -
              new Date(bParts[0], bParts[1] - 1, bParts[2]).getTime();
          }).at(-1) ?? null
        : null,
      hydrated,
      blockingStatus,
      startSession,
      toggleSession,
      endSession,
      saveReflection,
      skipReflection,
      grantStasisTokens,
      toggleApp,
      chooseAppsFromDevice,
      recordOverride,
      frictionCheck,
      beginFrictionCheck,
      selectFrictionPath,
      completeFrictionPath,
      clearFrictionCheck,
      setupDeviceBlocking,
      syncSnapshot: {
        apps,
        sessions,
        overrideEvents,
        pendingReflectionId,
        stasisTokens,
        protectedDateKeys,
      },
      applySyncedSnapshot,
      dailyGoalMinutes,
      setDailyGoalMinutes,
    };
  }, [
    calendarDay,
    apps,
    sessionSeconds,
    remainingSeconds,
    isRunning,
    hasActiveSession,
    sessions,
    overrideEvents,
    pendingReflectionId,
    stasisTokens,
    protectedDateKeys,
    startSession,
    toggleSession,
    endSession,
    grantStasisTokens,
    saveReflection,
    skipReflection,
    toggleApp,
    chooseAppsFromDevice,
    recordOverride,
    frictionCheck,
    beginFrictionCheck,
    selectFrictionPath,
    completeFrictionPath,
    clearFrictionCheck,
    setupDeviceBlocking,
    blockingStatus,
    applySyncedSnapshot,
    dailyGoalMinutes,
  ]);

  return <FocusContext.Provider value={value}>{children}</FocusContext.Provider>;
}

export function useFocus() {
  const value = useContext(FocusContext);
  if (!value) throw new Error('useFocus must be used inside FocusProvider');
  return value;
}
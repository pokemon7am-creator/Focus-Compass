import type { CustomerInfo } from 'react-native-purchases';

export const PREMIUM_ENTITLEMENT_ID = 'premium';

export type RevenueCatActionResult =
  | { status: 'success' }
  | { status: 'cancelled' }
  | { status: 'not_found' }
  | { status: 'error'; message: string };

type PurchasesErrorLike = {
  code?: string | number;
  message?: string;
  userCancelled?: boolean;
};

export function hasPremiumEntitlement(info: CustomerInfo) {
  return Boolean(info.entitlements.active[PREMIUM_ENTITLEMENT_ID]);
}

export function isPurchaseCancellation(reason: unknown) {
  const candidate = reason as PurchasesErrorLike | null;
  return Boolean(
    candidate?.userCancelled ||
      candidate?.code === '1' ||
      candidate?.code === 1 ||
      candidate?.code === 'PURCHASE_CANCELLED_ERROR',
  );
}

export function purchaseErrorMessage(reason: unknown, fallback: string) {
  if (reason instanceof Error && reason.message.trim()) return reason.message;
  const message = (reason as PurchasesErrorLike | null)?.message;
  return typeof message === 'string' && message.trim() ? message : fallback;
}
import { useAuth } from '@clerk/expo';
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import Purchases, { CustomerInfo, PurchasesOffering, PurchasesPackage } from 'react-native-purchases';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  hasPremiumEntitlement,
  isPurchaseCancellation,
  purchaseErrorMessage,
  RevenueCatActionResult,
} from './revenueCatHelpers';

type StoreMode = 'preview' | 'production' | 'unavailable';
type RevenueCatOperation = 'initializing' | 'refreshing' | 'purchasing' | 'restoring' | 'idle';

type RevenueCatState = {
  configured: boolean;
  ready: boolean;
  loading: boolean;
  isPremium: boolean;
  offering: PurchasesOffering | null;
  error: string | null;
  operation: RevenueCatOperation;
  storeMode: StoreMode;
  purchase: (item: PurchasesPackage) => Promise<RevenueCatActionResult>;
  restore: () => Promise<RevenueCatActionResult>;
  reload: () => Promise<void>;
};

const RevenueCatContext = createContext<RevenueCatState | null>(null);

function getConfiguration() {
  const preview = __DEV__ || Platform.OS === 'web' || Constants.executionEnvironment === 'storeClient';
  const apiKey = preview
    ? process.env.EXPO_PUBLIC_REVENUECAT_TEST_API_KEY
    : Platform.OS === 'ios'
      ? process.env.EXPO_PUBLIC_REVENUECAT_IOS_API_KEY
      : Platform.OS === 'android'
        ? process.env.EXPO_PUBLIC_REVENUECAT_ANDROID_API_KEY
        : undefined;

  return {
    apiKey,
    storeMode: apiKey ? (preview ? 'preview' : 'production') : 'unavailable',
  } as const;
}

export function RevenueCatProvider({ children }: { children: React.ReactNode }) {
  const { isLoaded: authLoaded, userId } = useAuth();
  const configuration = useMemo(getConfiguration, []);
  const [configured, setConfigured] = useState(false);
  const [ready, setReady] = useState(false);
  const [operation, setOperation] = useState<RevenueCatOperation>('initializing');
  const [isPremium, setIsPremium] = useState(false);
  const [offering, setOffering] = useState<PurchasesOffering | null>(null);
  const [error, setError] = useState<string | null>(null);
  const mountedRef = useRef(true);
  const configuredRef = useRef(false);
  const readyRef = useRef(false);
  const activeAppUserIdRef = useRef<string | null>(null);
  const generationRef = useRef(0);
  const queueRef = useRef<Promise<unknown>>(Promise.resolve());
  const actionLockedRef = useRef(false);
  const premiumRef = useRef(false);

  useEffect(() => {
    mountedRef.current = true;
    const listener = (info: CustomerInfo) => {
      const generation = generationRef.current;
      if (!readyRef.current) return;
      void Purchases.getAppUserID().then((appUserId) => {
        if (
          mountedRef.current &&
          readyRef.current &&
          generation === generationRef.current &&
          appUserId === activeAppUserIdRef.current
        ) {
          const active = hasPremiumEntitlement(info);
          premiumRef.current = active;
          setIsPremium(active);
        }
      }).catch(() => undefined);
    };
    Purchases.addCustomerInfoUpdateListener(listener);
    return () => {
      mountedRef.current = false;
      Purchases.removeCustomerInfoUpdateListener(listener);
    };
  }, []);

  const loadCurrentCustomer = useCallback(async (generation: number) => {
    const [info, offerings, appUserId] = await Promise.all([
      Purchases.getCustomerInfo(),
      Purchases.getOfferings(),
      Purchases.getAppUserID(),
    ]);
    if (!mountedRef.current || generation !== generationRef.current) return;

    activeAppUserIdRef.current = appUserId;
    readyRef.current = true;
    const active = hasPremiumEntitlement(info);
    premiumRef.current = active;
    setIsPremium(active);
    setOffering(offerings.current);
    setReady(true);
    setError(
      offerings.current?.availablePackages.length
        ? null
        : 'No membership plans are available from the store right now.',
    );
    setOperation('idle');
  }, []);

  useEffect(() => {
    if (!authLoaded) return;

    const generation = ++generationRef.current;
    readyRef.current = false;
    premiumRef.current = false;
    activeAppUserIdRef.current = null;
    setReady(false);
    setIsPremium(false);
    setOffering(null);
    setError(null);
    setOperation('initializing');

    const task = queueRef.current.catch(() => undefined).then(async () => {
      if (!mountedRef.current || generation !== generationRef.current) return;
      if (!configuration.apiKey) {
        throw new Error('Membership purchases are not available in this build.');
      }

      if (!configuredRef.current) {
        Purchases.configure({
          apiKey: configuration.apiKey,
          ...(userId ? { appUserID: userId } : {}),
        });
        configuredRef.current = true;
        if (mountedRef.current) setConfigured(true);
      } else if (userId) {
        const currentId = await Purchases.getAppUserID();
        if (currentId !== userId) await Purchases.logIn(userId);
      } else if (!(await Purchases.isAnonymous())) {
        await Purchases.logOut();
      }

      await loadCurrentCustomer(generation);
    });
    queueRef.current = task;
    void task.catch((reason: unknown) => {
      if (!mountedRef.current || generation !== generationRef.current) return;
      readyRef.current = false;
      setReady(false);
      setIsPremium(false);
      setOffering(null);
      setError(purchaseErrorMessage(reason, 'Could not load membership options.'));
      setOperation('idle');
    });
  }, [authLoaded, configuration.apiKey, loadCurrentCustomer, userId]);

  const reload = useCallback(async () => {
    if (!configuredRef.current) return;
    const generation = generationRef.current;
    setError(null);
    setOperation('refreshing');
    const task = queueRef.current.catch(() => undefined).then(() => loadCurrentCustomer(generation));
    queueRef.current = task;
    try {
      await task;
    } catch (reason: unknown) {
      if (!mountedRef.current || generation !== generationRef.current) return;
      setError(purchaseErrorMessage(reason, 'Could not refresh membership options.'));
      setOperation('idle');
    }
  }, [loadCurrentCustomer]);

  const purchase = useCallback(async (item: PurchasesPackage): Promise<RevenueCatActionResult> => {
    if (!configuredRef.current || !readyRef.current || actionLockedRef.current) {
      return { status: 'error', message: 'The store is still getting ready.' } as const;
    }
    if (premiumRef.current) return { status: 'success' };
    actionLockedRef.current = true;
    const generation = generationRef.current;
    setOperation('purchasing');
    setError(null);
    const task = queueRef.current.catch(() => undefined).then(() => Purchases.purchasePackage(item));
    queueRef.current = task;
    try {
      const result = await task;
      if (!mountedRef.current || generation !== generationRef.current) {
        return { status: 'error', message: 'Your account changed before the purchase finished.' };
      }
      const active = hasPremiumEntitlement(result.customerInfo);
      premiumRef.current = active;
      setIsPremium(active);
      if (!active) {
        const message = 'The purchase finished, but Premium is not active yet. Try Restore purchases.';
        setError(message);
        return { status: 'error', message };
      }
      return { status: 'success' };
    } catch (reason: unknown) {
      if (isPurchaseCancellation(reason)) return { status: 'cancelled' };
      const message = purchaseErrorMessage(reason, 'Purchase could not be completed.');
      if (mountedRef.current && generation === generationRef.current) setError(message);
      return { status: 'error', message };
    } finally {
      actionLockedRef.current = false;
      if (mountedRef.current && generation === generationRef.current) setOperation('idle');
    }
  }, []);

  const restore = useCallback(async (): Promise<RevenueCatActionResult> => {
    if (!configuredRef.current || !readyRef.current || actionLockedRef.current) {
      return { status: 'error', message: 'The store is still getting ready.' } as const;
    }
    actionLockedRef.current = true;
    const generation = generationRef.current;
    setOperation('restoring');
    setError(null);
    const task = queueRef.current.catch(() => undefined).then(() => Purchases.restorePurchases());
    queueRef.current = task;
    try {
      const info = await task;
      if (!mountedRef.current || generation !== generationRef.current) {
        return { status: 'error', message: 'Your account changed before restore finished.' };
      }
      const active = hasPremiumEntitlement(info);
      premiumRef.current = active;
      setIsPremium(active);
      return active ? { status: 'success' } : { status: 'not_found' };
    } catch (reason: unknown) {
      const message = purchaseErrorMessage(reason, 'Restore could not be completed.');
      if (mountedRef.current && generation === generationRef.current) setError(message);
      return { status: 'error', message };
    } finally {
      actionLockedRef.current = false;
      if (mountedRef.current && generation === generationRef.current) setOperation('idle');
    }
  }, []);

  const value = useMemo(
    () => ({
      configured,
      ready,
      loading: operation !== 'idle',
      isPremium,
      offering,
      error,
      operation,
      storeMode: configuration.storeMode,
      purchase,
      restore,
      reload,
    }),
    [configured, ready, operation, isPremium, offering, error, configuration.storeMode, purchase, restore, reload],
  );

  return <RevenueCatContext.Provider value={value}>{children}</RevenueCatContext.Provider>;
}

export function useRevenueCat() {
  const value = useContext(RevenueCatContext);
  if (!value) throw new Error('useRevenueCat must be used inside RevenueCatProvider');
  return value;
}
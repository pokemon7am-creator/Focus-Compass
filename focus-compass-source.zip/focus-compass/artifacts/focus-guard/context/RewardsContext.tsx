import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '@clerk/expo';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { practiceDirtyKey } from '@/services/practiceStorage';

export type RewardCategory = 'breath' | 'roast';
export type BreathStyle = 'classic' | 'moonlight' | 'starlight' | 'sunrise' | 'aurora' | 'paperfold';
export type RoastStyle = 'classic' | 'bold' | 'dry' | 'chaos' | 'margin-notes';
export type Soundscape =
  | 'none'
  | 'rainy-library'
  | 'quiet-spacecraft'
  | 'turning-pages'
  | 'greenhouse-rain'
  | 'misty-window'
  | 'sunday-vinyl'
  | 'ocean-desk'
  | 'library-lamp';
export type CollectibleId =
  | 'paper-folded-comet'
  | 'paper-notebook-moon'
  | 'paper-origami-rocket'
  | 'paper-constellation-page';

export type Collectible = {
  id: CollectibleId;
  title: string;
  description: string;
  icon: 'star' | 'moon' | 'send' | 'file-text';
};

export const paperPlanetsCollectibles: readonly Collectible[] = [
  { id: 'paper-folded-comet', title: 'Folded Comet', description: 'A bright little orbit, creased by hand.', icon: 'star' },
  { id: 'paper-notebook-moon', title: 'Notebook Moon', description: 'A quiet moon torn from a well-used page.', icon: 'moon' },
  { id: 'paper-origami-rocket', title: 'Origami Rocket', description: 'A launch plan for the next useful thing.', icon: 'send' },
  { id: 'paper-constellation-page', title: 'Constellation Page', description: 'A map of ideas that found their way together.', icon: 'file-text' },
];

export type EquippedRewards = {
  breath: BreathStyle;
  roast: RoastStyle;
};

export type RewardsSyncSnapshot = {
  rewardClaimKeys?: string[];
  leaves: number;
  mindfulMinutes: number;
  unlockedRewards: string[];
  equipped: EquippedRewards;
  stillnessEvents: string[];
  ownedCollectibles: CollectibleId[];
  selectedCollectible: CollectibleId | null;
  soundscape: Soundscape;
};

type RewardsState = {
  storageError: string | null;
  rewardClaimKeys: string[];
  importRewardClaims: (keys: string[]) => void;
  claimLocalReward: (key: string, reward: { leaves?: number; collectibleId?: CollectibleId; rewardId?: string; category?: RewardCategory }) => boolean;
  leaves: number;
  mindfulMinutes: number;
  hydrated: boolean;
  unlockedRewards: string[];
  equipped: EquippedRewards;
  stillnessEvents: string[];
  ownedCollectibles: CollectibleId[];
  selectedCollectible: CollectibleId | null;
  soundscape: Soundscape;
  completeStillness: (minutes: number) => void;
  grantLeaves: (amount: number) => void;
  spendLeaves: (amount: number) => boolean;
  grantCollectible: (id: CollectibleId) => void;
  selectCollectible: (id: CollectibleId) => boolean;
  setSoundscape: (soundscape: Soundscape) => void;
  unlockReward: (id: string, category: RewardCategory) => void;
  unlockAndEquip: (id: string, cost: number, category: RewardCategory) => boolean;
  syncSnapshot: RewardsSyncSnapshot;
  applySyncedSnapshot: (snapshot: RewardsSyncSnapshot) => void;
};

type PersistedRewards = {
  rewardClaimKeys?: string[];
  leaves?: number;
  mindfulMinutes?: number;
  unlockedRewards?: string[];
  equipped?: Partial<EquippedRewards>;
  stillnessEvents?: string[];
  ownedCollectibles?: CollectibleId[];
  selectedCollectible?: CollectibleId | null;
  soundscape?: Soundscape;
};

const LEGACY_STORAGE_KEY = 'zen-stillness-v1';
const MIGRATION_OWNER_KEY = 'zen-stillness-v1-migration-owner';
const RewardsContext = createContext<RewardsState | null>(null);

export const defaultRewardsSyncSnapshot: RewardsSyncSnapshot = {
  rewardClaimKeys: [],
  leaves: 0,
  mindfulMinutes: 0,
  unlockedRewards: [],
  equipped: { breath: 'classic', roast: 'classic' },
  stillnessEvents: [],
  ownedCollectibles: [],
  selectedCollectible: null,
  soundscape: 'none',
};

export function RewardsProvider({ children }: { children: React.ReactNode }) {
  const { isLoaded, userId } = useAuth();
  const storageKey = userId ? `${LEGACY_STORAGE_KEY}:user:${userId}` : LEGACY_STORAGE_KEY;
  const [leaves, setLeaves] = useState(0);
  const [rewardClaimKeys, setRewardClaimKeys] = useState<string[]>([]);
  const [storageError, setStorageError] = useState<string | null>(null);
  const persistenceQueue = useRef<Promise<void>>(Promise.resolve());
  const rewardClaimKeysRef = useRef(new Set<string>());
  const [mindfulMinutes, setMindfulMinutes] = useState(0);
  const [unlockedRewards, setUnlockedRewards] = useState<string[]>([]);
  const [equipped, setEquipped] = useState<EquippedRewards>({ breath: 'classic', roast: 'classic' });
  const [stillnessEvents, setStillnessEvents] = useState<string[]>([]);
  const [ownedCollectibles, setOwnedCollectibles] = useState<CollectibleId[]>([]);
  const firstCollectibleChoice = useRef<CollectibleId | null>(null);
  const [selectedCollectible, setSelectedCollectible] = useState<CollectibleId | null>(null);
  const [soundscape, setSoundscapeState] = useState<Soundscape>('none');
  const [hydratedStorageKey, setHydratedStorageKey] = useState<string | null>(null);
  const hydrated = isLoaded && hydratedStorageKey === storageKey;
  const skipNextPersistenceFor = useRef<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setHydratedStorageKey(null);
    setLeaves(0);
    setStorageError(null);
    setRewardClaimKeys([]);
    rewardClaimKeysRef.current = new Set();
    setMindfulMinutes(0);
    setUnlockedRewards([]);
    setEquipped({ breath: 'classic', roast: 'classic' });
    setStillnessEvents([]);
    setOwnedCollectibles([]);
    firstCollectibleChoice.current = null;
    setSelectedCollectible(null);
    setSoundscapeState('none');
    skipNextPersistenceFor.current = null;

    if (!isLoaded) {
      return () => {
        cancelled = true;
      };
    }

    const hydrate = async () => {
      let raw = await AsyncStorage.getItem(storageKey);
      if (userId) {
        const [legacy, migrationOwner] = await Promise.all([
          AsyncStorage.getItem(LEGACY_STORAGE_KEY),
          AsyncStorage.getItem(MIGRATION_OWNER_KEY),
        ]);
        if (legacy && !migrationOwner) {
          if (raw) {
            await AsyncStorage.setItem(MIGRATION_OWNER_KEY, userId);
          } else {
            await AsyncStorage.multiSet([
              [storageKey, legacy],
              [MIGRATION_OWNER_KEY, userId],
              [practiceDirtyKey(userId), '1'],
            ]);
            raw = legacy;
          }
          await AsyncStorage.removeItem(LEGACY_STORAGE_KEY);
        }
      }

      if (cancelled || !raw) {
        if (!cancelled) {
          skipNextPersistenceFor.current = storageKey;
          setHydratedStorageKey(storageKey);
        }
        return;
      }
        const saved = JSON.parse(raw) as PersistedRewards;
        const savedClaims = Array.isArray(saved.rewardClaimKeys) ? saved.rewardClaimKeys.filter((key) => typeof key === 'string') : [];
        setRewardClaimKeys(savedClaims);
        rewardClaimKeysRef.current = new Set(savedClaims);
        setLeaves(saved.leaves ?? 0);
        setMindfulMinutes(saved.mindfulMinutes ?? 0);
        setUnlockedRewards(saved.unlockedRewards ?? []);
        setStillnessEvents(saved.stillnessEvents ?? []);
        setOwnedCollectibles(saved.ownedCollectibles ?? []);
        setSelectedCollectible(saved.selectedCollectible ?? null);
        setSoundscapeState(saved.soundscape ?? 'none');
        setEquipped({
          breath: saved.equipped?.breath ?? 'classic',
          roast: saved.equipped?.roast ?? 'classic',
        });
      if (!cancelled) {
        skipNextPersistenceFor.current = storageKey;
        setHydratedStorageKey(storageKey);
      }
    };

    hydrate().catch(() => {
      if (!cancelled) {
        skipNextPersistenceFor.current = storageKey;
        setHydratedStorageKey(storageKey);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [isLoaded, storageKey, userId]);

  useEffect(() => {
    if (!hydrated) return;
    if (skipNextPersistenceFor.current === storageKey) {
      skipNextPersistenceFor.current = null;
      return;
    }
    const writes: [string, string][] = [
      [storageKey, JSON.stringify({
        rewardClaimKeys,
        leaves,
        mindfulMinutes,
        unlockedRewards,
        equipped,
        stillnessEvents,
        ownedCollectibles,
        selectedCollectible,
        soundscape,
      })],
    ];
    if (userId) writes.push([practiceDirtyKey(userId), '1']);
    let cancelled = false;
    let retry: ReturnType<typeof setTimeout> | undefined;
    const persist = async () => {
      const job = persistenceQueue.current.catch(() => undefined).then(() => AsyncStorage.multiSet(writes));
      persistenceQueue.current = job;
      try {
        await job;
        if (!cancelled) setStorageError(null);
      } catch {
        if (cancelled) return;
        setStorageError('Your wallet has not saved on this device yet. Keep the app open while we retry.');
        retry = setTimeout(() => void persist(), 3000);
      }
    };
    void persist();
    return () => { cancelled = true; if (retry) clearTimeout(retry); };
  }, [rewardClaimKeys, equipped, hydrated, leaves, mindfulMinutes, unlockedRewards, stillnessEvents, ownedCollectibles, selectedCollectible, soundscape, storageKey, userId]);

  const importRewardClaims = useCallback((keys: string[]) => {
    if (!hydrated) return;
    const additions = keys.filter((key) => !rewardClaimKeysRef.current.has(key));
    if (!additions.length) return;
    for (const key of additions) rewardClaimKeysRef.current.add(key);
    setRewardClaimKeys([...rewardClaimKeysRef.current]);
  }, [hydrated]);

  const claimLocalReward = useCallback((key: string, reward: { leaves?: number; collectibleId?: CollectibleId; rewardId?: string; category?: RewardCategory }) => {
    if (!hydrated || userId || rewardClaimKeysRef.current.has(key)) return false;
    rewardClaimKeysRef.current.add(key);
    setRewardClaimKeys([...rewardClaimKeysRef.current]);
    if (reward.leaves && reward.leaves > 0) setLeaves((value) => value + reward.leaves!);
    if (reward.collectibleId) setOwnedCollectibles((items) => [...new Set([...items, reward.collectibleId!])]);
    if (reward.rewardId && reward.category) {
      setUnlockedRewards((items) => [...new Set([...items, reward.rewardId!])]);
      setEquipped((current) => ({ ...current, [reward.category!]: reward.rewardId!.replace(`${reward.category}-`, '') }));
    }
    return true;
  }, [hydrated, userId]);

  const completeStillness = useCallback((minutes: number) => {
    setLeaves((value) => value + minutes);
    setMindfulMinutes((value) => value + minutes);
    setStillnessEvents((events) => [...events, new Date().toISOString()]);
  }, []);

  const grantLeaves = useCallback((amount: number) => {
    if (amount > 0) setLeaves((value) => value + amount);
  }, []);

  const spendLeaves = useCallback((amount: number) => {
    if (!Number.isFinite(amount) || amount <= 0 || leaves < amount) return false;
    setLeaves((value) => Math.max(0, value - amount));
    return true;
  }, [leaves]);

  const grantCollectible = useCallback((id: CollectibleId) => {
    setOwnedCollectibles((items) => (items.includes(id) ? items : [...items, id]));
  }, []);

  const selectCollectible = useCallback((id: CollectibleId) => {
    if (!hydrated || !paperPlanetsCollectibles.some((item) => item.id === id)) return false;
    if (!ownedCollectibles.includes(id)) {
      // An empty collection gets one starter choice, including between renders.
      if (ownedCollectibles.length > 0 || firstCollectibleChoice.current) return false;
      firstCollectibleChoice.current = id;
      setOwnedCollectibles([id]);
    }
    setSelectedCollectible(id);
    return true;
  }, [hydrated, ownedCollectibles]);

  const setSoundscape = useCallback((next: Soundscape) => {
    setSoundscapeState(next);
  }, []);

  const unlockReward = useCallback((id: string, category: RewardCategory) => {
    setUnlockedRewards((items) => (items.includes(id) ? items : [...items, id]));
    const style = id.replace(`${category}-`, '');
    if (category === 'breath') {
      setEquipped((current) => ({ ...current, breath: style as BreathStyle }));
    } else {
      setEquipped((current) => ({ ...current, roast: style as RoastStyle }));
    }
  }, []);

  const unlockAndEquip = useCallback(
    (id: string, cost: number, category: RewardCategory) => {
      const isUnlocked = unlockedRewards.includes(id);
      if (!isUnlocked && leaves < cost) return false;

      if (!isUnlocked) {
        setLeaves((value) => value - cost);
        setUnlockedRewards((items) => [...items, id]);
      }

      setEquipped((current) => ({
        ...current,
        [category]: id.replace(`${category}-`, ''),
      }));
      return true;
    },
    [leaves, unlockedRewards],
  );

  const applySyncedSnapshot = useCallback((snapshot: RewardsSyncSnapshot) => {
    const claims = snapshot.rewardClaimKeys ?? [];
    rewardClaimKeysRef.current = new Set(claims);
    setRewardClaimKeys(claims);
    setLeaves(Math.max(0, snapshot.leaves));
    setMindfulMinutes(Math.max(0, snapshot.mindfulMinutes));
    setUnlockedRewards(snapshot.unlockedRewards);
    setEquipped(snapshot.equipped);
    setStillnessEvents(snapshot.stillnessEvents);
    setOwnedCollectibles(snapshot.ownedCollectibles);
    setSelectedCollectible(snapshot.selectedCollectible);
    setSoundscapeState(snapshot.soundscape);
  }, []);

  const value = useMemo(
    () => ({
      storageError,
      rewardClaimKeys,
      importRewardClaims,
      claimLocalReward,
      leaves,
      mindfulMinutes,
      hydrated,
      unlockedRewards,
      equipped,
      stillnessEvents,
      ownedCollectibles,
      selectedCollectible,
      soundscape,
      completeStillness,
      grantLeaves,
      spendLeaves,
      grantCollectible,
      selectCollectible,
      setSoundscape,
      unlockReward,
      unlockAndEquip,
      syncSnapshot: {
        rewardClaimKeys,
        leaves,
        mindfulMinutes,
        unlockedRewards,
        equipped,
        stillnessEvents,
        ownedCollectibles,
        selectedCollectible,
        soundscape,
      },
      applySyncedSnapshot,
    }),
    [storageError, rewardClaimKeys, importRewardClaims, claimLocalReward, applySyncedSnapshot, completeStillness, equipped, grantCollectible, grantLeaves, hydrated, leaves, mindfulMinutes, ownedCollectibles, selectCollectible, selectedCollectible, setSoundscape, soundscape, spendLeaves, stillnessEvents, unlockAndEquip, unlockReward, unlockedRewards],
  );

  return <RewardsContext.Provider value={value}>{children}</RewardsContext.Provider>;
}

export function useRewards() {
  const value = useContext(RewardsContext);
  if (!value) throw new Error('useRewards must be used inside RewardsProvider');
  return value;
}
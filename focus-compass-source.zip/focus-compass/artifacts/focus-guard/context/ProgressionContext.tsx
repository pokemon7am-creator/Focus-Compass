import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '@clerk/expo';
import { AppState } from 'react-native';
import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { useFocus } from '@/context/FocusContext';
import { useRevenueCat } from '@/context/RevenueCatContext';
import { CollectibleId, RewardCategory, useRewards } from '@/context/RewardsContext';
import { usePracticeClaims } from '@/context/PracticeClaimsContext';
import { createWeeklyMissions, getLocalWeekKey as missionWeekKey } from '@/services/weeklyMissions';

export type RewardClaimResult = { status: 'claimed' | 'already-claimed' | 'error'; message?: string };

type PassRewardKind = 'leaves' | 'unlock';
export type WeeklyMission = {
  id: 'focus-sessions' | 'focus-minutes' | 'stillness-sessions';
  title: string;
  description: string;
  goal: number;
  progress: number;
  rewardLabel: string;
  rewardKind: 'leaves' | 'collectible';
  rewardAmount?: number;
  collectibleId?: CollectibleId;
};
export type StasisCapsuleResult = 'not-ready' | 'insufficient-leaves' | 'stasis-token' | 'consolation';
export type PassReward = {
  tier: number;
  icon: 'star' | 'wind' | 'shield' | 'book-open' | 'zap' | 'award' | 'sun' | 'gift' | 'moon' | 'message-circle' | 'edit-3';
  title: string;
  description: string;
  premium: boolean;
  kind: PassRewardKind;
  amount?: number;
  rewardId?: string;
  rewardCategory?: RewardCategory;
};

type MonthlyTheme = {
  name: string;
  subtitle: string;
  icon: PassReward['icon'];
};

type ProgressionState = {
  hydrated: boolean;
  focusMinutes: number;
  level: number;
  minutesIntoLevel: number;
  minutesPerLevel: number;
  maxLevels: number;
  seasonKey: string;
  seasonName: string;
  themeName: string;
  themeSubtitle: string;
  themeIcon: MonthlyTheme['icon'];
  seasonEndsAt: string;
  rewards: PassReward[];
  claimedRewards: string[];
  claimReward: (reward: PassReward) => Promise<RewardClaimResult>;
  claiming: boolean;
  claimsReady: boolean;
  weekKey: string;
  weeklyMissions: WeeklyMission[];
  claimedWeeklyMissions: string[];
  claimWeeklyMission: (mission: WeeklyMission) => Promise<RewardClaimResult>;
  drawStasisCapsule: () => StasisCapsuleResult;
  isPremium: boolean;
};

type PersistedProgression = {
  seasonKey?: string;
  claimedRewards?: string[];
  weeklyMissionClaims?: Record<string, string[]>;
};

const LEGACY_STORAGE_KEY = 'space-progression-v2';
const MIGRATION_OWNER_KEY = 'space-progression-v2-migration-owner';
const MINUTES_PER_LEVEL = 20;
const MAX_LEVELS = 50;
export const STASIS_CAPSULE_COST = 40;
export const STASIS_TOKEN_CHANCE = 0.08;

const monthlyThemes: MonthlyTheme[] = [
  { name: 'Quiet Orbit', subtitle: 'Build a calm orbit, one focused minute at a time.', icon: 'wind' },
  { name: 'Dawn Circuit', subtitle: 'Start bright and keep the momentum gentle.', icon: 'sun' },
  { name: 'Rainy Library', subtitle: 'A softer season for deep reading and steady work.', icon: 'book-open' },
  { name: 'Greenhouse', subtitle: 'Small sessions grow into something you can see.', icon: 'award' },
  { name: 'Moon Garden', subtitle: 'Make room for patient, low-noise progress.', icon: 'moon' as PassReward['icon'] },
  { name: 'Sunlit Desk', subtitle: 'Clear the desk. Choose the next useful thing.', icon: 'star' },
  { name: 'Tide Pool', subtitle: 'Return to the work in small, repeatable waves.', icon: 'wind' },
  { name: 'Night Flight', subtitle: 'Protect the quiet that helps ideas travel.', icon: 'zap' },
  { name: 'Paper Planets', subtitle: 'Turn notes, drafts, and questions into motion.', icon: 'book-open' },
  { name: 'Golden Hour', subtitle: 'Use your attention while the light is good.', icon: 'sun' },
  { name: 'Evergreen', subtitle: 'Consistency is the rarest reward.', icon: 'shield' },
  { name: 'Winter Signal', subtitle: 'A small signal is enough to begin again.', icon: 'gift' },
  { name: 'Ink & Ivy', subtitle: 'Let a clear page make room for a curious mind.', icon: 'book-open' },
  { name: 'Cloud Desk', subtitle: 'Keep the next useful thing light and visible.', icon: 'wind' },
  { name: 'Lantern Room', subtitle: 'Protect a warm pocket of attention from the noise.', icon: 'sun' },
  { name: 'Moss Signal', subtitle: 'Slow progress still leaves a trail you can follow.', icon: 'shield' },
  { name: 'Little Comet', subtitle: 'Small bursts of momentum can change your whole orbit.', icon: 'star' },
  { name: 'Quiet Harbor', subtitle: 'Return to the work like water returning to shore.', icon: 'wind' },
  { name: 'Copper Dawn', subtitle: 'Begin before the day has a chance to crowd you.', icon: 'sun' },
  { name: 'Atlas Notes', subtitle: 'Map the ideas that are worth carrying forward.', icon: 'book-open' },
  { name: 'Meadow Circuit', subtitle: 'Build a rhythm that feels steady instead of forced.', icon: 'zap' },
  { name: 'Blue Lantern', subtitle: 'A little light is enough for the next step.', icon: 'moon' as PassReward['icon'] },
  { name: 'Seedling Studio', subtitle: 'Give unfinished ideas the quiet they need to grow.', icon: 'award' },
  { name: 'Still Water', subtitle: 'Make space for calm attention and deliberate motion.', icon: 'gift' },
];

const levelMotifs = [
  'First Light', 'Open Window', 'Soft Focus', 'Small Orbit', 'Clear Desk',
  'Blue Hour', 'Fresh Page', 'Slow Bloom', 'Bright Line', 'Deep Breath',
];
const rewardIcons: PassReward['icon'][] = ['star', 'wind', 'shield', 'book-open', 'zap', 'award', 'sun', 'gift'];

const specialRewards: Record<
  number,
  { icon: PassReward['icon']; title: string; description: string; rewardId: string; rewardCategory: RewardCategory }
> = {
  1: {
    icon: 'wind',
    title: 'Moonlight breath',
    description: 'Unlocks the Moonlight breathing style in Shop.',
    rewardId: 'breath-moonlight',
    rewardCategory: 'breath',
  },
  2: {
    icon: 'message-circle',
    title: 'Bold roast pack',
    description: 'Unlocks sharper AI roast prompts in Shop.',
    rewardId: 'roast-bold',
    rewardCategory: 'roast',
  },
  3: {
    icon: 'star',
    title: 'Starlight breath',
    description: 'Unlocks the Starlight breathing style in Shop.',
    rewardId: 'breath-starlight',
    rewardCategory: 'breath',
  },
  4: {
    icon: 'message-circle',
    title: 'Dry roast pack',
    description: 'Unlocks calm, deadpan AI roasts in Shop.',
    rewardId: 'roast-dry',
    rewardCategory: 'roast',
  },
  5: {
    icon: 'sun',
    title: 'Sunrise breath',
    description: 'Unlocks the Sunrise breathing style in Shop.',
    rewardId: 'breath-sunrise',
    rewardCategory: 'breath',
  },
  6: {
    icon: 'zap',
    title: 'Chaos roast pack',
    description: 'Unlocks the Chaos AI roast style in Shop.',
    rewardId: 'roast-chaos',
    rewardCategory: 'roast',
  },
  7: {
    icon: 'award',
    title: 'Aurora breath',
    description: 'Unlocks the Aurora breathing style in Shop.',
    rewardId: 'breath-aurora',
    rewardCategory: 'breath',
  },
};

const paperPlanetsRewards: typeof specialRewards = {
  1: {
    icon: 'book-open',
    title: 'Paper Fold breath',
    description: 'Unlocks a folded-paper orbit for Stillness sessions.',
    rewardId: 'breath-paperfold',
    rewardCategory: 'breath',
  },
  2: {
    icon: 'edit-3',
    title: 'Margin Notes roast pack',
    description: 'Unlocks bookish footnotes for focus interruptions.',
    rewardId: 'roast-margin-notes',
    rewardCategory: 'roast',
  },
  3: {
    icon: 'star',
    title: 'Paper Planets constellation',
    description: 'Unlocks Starlight breath as the next point in your paper sky.',
    rewardId: 'breath-starlight',
    rewardCategory: 'breath',
  },
};

function getSeason() {
  const now = new Date();
  const seasonEnds = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  const seasonKey = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  const theme = monthlyThemes[now.getMonth() % monthlyThemes.length];
  const seasonName = now.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
  return {
    seasonKey,
    seasonName: `${seasonName} season`,
    theme,
    seasonEndsAt: seasonEnds.toISOString(),
  };
}

function createPassRewards(theme: MonthlyTheme) {
  return Array.from({ length: MAX_LEVELS * 2 }, (_, index) => {
    const tier = Math.floor(index / 2) + 1;
    const premium = index % 2 === 1;
    const motif = levelMotifs[(tier - 1) % levelMotifs.length];
    const icon = rewardIcons[(tier - 1) % rewardIcons.length];
    const leafAmount = Math.min(50, 5 + Math.floor((tier - 1) / 5) * 5);
    const special = premium
      ? theme.name === 'Paper Planets'
        ? paperPlanetsRewards[tier] ?? specialRewards[tier]
        : specialRewards[tier]
      : undefined;

    if (special) {
      return {
        tier,
        icon: special.icon,
        premium,
        title: special.title,
        description: special.description,
        kind: 'unlock' as const,
        rewardId: special.rewardId,
        rewardCategory: special.rewardCategory,
      };
    }

    return {
      tier,
      icon,
      premium,
      title: `${leafAmount} Leaves`,
      description: premium
        ? `A ${theme.name.toLowerCase()} bonus for level ${tier}.`
        : `Adds ${leafAmount} Leaves to your Shop wallet.`,
      kind: 'leaves' as const,
      amount: leafAmount,
    };
  });
}

export function ProgressionProvider({ children }: { children: React.ReactNode }) {
  const { isLoaded, userId } = useAuth();
  const storageKey = userId ? `${LEGACY_STORAGE_KEY}:user:${userId}` : LEGACY_STORAGE_KEY;
  const focus = useFocus();
  const revenueCat = useRevenueCat();
  const rewardsWallet = useRewards();
  const syncedClaims = usePracticeClaims();
  const [legacyClaimedRewards, setClaimedRewards] = useState<string[]>([]);
  const [weeklyMissionClaims, setWeeklyMissionClaims] = useState<Record<string, string[]>>({});
  const [hydratedStorageKey, setHydratedStorageKey] = useState<string | null>(null);
  const hydrated = isLoaded && hydratedStorageKey === storageKey;
  const claimedMissionKeys = useRef(new Set<string>());
  const [calendarDate, setCalendarDate] = useState(() => new Date());
  const [claiming, setClaiming] = useState(false);
  const claimLock = useRef(false);
  const season = getSeason();
  const weekKey = missionWeekKey(calendarDate);
  const claimedRewards = useMemo(() => [...new Set([
    ...legacyClaimedRewards,
    ...rewardsWallet.rewardClaimKeys.filter((key) => key.startsWith(`pass:${season.seasonKey}:`))
      .map((key) => key.slice(5).replaceAll(':', '-')),
  ])], [legacyClaimedRewards, rewardsWallet.rewardClaimKeys, season.seasonKey]);
  const claimsReady = hydrated && focus.hydrated && rewardsWallet.hydrated && (!userId || syncedClaims.ready);
  useEffect(() => {
    const refresh = () => setCalendarDate(new Date());
    const interval = setInterval(refresh, 30000);
    const subscription = AppState.addEventListener('change', (state) => { if (state === 'active') refresh(); });
    return () => { clearInterval(interval); subscription.remove(); };
  }, []);
  const rewards = useMemo(() => createPassRewards(season.theme), [season.theme]);
  const weeklyMissions = useMemo<WeeklyMission[]>(
    () => createWeeklyMissions(focus.syncSnapshot.sessions, rewardsWallet.stillnessEvents, calendarDate),
    [focus.syncSnapshot.sessions, rewardsWallet.stillnessEvents, calendarDate],
  );

  useEffect(() => {
    let cancelled = false;
    setHydratedStorageKey(null);
    setClaimedRewards([]);
    setWeeklyMissionClaims({});
    claimedMissionKeys.current = new Set();

    if (!isLoaded) {
      return () => {
        cancelled = true;
      };
    }

    const hydrate = async () => {
      let raw = await AsyncStorage.getItem(storageKey);
      if (userId) {
        const [legacy, migrationOwner] = await Promise.all([
          AsyncStorage.getItem(LEGACY_STORAGE_KEY),
          AsyncStorage.getItem(MIGRATION_OWNER_KEY),
        ]);
        if (legacy && !migrationOwner) {
          if (raw) {
            await AsyncStorage.setItem(MIGRATION_OWNER_KEY, userId);
          } else {
            await AsyncStorage.multiSet([
              [storageKey, legacy],
              [MIGRATION_OWNER_KEY, userId],
            ]);
            raw = legacy;
          }
          await AsyncStorage.removeItem(LEGACY_STORAGE_KEY);
        }
      }

      if (cancelled || !raw) {
        if (!cancelled) setHydratedStorageKey(storageKey);
        return;
      }
        const saved = JSON.parse(raw) as PersistedProgression;
        setClaimedRewards(saved.seasonKey === season.seasonKey ? saved.claimedRewards ?? [] : []);
        const claims = saved.weeklyMissionClaims ?? {};
        setWeeklyMissionClaims(claims);
        claimedMissionKeys.current = new Set(
          Object.entries(claims).flatMap(([key, ids]) => ids.map((id) => `${key}-${id}`)),
        );
      if (!cancelled) setHydratedStorageKey(storageKey);
    };

    hydrate().catch(() => {
      if (!cancelled) setHydratedStorageKey(storageKey);
    });
    return () => {
      cancelled = true;
    };
  }, [isLoaded, season.seasonKey, storageKey, userId]);

  useEffect(() => {
    if (!hydrated || !rewardsWallet.hydrated) return;
    // Older versions saved claim markers apart from the wallet. Import markers
    // only: their awards are already included in the saved balance.
    const keys = [
      ...legacyClaimedRewards.filter((key) => /^\d{4}-\d{2}-(free|premium)-\d+$/.test(key))
        .map((key) => key.replace(/^(\d{4}-\d{2})-(free|premium)-(\d+)$/, 'pass:$1:$2:$3')),
      ...Object.entries(weeklyMissionClaims).flatMap(([week, ids]) =>
        ids.map((id) => `weekly:${week}:${id}`)),
    ];
    rewardsWallet.importRewardClaims(keys);
  }, [hydrated, legacyClaimedRewards, weeklyMissionClaims, rewardsWallet.hydrated, rewardsWallet.importRewardClaims]);

  useEffect(() => {
    if (!hydrated || !rewardsWallet.hydrated) return;
    AsyncStorage.setItem(
      storageKey,
      JSON.stringify({ seasonKey: season.seasonKey, claimedRewards, weeklyMissionClaims }),
    ).catch(() => undefined);
  }, [claimedRewards, hydrated, rewardsWallet.hydrated, season.seasonKey, storageKey, weeklyMissionClaims]);

  useEffect(() => {
    if (!hydrated || !rewardsWallet.hydrated) return;

    for (const reward of rewards) {
      const key = `${season.seasonKey}-${reward.premium ? 'premium' : 'free'}-${reward.tier}`;
      if (
        claimedRewards.includes(key) &&
        reward.kind === 'unlock' &&
        reward.rewardId &&
        reward.rewardCategory
      ) {
        // Backfill rewards claimed before the Pass reward was connected to Shop.
        rewardsWallet.unlockReward(reward.rewardId, reward.rewardCategory);
      }
    }
  }, [claimedRewards, hydrated, rewards, rewardsWallet.hydrated, rewardsWallet.unlockReward, season.seasonKey]);

  const focusMinutes = focus.minutesFocusedThisMonth;
  const level = Math.min(MAX_LEVELS, Math.floor(focusMinutes / MINUTES_PER_LEVEL) + 1);
  const minutesIntoLevel = level === MAX_LEVELS && focusMinutes >= (MAX_LEVELS - 1) * MINUTES_PER_LEVEL
    ? Math.min(MINUTES_PER_LEVEL, focusMinutes - (MAX_LEVELS - 1) * MINUTES_PER_LEVEL)
    : focusMinutes % MINUTES_PER_LEVEL;

  const claimReward = useCallback(
    async (requested: PassReward): Promise<RewardClaimResult> => {
      const reward = rewards.find((item) => item.tier === requested.tier && item.premium === requested.premium);
      if (!reward || getSeason().seasonKey !== season.seasonKey) return { status: 'error', message: 'The season changed. Please try again.' };
      const key = `${season.seasonKey}-${reward.premium ? 'premium' : 'free'}-${reward.tier}`;
      if (!claimsReady || claimLock.current) return { status: 'error', message: 'Your practice is syncing. Connect to the internet and try again shortly.' };
      if (reward.premium && !revenueCat.isPremium) return { status: 'error', message: 'Premium is required for this reward.' };
      if (claimedRewards.includes(key)) return { status: 'already-claimed' };
      if (level < reward.tier) return { status: 'error', message: 'Reach this level before claiming its reward.' };
      claimLock.current = true;
      setClaiming(true);
      try {
        const claimKey = `pass:${season.seasonKey}:${reward.premium ? 'premium' : 'free'}:${reward.tier}`;
        const status = userId
          ? await syncedClaims.requestClaim(claimKey)
          : rewardsWallet.claimLocalReward(claimKey, {
            leaves: reward.kind === 'leaves' ? reward.amount : undefined,
            rewardId: reward.rewardId,
            category: reward.rewardCategory,
          }) ? 'claimed' : 'already-claimed';
        return { status };
      } catch (error) {
        return { status: 'error', message: error instanceof Error ? error.message : 'Could not claim this reward. Please try again.' };
      } finally {
        claimLock.current = false;
        setClaiming(false);
      }
    },
    [claimedRewards, claimsReady, level, revenueCat.isPremium, rewardsWallet, rewards, season.seasonKey, syncedClaims, userId],
  );

  const claimWeeklyMission = useCallback(async (requested: WeeklyMission): Promise<RewardClaimResult> => {
    const now = new Date();
    if (missionWeekKey(now) !== weekKey) return { status: 'error', message: 'A new week has started. Please try again.' };
    const mission = createWeeklyMissions(focus.syncSnapshot.sessions, rewardsWallet.stillnessEvents, now).find((item) => item.id === requested.id);
    if (!claimsReady || claimLock.current) return { status: 'error', message: 'Your practice is syncing. Connect to the internet and try again shortly.' };
    if (!mission || mission.progress < mission.goal) return { status: 'error', message: 'Complete this week’s mission before claiming.' };
    const claimKey = `weekly:${weekKey}:${mission.id}`;
    if (rewardsWallet.rewardClaimKeys.includes(claimKey) || claimedMissionKeys.current.has(`${weekKey}-${mission.id}`)) return { status: 'already-claimed' };
    claimLock.current = true;
    setClaiming(true);
    try {
      const status = userId
        ? await syncedClaims.requestClaim(claimKey)
        : rewardsWallet.claimLocalReward(claimKey, { leaves: mission.rewardAmount, collectibleId: mission.collectibleId }) ? 'claimed' : 'already-claimed';
      return { status };
    } catch (error) {
      return { status: 'error', message: error instanceof Error ? error.message : 'Could not claim this reward. Please try again.' };
    } finally {
      claimLock.current = false;
      setClaiming(false);
    }
  }, [claimsReady, focus.syncSnapshot.sessions, rewardsWallet, syncedClaims, userId, weekKey]);

  const drawStasisCapsule = useCallback((): StasisCapsuleResult => {
    if (!hydrated || !focus.hydrated || !rewardsWallet.hydrated) return 'not-ready';
    if (!rewardsWallet.spendLeaves(STASIS_CAPSULE_COST)) return 'insufficient-leaves';
    if (Math.random() < STASIS_TOKEN_CHANCE) {
      focus.grantStasisTokens(1);
      return 'stasis-token';
    }
    rewardsWallet.grantLeaves(5);
    return 'consolation';
  }, [focus, hydrated, rewardsWallet]);

  const claimedWeeklyMissions = [...new Set([
    ...(weeklyMissionClaims[weekKey] ?? []),
    ...rewardsWallet.rewardClaimKeys.filter((key) => key.startsWith(`weekly:${weekKey}:`)).map((key) => key.split(':')[2]),
  ])];

  const value = useMemo(
    () => ({
      hydrated,
      claiming,
      claimsReady,
      focusMinutes,
      level,
      minutesIntoLevel,
      minutesPerLevel: MINUTES_PER_LEVEL,
      maxLevels: MAX_LEVELS,
      seasonKey: season.seasonKey,
      seasonName: season.seasonName,
      themeName: season.theme.name,
      themeSubtitle: season.theme.subtitle,
      themeIcon: season.theme.icon,
      seasonEndsAt: season.seasonEndsAt,
      rewards,
      claimedRewards,
      claimReward,
      weekKey,
      weeklyMissions,
      claimedWeeklyMissions,
      claimWeeklyMission,
      drawStasisCapsule,
      isPremium: revenueCat.isPremium,
    }),
    [
      claiming,
      claimsReady,
      claimReward,
      claimedRewards,
      claimedWeeklyMissions,
      claimWeeklyMission,
      drawStasisCapsule,
      focusMinutes,
      hydrated,
      level,
      minutesIntoLevel,
      revenueCat.isPremium,
      rewards,
      season.seasonEndsAt,
      season.seasonKey,
      season.seasonName,
      season.theme.icon,
      season.theme.name,
      season.theme.subtitle,
      weekKey,
      weeklyMissions,
    ],
  );

  return <ProgressionContext.Provider value={value}>{children}</ProgressionContext.Provider>;
}

const ProgressionContext = createContext<ProgressionState | null>(null);

export function useProgression() {
  const value = useContext(ProgressionContext);
  if (!value) throw new Error('useProgression must be used inside ProgressionProvider');
  return value;
}
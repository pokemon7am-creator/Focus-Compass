import { createContext, useContext } from 'react';

export type ClaimStatus = 'claimed' | 'already-claimed';
export type PracticeClaimsState = {
  ready: boolean;
  requestClaim: (claimKey: string) => Promise<ClaimStatus>;
};

export const PracticeClaimsContext = createContext<PracticeClaimsState>({
  ready: false,
  requestClaim: async () => { throw new Error('Your practice is still syncing. Please try again shortly.'); },
});

export const usePracticeClaims = () => useContext(PracticeClaimsContext);
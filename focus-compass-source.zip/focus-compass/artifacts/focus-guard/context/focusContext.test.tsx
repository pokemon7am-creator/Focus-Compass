import React from 'react';
import TestRenderer, { act } from 'react-test-renderer';
import type { useFocus } from './FocusContext';

declare const __filename: string;
declare const require: (moduleName: string) => {
  _load: (request: string, parent: unknown, isMain: boolean) => unknown;
};

type FocusApi = ReturnType<typeof useFocus>;

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

function assertEqual<T>(actual: T, expected: T, message: string) {
  assert(actual === expected, `${message}; expected ${String(expected)}, received ${String(actual)}`);
}

const storage = new Map<string, string>();
const blockingStarts: { appIds: string[]; durationSeconds: number }[] = [];
let blockingStops = 0;
let nativeBlockingStatus = 'ready';
let rejectBlockingStart = false;
const nativeBlocker = {
  getStatus: async () => nativeBlockingStatus,
  startBlocking: async (appIds: string[], durationSeconds: number) => {
    if (rejectBlockingStart) throw new Error('permission lost');
    blockingStarts.push({ appIds, durationSeconds });
  },
  stopBlocking: async () => {
    blockingStops += 1;
  },
};
const nodeModule = require('node:module');
const originalLoad = nodeModule._load;
(
  globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean }
).IS_REACT_ACT_ENVIRONMENT = true;

// FocusProvider's production dependencies include native modules. Keep this
// runner deterministic and host-platform independent while exercising the
// provider's real state transitions.
nodeModule._load = (request, parent, isMain) => {
  if (request === '@clerk/expo') {
    return { useAuth: () => ({ isLoaded: true, userId: null }) };
  }
  if (request === '@react-native-async-storage/async-storage') {
    return {
      getItem: async (key: string) => storage.get(key) ?? null,
      setItem: async (key: string, value: string) => {
        storage.set(key, value);
      },
      multiSet: async (entries: [string, string][]) => {
        entries.forEach(([key, value]) => storage.set(key, value));
      },
      removeItem: async (key: string) => {
        storage.delete(key);
      },
    };
  }
  if (request === 'expo-haptics') {
    return {
      ImpactFeedbackStyle: { Medium: 'medium' },
      NotificationFeedbackType: { Success: 'success', Warning: 'warning' },
      impactAsync: async () => undefined,
      notificationAsync: async () => undefined,
      selectionAsync: async () => undefined,
    };
  }
  if (request === 'expo') {
    return { requireOptionalNativeModule: () => nativeBlocker };
  }
  if (request === 'react-native') {
    return {
      AppState: {
        addEventListener: () => ({ remove: () => undefined }),
      },
      Linking: { openSettings: async () => undefined },
      Platform: { OS: 'ios' },
      DeviceEventEmitter: { addListener: () => ({ remove: () => undefined }) },
    };
  }
  return originalLoad(request, parent, isMain);
};

async function flushEffects() {
  await new Promise<void>((resolve) => setTimeout(resolve, 0));
}

async function createHarness(startAt: number, savedState?: Record<string, unknown>) {
  storage.clear();
  blockingStarts.length = 0;
  blockingStops = 0;
  if (savedState) {
    storage.set('focus-guard-state-v2', JSON.stringify(savedState));
  }
  Date.now = () => startAt;
  const focusModule = await import('./FocusContext');
  let value: FocusApi | undefined;
  const ProbeWithContext = () => {
    value = focusModule.useFocus();
    return null;
  };
  let renderer: TestRenderer.ReactTestRenderer;

  await act(async () => {
    renderer = TestRenderer.create(
      React.createElement(
        focusModule.FocusProvider,
        null,
        React.createElement(ProbeWithContext),
      ),
    );
    await flushEffects();
    await flushEffects();
  });

  assert(value !== undefined, 'FocusProvider should expose its context value');
  return {
    get value() {
      assert(value !== undefined, 'FocusProvider context value should remain available');
      return value;
    },
    unmount: async () => {
      await act(async () => {
        renderer.unmount();
        await flushEffects();
      });
    },
  };
}

async function endSession(harness: Awaited<ReturnType<typeof createHarness>>) {
  let sessionId: string | null = null;
  await act(async () => {
    sessionId = harness.value.endSession();
    await flushEffects();
  });
  return sessionId;
}

/**
 * Provider-level regression coverage for the minutes that survive an
 * interruption. This deliberately calls the public context methods instead
 * of testing the timer arithmetic in isolation.
 */
export async function runFocusContextRegressionTests() {
  const originalDateNow = Date.now;
  try {
    // An escape check stays locked until the selected friction path reports
    // completion, and completing a different path must not unlock it.
    {
      const harness = await createHarness(Date.UTC(2026, 8, 17, 11));
      assert(!harness.value.frictionCheck.required, 'friction checks should start inactive');
      await act(async () => {
        harness.value.beginFrictionCheck();
        await flushEffects();
      });
      assert(harness.value.frictionCheck.required, 'an escape should require a friction check');
      await act(async () => {
        harness.value.selectFrictionPath('physical');
        await flushEffects();
      });
      assertEqual(
        harness.value.frictionCheck.selected,
        'physical',
        'the chosen friction path should be retained',
      );
      await act(async () => {
        harness.value.completeFrictionPath('math');
        await flushEffects();
      });
      assert(!harness.value.frictionCheck.completed, 'a different path must not unlock focus');
      await act(async () => {
        harness.value.completeFrictionPath('physical');
        await flushEffects();
      });
      assert(harness.value.frictionCheck.completed, 'the selected path should unlock focus');
      await act(async () => {
        harness.value.clearFrictionCheck();
        await flushEffects();
      });
      assert(!harness.value.frictionCheck.required, 'returning to focus should clear the check');
      await harness.unmount();
    }

    // Running sessions record whole elapsed minutes from the deadline, not
    // the rounded countdown displayed by the UI.
    {
      const startAt = Date.UTC(2026, 8, 17, 12);
      const harness = await createHarness(startAt);
      await act(async () => {
        harness.value.startSession(10);
        await flushEffects();
      });
      Date.now = () => startAt + 3 * 60 * 1000 + 42_500;
      const sessionId = await endSession(harness);
      assert(sessionId !== null, 'ending a running session should record a session');
      assertEqual(
        harness.value.syncSnapshot.sessions.length,
        1,
        'running session should be persisted once',
      );
      assertEqual(
        harness.value.syncSnapshot.sessions[0].durationMinutes,
        3,
        'running session should record elapsed whole minutes',
      );
      await harness.unmount();
    }

    // Reopening during a valid running session restores native enforcement
    // only for the selected apps and the remaining wall-clock duration.
    {
      const startAt = Date.UTC(2026, 8, 17, 12, 30);
      const targetEndAt = startAt + 8 * 60 * 1000;
      const harness = await createHarness(startAt, {
        apps: [
          { id: 'selected-token', name: 'Selected app', category: 'Screen Time', active: true },
          { id: 'inactive-token', name: 'Inactive app', category: 'Screen Time', active: false },
        ],
        sessionSeconds: 10 * 60,
        elapsedSeconds: 2 * 60,
        remainingSeconds: 8 * 60,
        isRunning: true,
        hasActiveSession: true,
        targetEndAt,
        activeSessionId: 'restored-session',
        sessions: [],
        overrideEvents: [],
      });
      assertEqual(blockingStarts.length, 1, 'running restoration should restart native blocking once');
      assertEqual(
        blockingStarts[0].appIds.join(','),
        'selected-token',
        'running restoration should block only active selections',
      );
      assertEqual(
        blockingStarts[0].durationSeconds,
        8 * 60,
        'running restoration should use the persisted deadline',
      );
      assertEqual(harness.value.blockingStatus, 'active', 'successful restoration should report active blocking');
      await harness.unmount();
    }

    // Losing device permission while the app was closed must not be reported
    // as active protection when native restoration fails.
    {
      const startAt = Date.UTC(2026, 8, 17, 12, 40);
      rejectBlockingStart = true;
      nativeBlockingStatus = 'needs-permission';
      const harness = await createHarness(startAt, {
        apps: [
          { id: 'selected-token', name: 'Selected app', category: 'Screen Time', active: true },
        ],
        sessionSeconds: 10 * 60,
        elapsedSeconds: 2 * 60,
        remainingSeconds: 8 * 60,
        isRunning: true,
        hasActiveSession: true,
        targetEndAt: startAt + 8 * 60 * 1000,
        activeSessionId: 'permission-loss-session',
        sessions: [],
        overrideEvents: [],
      });
      assertEqual(
        harness.value.blockingStatus,
        'needs-permission',
        'failed restoration should expose the current native permission state',
      );
      await harness.unmount();
      rejectBlockingStart = false;
      nativeBlockingStatus = 'ready';
    }

    // Paused sessions remain resumable but must not leave native blocking on.
    {
      const startAt = Date.UTC(2026, 8, 17, 12, 45);
      const harness = await createHarness(startAt, {
        apps: [
          { id: 'selected-token', name: 'Selected app', category: 'Screen Time', active: true },
        ],
        sessionSeconds: 10 * 60,
        elapsedSeconds: 2 * 60,
        remainingSeconds: 8 * 60,
        isRunning: false,
        hasActiveSession: true,
        targetEndAt: null,
        activeSessionId: 'paused-session',
        sessions: [],
        overrideEvents: [],
      });
      assertEqual(blockingStarts.length, 0, 'paused restoration should not restart native blocking');
      assert(blockingStops > 0, 'paused restoration should clear native blocking');
      assertEqual(harness.value.blockingStatus, 'ready', 'paused restoration should report ready blocking');
      await harness.unmount();
    }

    // An already-expired running deadline is completed by the timer recovery
    // path, but native enforcement is cleared rather than restarted.
    {
      const startAt = Date.UTC(2026, 8, 17, 12, 50);
      const harness = await createHarness(startAt, {
        apps: [
          { id: 'selected-token', name: 'Selected app', category: 'Screen Time', active: true },
        ],
        sessionSeconds: 10 * 60,
        elapsedSeconds: 9 * 60,
        remainingSeconds: 60,
        isRunning: true,
        hasActiveSession: true,
        targetEndAt: startAt - 1,
        activeSessionId: 'expired-session',
        sessions: [],
        overrideEvents: [],
      });
      assertEqual(blockingStarts.length, 0, 'expired restoration should not restart native blocking');
      assert(blockingStops > 0, 'expired restoration should clear native blocking');
      await harness.unmount();
    }

    // Pausing freezes elapsed wall-clock time; ending later must not count
    // time spent paused.
    {
      const startAt = Date.UTC(2026, 8, 17, 13);
      const harness = await createHarness(startAt);
      await act(async () => {
        harness.value.startSession(10);
        await flushEffects();
      });
      Date.now = () => startAt + 2 * 60 * 1000 + 15_000;
      await act(async () => {
        harness.value.toggleSession();
        await flushEffects();
      });
      Date.now = () => startAt + 8 * 60 * 1000;
      const sessionId = await endSession(harness);
      assert(sessionId !== null, 'ending a paused session should record a session');
      assertEqual(
        harness.value.syncSnapshot.sessions[0].durationMinutes,
        2,
        'paused session should record only elapsed minutes before pausing',
      );
      await harness.unmount();
    }

    // A partial minute is not rounded up into a recorded minute.
    {
      const startAt = Date.UTC(2026, 8, 17, 14);
      const harness = await createHarness(startAt);
      await act(async () => {
        harness.value.startSession(10);
        await flushEffects();
      });
      Date.now = () => startAt + 59_999;
      const sessionId = await endSession(harness);
      assertEqual(sessionId, null, 'sessions under one minute should not be recorded');
      assertEqual(
        harness.value.syncSnapshot.sessions.length,
        0,
        'under-minute sessions should not overstate time',
      );
      await harness.unmount();
    }

    // A completion can be delivered by more than one path (for example, a
    // timer tick and an explicit end). The same active identity is recorded
    // once, and later calls are no-ops.
    {
      const startAt = Date.UTC(2026, 8, 17, 15);
      const harness = await createHarness(startAt);
      await act(async () => {
        harness.value.startSession(5);
        await flushEffects();
      });
      Date.now = () => startAt + 5 * 60 * 1000;
      let firstSessionId: string | null = null;
      let secondSessionId: string | null = null;
      await act(async () => {
        firstSessionId = harness.value.endSession();
        secondSessionId = harness.value.endSession();
        await flushEffects();
      });
      assert(firstSessionId !== null, 'completed session should be recorded');
      assertEqual(secondSessionId, null, 'completed session should not be recorded twice');
      assertEqual(
        harness.value.syncSnapshot.sessions.length,
        1,
        'completed session should have one record',
      );
      assertEqual(
        harness.value.syncSnapshot.sessions[0].durationMinutes,
        5,
        'completed session should retain duration',
      );
      await harness.unmount();
    }

    // A delayed timer tick includes wall-clock time spent while JavaScript was
    // not running, as happens when the app is backgrounded.
    {
      const startAt = Date.UTC(2026, 8, 17, 16);
      const harness = await createHarness(startAt);
      await act(async () => {
        harness.value.startSession(10);
        await flushEffects();
      });
      Date.now = () => startAt + 4 * 60 * 1000 + 250;
      await act(async () => {
        await new Promise<void>((resolve) => setTimeout(resolve, 300));
      });
      assertEqual(
        harness.value.remainingSeconds,
        360,
        'a delayed tick should include elapsed background time',
      );
      await harness.unmount();
    }

    // Pausing captures the deadline-derived remainder, and resuming creates a
    // fresh deadline from that frozen amount rather than counting paused time.
    {
      const startAt = Date.UTC(2026, 8, 17, 17);
      const harness = await createHarness(startAt);
      await act(async () => {
        harness.value.startSession(10);
        await flushEffects();
      });
      Date.now = () => startAt + 2 * 60 * 1000 + 400;
      await act(async () => {
        harness.value.toggleSession();
        await flushEffects();
      });
      const pausedRemaining = harness.value.remainingSeconds;
      assertEqual(pausedRemaining, 480, 'pause should preserve deadline-derived remaining time');

      Date.now = () => startAt + 12 * 60 * 1000;
      await act(async () => {
        harness.value.toggleSession();
        await flushEffects();
      });
      assertEqual(
        harness.value.remainingSeconds,
        pausedRemaining,
        'resume should not consume time spent paused',
      );
      Date.now = () => startAt + 13 * 60 * 1000;
      await act(async () => {
        await new Promise<void>((resolve) => setTimeout(resolve, 300));
      });
      assertEqual(
        harness.value.remainingSeconds,
        pausedRemaining - 60,
        'resumed timer should continue from the preserved remainder',
      );
      await harness.unmount();
    }

    // Hydration ignores a stale displayed remainder for running sessions and
    // recalculates from the persisted deadline.
    {
      const startAt = Date.UTC(2026, 8, 17, 18);
      const deadline = startAt + 10 * 60 * 1000;
      const harness = await createHarness(startAt + 3 * 60 * 1000, {
        sessionSeconds: 600,
        elapsedSeconds: 180,
        remainingSeconds: 599,
        isRunning: true,
        hasActiveSession: true,
        targetEndAt: deadline,
        activeSessionId: 'restored-running-session',
      });
      assertEqual(harness.value.isRunning, true, 'persisted running session should be restored');
      assertEqual(
        harness.value.remainingSeconds,
        420,
        'restored running session should derive remaining time from its deadline',
      );
      await harness.unmount();
    }

    // Automatic completion may race with later completion paths, but the
    // active session identity is recorded exactly once.
    {
      const startAt = Date.UTC(2026, 8, 17, 19);
      const harness = await createHarness(startAt);
      await act(async () => {
        harness.value.startSession(1);
        await flushEffects();
      });
      Date.now = () => startAt + 60_500;
      await act(async () => {
        await new Promise<void>((resolve) => setTimeout(resolve, 300));
      });
      const laterResult = await endSession(harness);
      assertEqual(laterResult, null, 'ending after automatic completion should be a no-op');
      assertEqual(
        harness.value.syncSnapshot.sessions.length,
        1,
        'automatic completion should create exactly one record',
      );
      assertEqual(
        harness.value.syncSnapshot.sessions[0].durationMinutes,
        1,
        'automatic completion should record the full session duration',
      );
      await harness.unmount();
    }
  } finally {
    rejectBlockingStart = false;
    nativeBlockingStatus = 'ready';
    Date.now = originalDateNow;
    nodeModule._load = originalLoad;
  }
}

if (process.argv[1]?.endsWith('focusContext.test.tsx')) {
  runFocusContextRegressionTests().catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  });
}

/**
 * The timer's deadline is the source of truth while it is running. Keeping
 * this calculation separate from the rendered countdown prevents a delayed
 * tick (or a stale `remainingSeconds` value) from changing recorded time.
 */
export function getBoundedElapsedSeconds(
  sessionSeconds: number,
  deadlineAt: number,
  now: number,
) {
  if (!Number.isFinite(sessionSeconds) || sessionSeconds <= 0) return 0;
  if (!Number.isFinite(deadlineAt) || !Number.isFinite(now)) return 0;

  const startAt = deadlineAt - sessionSeconds * 1000;
  return Math.min(sessionSeconds, Math.max(0, (now - startAt) / 1000));
}

export function getRemainingSeconds(sessionSeconds: number, elapsedSeconds: number) {
  return Math.max(0, Math.ceil(sessionSeconds - Math.max(0, elapsedSeconds)));
}

export function getRecordedMinutes(elapsedSeconds: number) {
  return Math.floor(Math.max(0, elapsedSeconds) / 60);
}

export function getResumeDeadline(now: number, sessionSeconds: number, elapsedSeconds: number) {
  return now + Math.max(0, sessionSeconds - Math.max(0, elapsedSeconds)) * 1000;
}

export function getCompletionTimestamp(deadlineAt: number, now: number) {
  return now >= deadlineAt ? deadlineAt : now;
}

export function appendSessionIfMissing<T extends { id: string }>(items: T[], session: T) {
  return items.some((item) => item.id === session.id) ? items : [...items, session];
}
import {
  hasPremiumEntitlement,
  isPurchaseCancellation,
  purchaseErrorMessage,
} from './revenueCatHelpers';
import type { CustomerInfo } from 'react-native-purchases';

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

const withoutPremium = { entitlements: { active: {} } } as CustomerInfo;
const withPremium = {
  entitlements: { active: { premium: { identifier: 'premium' } } },
} as unknown as CustomerInfo;

assert(!hasPremiumEntitlement(withoutPremium), 'missing premium entitlement must remain free');
assert(hasPremiumEntitlement(withPremium), 'active premium entitlement must unlock premium');
assert(isPurchaseCancellation({ userCancelled: true }), 'userCancelled errors must be cancellations');
assert(isPurchaseCancellation({ code: 'PURCHASE_CANCELLED_ERROR' }), 'cancel code must be recognized');
assert(!isPurchaseCancellation(new Error('offline')), 'ordinary errors must not look cancelled');
assert(
  purchaseErrorMessage({ message: 'Store unavailable' }, 'fallback') === 'Store unavailable',
  'SDK error message should be surfaced',
);
assert(purchaseErrorMessage({}, 'fallback') === 'fallback', 'missing SDK message should use fallback');

console.log('RevenueCat helper tests passed');
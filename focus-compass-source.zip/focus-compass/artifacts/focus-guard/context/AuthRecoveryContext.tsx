import React, { createContext, useContext } from 'react';

const AuthRecoveryContext = createContext<(() => void) | null>(null);

export function AuthRecoveryProvider({
  retryAuth,
  children,
}: {
  retryAuth: () => void;
  children: React.ReactNode;
}) {
  return (
    <AuthRecoveryContext.Provider value={retryAuth}>
      {children}
    </AuthRecoveryContext.Provider>
  );
}

export function useAuthRecovery() {
  const retryAuth = useContext(AuthRecoveryContext);
  if (!retryAuth) {
    throw new Error('useAuthRecovery must be used within AuthRecoveryProvider.');
  }
  return retryAuth;
}
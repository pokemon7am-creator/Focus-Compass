import {
  appendSessionIfMissing,
  getBoundedElapsedSeconds,
  getCompletionTimestamp,
  getRecordedMinutes,
  getRemainingSeconds,
  getResumeDeadline,
} from './focusTimer';

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

/**
 * Focus timer regression cases are kept as a small runner because this
 * artifact does not ship a test framework. They can be invoked by a project
 * test harness without mounting React Native or depending on wall-clock time.
 */
export function runFocusTimerRegressionTests() {
  const sessionSeconds = 15 * 60;
  const deadline = Date.UTC(2025, 0, 2, 23, 59, 30);
  const delayedNow = deadline + 5 * 60 * 1000;

  // A delayed callback still records the full timer at its actual deadline,
  // rather than moving the completion into the next day's totals.
  assert(
    getBoundedElapsedSeconds(sessionSeconds, deadline, delayedNow) === sessionSeconds,
    'expired timers must be bounded at their full duration',
  );
  assert(
    getRecordedMinutes(getBoundedElapsedSeconds(sessionSeconds, deadline, delayedNow)) === 15,
    'expired timers must retain their recorded minutes',
  );
  assert(
    getCompletionTimestamp(deadline, delayedNow) === deadline,
    'delayed completion must retain the timer deadline timestamp',
  );

  // Early end uses elapsed wall-clock time from the deadline, not a stale
  // rendered countdown value.
  const earlyNow = deadline - (sessionSeconds - 73) * 1000;
  assert(
    getBoundedElapsedSeconds(sessionSeconds, deadline, earlyNow) === 73,
    'early end must derive elapsed time from the deadline',
  );
  assert(getRecordedMinutes(73) === 1, 'early end must floor recorded minutes');

  // Repeated finish/end calls cannot append the same persisted session twice.
  const session = {
    id: 'stable-session-id',
    completedAt: new Date(deadline).toISOString(),
    durationMinutes: 15,
  };
  const once = appendSessionIfMissing([], session);
  const twice = appendSessionIfMissing(once, session);
  assert(twice.length === 1, 'duplicate completion must be idempotent by session identity');

  // Pausing preserves fractional elapsed time for resume instead of rounding
  // each pause into another lost second.
  const pausedElapsed = 73.5;
  const resumedAt = Date.UTC(2025, 0, 3, 12);
  const resumedDeadline = getResumeDeadline(resumedAt, sessionSeconds, pausedElapsed);
  assert(
    getBoundedElapsedSeconds(sessionSeconds, resumedDeadline, resumedAt + 1000) === 74.5,
    'resume must continue from the exact paused elapsed time',
  );
  assert(
    getRemainingSeconds(sessionSeconds, pausedElapsed) === 827,
    'paused countdown must round only for display',
  );
}
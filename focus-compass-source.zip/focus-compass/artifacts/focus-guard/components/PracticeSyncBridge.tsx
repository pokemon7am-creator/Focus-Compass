import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '@clerk/expo';
import {
  getPractice,
  savePractice,
  claimPracticeReward,
  type PracticeSyncResponse,
} from '@workspace/api-client-react';
import { SavePracticeBody } from '@workspace/api-zod';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';
import {
  useFocus,
  defaultFocusSyncSnapshot,
  type FocusSyncSnapshot,
  type SessionRecord,
} from '@/context/FocusContext';
import {
  useRewards,
  defaultRewardsSyncSnapshot,
  type RewardsSyncSnapshot,
} from '@/context/RewardsContext';
import { practiceDirtyKey } from '@/services/practiceStorage';
import { PracticeClaimsContext, type ClaimStatus } from '@/context/PracticeClaimsContext';
import { duplicateClaimLeaves } from '@/services/rewardClaimLedger';

type PracticeSnapshot = {
  version: 1;
  focus: FocusSyncSnapshot;
  rewards: RewardsSyncSnapshot;
};

type SyncMeta = {
  revision: number;
  snapshot: PracticeSnapshot;
};

const META_KEY_PREFIX = 'flow-practice-sync-v1';
export const DEFAULT_SNAPSHOT: PracticeSnapshot = {
  version: 1,
  focus: defaultFocusSyncSnapshot,
  rewards: defaultRewardsSyncSnapshot,
};

function unionStrings(local: string[], remote: string[]) {
  return [...new Set([...remote, ...local])];
}

function mergeSessions(local: SessionRecord[], remote: SessionRecord[]) {
  const merged = new Map(remote.map((session) => [session.id, session]));
  for (const session of local) {
    const existing = merged.get(session.id);
    merged.set(session.id, {
      ...(existing ?? session),
      ...session,
      reflection: session.reflection ?? existing?.reflection,
    });
  }
  return [...merged.values()].sort((a, b) => a.completedAt.localeCompare(b.completedAt));
}

function mergeCounter(local: number, remote: number, base?: number) {
  if (base === undefined) return Math.max(local, remote);
  return Math.max(0, base + (local - base) + (remote - base));
}

function changedChoice<T>(local: T, remote: T, base?: T) {
  if (base === undefined) return remote;
  return JSON.stringify(local) === JSON.stringify(base) ? remote : local;
}

function isRevisionConflict(error: unknown) {
  return Boolean(
    error &&
      typeof error === 'object' &&
      'status' in error &&
      error.status === 409,
  );
}

export function mergeSnapshots(
  local: PracticeSnapshot,
  remote: PracticeSnapshot,
  base?: PracticeSnapshot,
): PracticeSnapshot {
  return {
    version: 1,
    focus: {
      apps: changedChoice(local.focus.apps, remote.focus.apps, base?.focus.apps),
      sessions: mergeSessions(local.focus.sessions, remote.focus.sessions),
      overrideEvents: unionStrings(local.focus.overrideEvents, remote.focus.overrideEvents),
      pendingReflectionId: changedChoice(
        local.focus.pendingReflectionId,
        remote.focus.pendingReflectionId,
        base?.focus.pendingReflectionId,
      ),
      stasisTokens: mergeCounter(
        local.focus.stasisTokens,
        remote.focus.stasisTokens,
        base?.focus.stasisTokens,
      ),
      protectedDateKeys: unionStrings(
        local.focus.protectedDateKeys,
        remote.focus.protectedDateKeys,
      ),
    },
    rewards: {
      rewardClaimKeys: unionStrings(local.rewards.rewardClaimKeys ?? [], remote.rewards.rewardClaimKeys ?? []),
      leaves: Math.max(0, mergeCounter(
        local.rewards.leaves,
        remote.rewards.leaves,
        base?.rewards.leaves,
      ) - (base ? duplicateClaimLeaves(
        local.rewards.rewardClaimKeys ?? [],
        remote.rewards.rewardClaimKeys ?? [],
        base.rewards.rewardClaimKeys ?? [],
      ) : 0)),
      mindfulMinutes: mergeCounter(
        local.rewards.mindfulMinutes,
        remote.rewards.mindfulMinutes,
        base?.rewards.mindfulMinutes,
      ),
      unlockedRewards: unionStrings(
        local.rewards.unlockedRewards,
        remote.rewards.unlockedRewards,
      ),
      equipped: {
        breath: changedChoice(
          local.rewards.equipped.breath,
          remote.rewards.equipped.breath,
          base?.rewards.equipped.breath,
        ),
        roast: changedChoice(
          local.rewards.equipped.roast,
          remote.rewards.equipped.roast,
          base?.rewards.equipped.roast,
        ),
      },
      stillnessEvents: unionStrings(
        local.rewards.stillnessEvents,
        remote.rewards.stillnessEvents,
      ),
      ownedCollectibles: unionStrings(
        local.rewards.ownedCollectibles,
        remote.rewards.ownedCollectibles,
      ) as RewardsSyncSnapshot['ownedCollectibles'],
      selectedCollectible: changedChoice(
        local.rewards.selectedCollectible,
        remote.rewards.selectedCollectible,
        base?.rewards.selectedCollectible,
      ),
      soundscape: changedChoice(
        local.rewards.soundscape,
        remote.rewards.soundscape,
        base?.rewards.soundscape,
      ),
    },
  };
}

export function mergeInitialSnapshot(
  local: PracticeSnapshot,
  remote: PracticeSnapshot | null,
  base: PracticeSnapshot | undefined,
  hasUnsyncedLocalChanges: boolean,
) {
  if (!remote) return local;
  if (base) return mergeSnapshots(local, remote, base);
  if (hasUnsyncedLocalChanges) {
    return mergeSnapshots(local, remote, DEFAULT_SNAPSHOT);
  }
  return remote;
}

function decodeSnapshot(value: unknown): PracticeSnapshot | null {
  if (!value) return null;
  const parsed = SavePracticeBody.shape.snapshot.safeParse(value);
  return parsed.success ? (parsed.data as PracticeSnapshot) : null;
}

function decodeMeta(raw: string | null): SyncMeta | null {
  if (!raw) return null;
  try {
    const value = JSON.parse(raw) as Partial<SyncMeta>;
    const snapshot = decodeSnapshot(value.snapshot);
    return Number.isInteger(value.revision) && (value.revision ?? -1) >= 0 && snapshot
      ? { revision: value.revision!, snapshot }
      : null;
  } catch {
    return null;
  }
}

function wait(milliseconds: number) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

type PendingClaim = {
  claimKey: string;
  resolve: (result: ClaimStatus) => void;
  reject: (error: Error) => void;
};

export function PracticeSyncBridge({ children }: { children: React.ReactNode }) {
  const { getToken, isLoaded, isSignedIn, userId } = useAuth();
  const focus = useFocus();
  const rewards = useRewards();
  const ready = isLoaded && focus.hydrated && rewards.hydrated;
  const [claimReadyUser, setClaimReadyUser] = useState<string | null>(null);
  const pendingClaims = useRef<PendingClaim[]>([]);
  const claimReady = Boolean(ready && isSignedIn && userId && claimReadyUser === userId);
  const requestClaim = useCallback((claimKey: string): Promise<ClaimStatus> => {
    if (!claimReady) return Promise.reject(new Error('Your practice is still syncing. Connect to the internet and try again shortly.'));
    return new Promise((resolve, reject) => {
      const claim: PendingClaim = {
        claimKey,
        resolve: (result) => { clearTimeout(timeout); resolve(result); },
        reject: (error) => { clearTimeout(timeout); reject(error); },
      };
      const timeout = setTimeout(() => {
        pendingClaims.current = pendingClaims.current.filter((item) => item !== claim);
        reject(new Error('The claim could not be confirmed yet. Reconnect and check your rewards before trying again.'));
      }, 25000);
      pendingClaims.current.push(claim);
    });
  }, [claimReady]);
  const latestSnapshot = useRef<PracticeSnapshot>({
    version: 1,
    focus: focus.syncSnapshot,
    rewards: rewards.syncSnapshot,
  });
  const latestSerialized = useRef(JSON.stringify(latestSnapshot.current));
  const applyFocus = useRef(focus.applySyncedSnapshot);
  const applyRewards = useRef(rewards.applySyncedSnapshot);

  latestSnapshot.current = {
    version: 1,
    focus: focus.syncSnapshot,
    rewards: rewards.syncSnapshot,
  };
  latestSerialized.current = JSON.stringify(latestSnapshot.current);
  applyFocus.current = focus.applySyncedSnapshot;
  applyRewards.current = rewards.applySyncedSnapshot;

  useEffect(() => {
    setClaimReadyUser(null);
    if (!isLoaded || !isSignedIn || !userId || !ready) return;

    let stopped = false;
    let initialized = false;
    let revision = 0;
    let baseline: PracticeSnapshot | undefined;
    let lastSaved = '';
    let retryDelay = 1000;
    let nextPullAt = Date.now() + 15000;
    let activeClaim: PendingClaim | undefined;
    const metaKey = `${META_KEY_PREFIX}:${userId}`;
    const dirtyKey = practiceDirtyKey(userId);
    const appStateSubscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') nextPullAt = 0;
    });

    const requestOptions = async () => {
      const token = await getToken();
      if (!token) throw new Error('A Clerk session token is required to sync.');
      return { headers: { Authorization: `Bearer ${token}` } };
    };

    const applySnapshot = (next: PracticeSnapshot) => {
      if (stopped) return;
      latestSnapshot.current = next;
      latestSerialized.current = JSON.stringify(next);
      applyFocus.current(next.focus);
      applyRewards.current(next.rewards);
    };

    const saveWithConflicts = async (
      first: PracticeSnapshot,
      expectedRevision: number,
      mergeBase?: PracticeSnapshot,
    ) => {
      let next = first;
      let expected = expectedRevision;
      let base = mergeBase;

      for (let attempt = 0; attempt < 3; attempt += 1) {
        if (stopped) throw new Error('Practice sync stopped.');
        const request = await requestOptions();
        try {
          const saved = await savePractice(
            { expectedRevision: expected, snapshot: next },
            request,
          );
          const acknowledged = decodeSnapshot(saved.snapshot);
          if (!acknowledged) throw new Error('Invalid saved practice snapshot.');
          if (JSON.stringify(acknowledged) !== JSON.stringify(next)) {
            applySnapshot(mergeSnapshots(latestSnapshot.current, acknowledged, next));
          }
          return { saved, snapshot: acknowledged };
        } catch (error) {
          if (!isRevisionConflict(error)) throw error;
          const current = await getPractice(request);
          const remote = decodeSnapshot(current.snapshot);
          if (current.snapshot && !remote) throw new Error('Invalid practice snapshot returned.');
          next = remote
            ? mergeSnapshots(latestSnapshot.current, remote, base)
            : latestSnapshot.current;
          expected = current.revision;
          base = remote ?? base;
          applySnapshot(next);
        }
      }
      throw new Error('Practice changed too many times while syncing.');
    };

    const run = async () => {
      while (!stopped) {
        try {
          if (!initialized) {
            const [storedMeta, dirtyValue] = await Promise.all([
              AsyncStorage.getItem(metaKey),
              AsyncStorage.getItem(dirtyKey),
            ]);
            const meta = decodeMeta(storedMeta);
            const hasUnsyncedLocalChanges = dirtyValue === '1';
            const capturedLocal = latestSnapshot.current;
            const request = await requestOptions();
            const current = await getPractice(request);
            if (stopped) return;
            const remote = decodeSnapshot(current.snapshot);
            if (current.snapshot && !remote) throw new Error('Invalid practice snapshot returned.');

            let merged = mergeInitialSnapshot(
              capturedLocal,
              remote,
              meta?.snapshot,
              hasUnsyncedLocalChanges,
            );
            merged = mergeSnapshots(latestSnapshot.current, merged, capturedLocal);
            applySnapshot(merged);

            const result = await saveWithConflicts(merged, current.revision, remote ?? meta?.snapshot);
            if (stopped) return;
            revision = result.saved.revision;
            baseline = result.snapshot;
            lastSaved = JSON.stringify(result.snapshot);
            await AsyncStorage.multiSet([
              [metaKey, JSON.stringify({ revision, snapshot: result.snapshot })],
              [dirtyKey, '0'],
            ]);
            initialized = true;
            setClaimReadyUser(userId);
            nextPullAt = Date.now() + 15000;
          } else if (latestSerialized.current !== lastSaved) {
            const candidate = latestSnapshot.current;
            const result = await saveWithConflicts(candidate, revision, baseline);
            if (stopped) return;
            revision = result.saved.revision;
            baseline = result.snapshot;
            lastSaved = JSON.stringify(result.snapshot);
            await AsyncStorage.multiSet([
              [metaKey, JSON.stringify({ revision, snapshot: result.snapshot })],
              [dirtyKey, '0'],
            ]);
            nextPullAt = Date.now() + 15000;
          } else if (pendingClaims.current.length) {
            activeClaim = pendingClaims.current.shift();
            if (!activeClaim) continue;
            const capturedLocal = latestSnapshot.current;
            const abort = new AbortController();
            const timeout = setTimeout(() => abort.abort(), 20000);
            try {
              const request = await requestOptions();
              const result = await claimPracticeReward({
                expectedRevision: revision,
                claimKey: activeClaim.claimKey,
                timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
              }, { ...request, signal: abort.signal });
              if (stopped) return;
              const remote = decodeSnapshot(result.practice.snapshot);
              if (!remote) throw new Error('Invalid reward response. Please sync and try again.');
              const merged = mergeSnapshots(latestSnapshot.current, remote, capturedLocal);
              applySnapshot(merged);
              revision = result.practice.revision;
              baseline = remote;
              lastSaved = JSON.stringify(remote);
              await AsyncStorage.multiSet([
                [metaKey, JSON.stringify({ revision, snapshot: remote })],
                [dirtyKey, JSON.stringify(merged) === lastSaved ? '0' : '1'],
              ]);
              activeClaim.resolve(result.status);
            } catch (error) {
              nextPullAt = 0;
              activeClaim.reject(new Error(isRevisionConflict(error)
                ? 'Your rewards changed on another device. Syncing now — please try again.'
                : error instanceof Error ? error.message : 'Could not claim the reward. Please try again online.'));
            } finally {
              clearTimeout(timeout);
              activeClaim = undefined;
            }
          } else if (Date.now() >= nextPullAt) {
            const capturedLocal = latestSnapshot.current;
            const request = await requestOptions();
            const current = await getPractice(request);
            if (stopped) return;

            if (current.revision > revision) {
              const remote = decodeSnapshot(current.snapshot);
              if (!remote) throw new Error('Invalid practice snapshot returned.');
              let merged = mergeSnapshots(capturedLocal, remote, baseline);
              merged = mergeSnapshots(latestSnapshot.current, merged, capturedLocal);
              applySnapshot(merged);

              if (JSON.stringify(merged) === JSON.stringify(remote)) {
                revision = current.revision;
                baseline = remote;
                lastSaved = JSON.stringify(remote);
                await AsyncStorage.multiSet([
                  [metaKey, JSON.stringify({ revision, snapshot: remote })],
                  [dirtyKey, '0'],
                ]);
              } else {
                const result = await saveWithConflicts(merged, current.revision, remote);
                if (stopped) return;
                revision = result.saved.revision;
                baseline = result.snapshot;
                lastSaved = JSON.stringify(result.snapshot);
                await AsyncStorage.multiSet([
                  [metaKey, JSON.stringify({ revision, snapshot: result.snapshot })],
                  [dirtyKey, '0'],
                ]);
              }
            }
            nextPullAt = Date.now() + 15000;
          }
          retryDelay = 1000;
          if (!stopped && initialized) setClaimReadyUser(userId);
          await wait(800);
        } catch (error) {
          if (stopped) return;
          setClaimReadyUser(null);
          for (const claim of pendingClaims.current.splice(0)) {
            claim.reject(new Error('Could not sync your practice. Check your connection and try claiming again.'));
          }
          console.warn('Practice sync will retry.', error);
          await wait(retryDelay);
          retryDelay = Math.min(retryDelay * 2, 30000);
        }
      }
    };

    void run();
    return () => {
      stopped = true;
      activeClaim?.reject(new Error('Account changed before the claim finished. Check your rewards after syncing.'));
      for (const claim of pendingClaims.current.splice(0)) claim.reject(new Error('Practice sync stopped. Please try again.'));
      appStateSubscription.remove();
    };
  }, [getToken, isLoaded, isSignedIn, ready, userId]);

  return <PracticeClaimsContext.Provider value={{ ready: claimReady, requestClaim }}>{children}</PracticeClaimsContext.Provider>;
}
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '@clerk/expo';
import { Feather } from '@expo/vector-icons';
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { useColors } from '@/hooks/useColors';

const STORAGE_PREFIX = 'focus-compass-reminder-apps-v1';
const PRESET_APPS = ['Instagram', 'TikTok', 'YouTube', 'Reddit', 'X', 'Snapchat'] as const;

type ReminderPreferences = {
  selectedPresets: string[];
  customNames: string[];
};

type LoadStatus = 'loading' | 'ready' | 'error';

const emptyPreferences: ReminderPreferences = {
  selectedPresets: [],
  customNames: [],
};

function normalizedName(value: string) {
  return value.trim().replace(/\s+/g, ' ');
}

function parsePreferences(raw: string | null): ReminderPreferences {
  if (raw === null) return emptyPreferences;
  const parsed: unknown = JSON.parse(raw);
  if (!parsed || typeof parsed !== 'object') throw new Error('Invalid reminder preferences');

  const selectedPresets = (parsed as Partial<ReminderPreferences>).selectedPresets;
  const customNames = (parsed as Partial<ReminderPreferences>).customNames;
  if (
    !Array.isArray(selectedPresets) ||
    !selectedPresets.every((name) => typeof name === 'string') ||
    !Array.isArray(customNames) ||
    !customNames.every((name) => typeof name === 'string')
  ) {
    throw new Error('Invalid reminder preferences');
  }

  const validPresets = new Set<string>(PRESET_APPS);
  const uniqueCustomNames: string[] = [];
  const seenNames = new Set(PRESET_APPS.map((name) => name.toLocaleLowerCase()));
  for (const value of customNames) {
    const name = normalizedName(value);
    const key = name.toLocaleLowerCase();
    if (name && !seenNames.has(key)) {
      seenNames.add(key);
      uniqueCustomNames.push(name);
    }
  }

  return {
    selectedPresets: [...new Set(selectedPresets.filter((name) => validPresets.has(name)))],
    customNames: uniqueCustomNames,
  };
}

export function ReminderAppList() {
  const colors = useColors();
  const { isLoaded: isAuthLoaded, userId } = useAuth();
  const scope = useMemo(
    () => (isAuthLoaded ? (userId ? `user:${userId}` : 'guest') : null),
    [isAuthLoaded, userId],
  );
  const [preferences, setPreferences] = useState<ReminderPreferences>(emptyPreferences);
  const [customName, setCustomName] = useState('');
  const [status, setStatus] = useState<LoadStatus>('loading');
  const [statusScope, setStatusScope] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [saveFailed, setSaveFailed] = useState(false);
  const [refreshCount, setRefreshCount] = useState(0);
  const preferencesRef = useRef<ReminderPreferences>(emptyPreferences);
  const writeQueue = useRef<Promise<void>>(Promise.resolve());
  const saveSequence = useRef(0);
  const activeScope = useRef(scope);
  activeScope.current = scope;

  useEffect(() => {
    let cancelled = false;
    setStatusScope(scope);
    setStatus('loading');
    setMessage('');
    setSaveFailed(false);
    preferencesRef.current = emptyPreferences;
    setPreferences(emptyPreferences);
    setCustomName('');
    if (!scope) return () => { cancelled = true; };

    AsyncStorage.getItem(`${STORAGE_PREFIX}:${scope}`)
      .then((raw) => {
        if (cancelled) return;
        const restored = parsePreferences(raw);
        preferencesRef.current = restored;
        setPreferences(restored);
        setStatus('ready');
      })
      .catch(() => {
        if (cancelled) return;
        setStatus('error');
        setMessage('Your reminder list could not be loaded. Try again before making changes.');
      });

    return () => {
      cancelled = true;
    };
  }, [refreshCount, scope]);

  const savePreferences = useCallback((next: ReminderPreferences) => {
    if (!scope) return;
    preferencesRef.current = next;
    setPreferences(next);
    setSaveFailed(false);
    setMessage('Saving…');
    const targetScope = scope;
    const sequence = ++saveSequence.current;
    writeQueue.current = writeQueue.current
      .catch(() => undefined)
      .then(() => AsyncStorage.setItem(`${STORAGE_PREFIX}:${targetScope}`, JSON.stringify(next)))
      .then(() => {
        if (activeScope.current === targetScope && saveSequence.current === sequence) setMessage('');
      })
      .catch(() => {
        if (activeScope.current === targetScope && saveSequence.current === sequence) {
          setSaveFailed(true);
          setMessage('Your changes could not be saved. Try saving again.');
        }
      });
  }, [scope]);

  const togglePreset = (name: string) => {
    if (status !== 'ready') return;
    const current = preferencesRef.current;
    const selectedPresets = current.selectedPresets.includes(name)
      ? current.selectedPresets.filter((item) => item !== name)
      : [...current.selectedPresets, name];
    savePreferences({ ...current, selectedPresets });
  };

  const addCustomName = () => {
    if (status !== 'ready') return;
    const name = normalizedName(customName);
    if (!name) {
      setMessage('Enter an app name first.');
      return;
    }
    const key = name.toLocaleLowerCase();
    const current = preferencesRef.current;
    const isDuplicate = [...PRESET_APPS, ...current.customNames]
      .some((item) => item.toLocaleLowerCase() === key);
    if (isDuplicate) {
      setMessage('That app is already in your reminder list.');
      return;
    }
    setCustomName('');
    savePreferences({ ...current, customNames: [...current.customNames, name] });
  };

  const removeCustomName = (name: string) => {
    if (status !== 'ready') return;
    const current = preferencesRef.current;
    savePreferences({
      ...current,
      customNames: current.customNames.filter((item) => item !== name),
    });
  };

  const currentStatus = statusScope === scope ? status : 'loading';
  const disabled = currentStatus !== 'ready';

  return (
    <View>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Apps to avoid</Text>
      <Text style={[styles.sectionBody, { color: colors.mutedForeground }]}>
        Choose apps that tend to pull you off course. This is a personal reminder list only—Focus Compass cannot detect or block these apps.
      </Text>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.label, { color: colors.foreground }]}>COMMON DISTRACTIONS</Text>
        <View style={styles.presetGrid}>
          {PRESET_APPS.map((name) => {
            const selected = preferences.selectedPresets.includes(name);
            return (
              <Pressable
                key={name}
                testID={`reminder-preset-${name.toLocaleLowerCase()}`}
                accessibilityRole="checkbox"
                accessibilityState={{ checked: selected, disabled }}
                disabled={disabled}
                onPress={() => togglePreset(name)}
                style={({ pressed }) => [
                  styles.preset,
                  {
                    backgroundColor: selected ? colors.deepBackground : colors.background,
                    borderColor: selected ? colors.deepBackground : colors.border,
                  },
                  pressed && styles.pressed,
                  disabled && styles.disabled,
                ]}
              >
                <Feather
                  name={selected ? 'check-circle' : 'circle'}
                  size={17}
                  color={selected ? colors.deepForeground : colors.mutedForeground}
                />
                <Text
                  style={[
                    styles.presetText,
                    { color: selected ? colors.deepForeground : colors.foreground },
                  ]}
                >
                  {name}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <Text style={[styles.label, styles.customLabel, { color: colors.foreground }]}>ADD ANOTHER APP</Text>
        <View style={styles.addRow}>
          <TextInput
            testID="custom-reminder-app-input"
            accessibilityLabel="Custom app name"
            editable={!disabled}
            value={customName}
            onChangeText={setCustomName}
            onSubmitEditing={addCustomName}
            placeholder="App name"
            placeholderTextColor={colors.mutedForeground}
            returnKeyType="done"
            style={[
              styles.input,
              { backgroundColor: colors.background, borderColor: colors.input, color: colors.foreground },
              disabled && styles.disabled,
            ]}
          />
          <Pressable
            testID="add-custom-reminder-app"
            accessibilityRole="button"
            accessibilityLabel="Add app reminder"
            disabled={disabled}
            onPress={addCustomName}
            style={({ pressed }) => [
              styles.addButton,
              { backgroundColor: colors.primary },
              pressed && styles.pressed,
              disabled && styles.disabled,
            ]}
          >
            <Feather name="plus" size={21} color={colors.primaryForeground} />
          </Pressable>
        </View>

        {preferences.customNames.map((name) => (
          <View key={name.toLocaleLowerCase()} style={[styles.customRow, { borderTopColor: colors.border }]}>
            <Text style={[styles.customName, { color: colors.foreground }]}>{name}</Text>
            <Pressable
              testID={`remove-custom-reminder-${name.toLocaleLowerCase()}`}
              accessibilityRole="button"
              accessibilityLabel={`Remove ${name}`}
              disabled={disabled}
              onPress={() => removeCustomName(name)}
              hitSlop={10}
            >
              <Feather name="x" size={20} color={colors.destructive} />
            </Pressable>
          </View>
        ))}

        {currentStatus === 'loading' ? (
          <Text style={[styles.message, { color: colors.mutedForeground }]}>Loading your reminder list…</Text>
        ) : null}
        {message ? (
          <View style={[styles.messageRow, { backgroundColor: colors.secondary }]}>
            <Feather name="info" size={16} color={colors.secondaryForeground} />
            <Text style={[styles.messageText, { color: colors.secondaryForeground }]}>{message}</Text>
          </View>
        ) : null}
        {currentStatus === 'error' ? (
          <Pressable
            testID="retry-reminder-apps"
            accessibilityRole="button"
            onPress={() => setRefreshCount((count) => count + 1)}
          >
            <Text style={[styles.retryText, { color: colors.primary }]}>Try loading again</Text>
          </Pressable>
        ) : null}
        {saveFailed && currentStatus === 'ready' ? (
          <Pressable
            testID="retry-save-reminder-apps"
            accessibilityRole="button"
            onPress={() => savePreferences(preferencesRef.current)}
          >
            <Text style={[styles.retryText, { color: colors.primary }]}>Try saving again</Text>
          </Pressable>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, marginBottom: 7 },
  sectionBody: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21, marginBottom: 11 },
  card: { borderRadius: 22, borderWidth: 1, padding: 14 },
  label: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.8, marginBottom: 10 },
  presetGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  preset: { minHeight: 40, borderRadius: 13, borderWidth: 1, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', gap: 7 },
  presetText: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  customLabel: { marginTop: 18 },
  addRow: { flexDirection: 'row', gap: 9 },
  input: { flex: 1, minHeight: 48, borderRadius: 14, borderWidth: 1, paddingHorizontal: 13, fontFamily: 'Inter_500Medium', fontSize: 15 },
  addButton: { width: 48, minHeight: 48, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  customRow: { minHeight: 44, borderTopWidth: 1, marginTop: 10, paddingTop: 10, flexDirection: 'row', alignItems: 'center' },
  customName: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 15 },
  message: { fontFamily: 'Inter_500Medium', fontSize: 13, marginTop: 12 },
  messageRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderRadius: 12, padding: 10, marginTop: 12 },
  messageText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 12, lineHeight: 18 },
  retryText: { alignSelf: 'flex-end', fontFamily: 'Inter_700Bold', fontSize: 13, paddingTop: 10 },
  pressed: { opacity: 0.72, transform: [{ scale: 0.99 }] },
  disabled: { opacity: 0.55 },
});
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';

export function StartupLoading({
  message,
  variant = 'screen',
}: {
  message: string;
  variant?: 'screen' | 'compact';
}) {
  const colors = useColors();
  const [slow, setSlow] = useState(false);
  useEffect(() => {
    const timer = setTimeout(() => setSlow(true), 15000);
    return () => clearTimeout(timer);
  }, []);

  if (variant === 'compact') {
    return (
      <View
        style={[styles.banner, { backgroundColor: colors.card, borderColor: colors.border }]}
      >
        <ActivityIndicator size="small" color={colors.primary} />
        <Text accessibilityLiveRegion="polite" style={[styles.bannerText, { color: colors.foreground }]}>
          {slow ? 'Sign-in services are still connecting…' : message}
        </Text>
      </View>
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: colors.background }]}>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={[styles.title, { color: colors.foreground }]}>Opening Focus Compass</Text>
      <Text accessibilityLiveRegion="polite" style={[styles.body, { color: colors.foreground }]}>
        {slow ? 'Startup is taking longer than expected. Check your connection and reload the preview.' : message}
      </Text>
      {slow && Platform.OS === 'web' && (
        <Pressable
          accessibilityRole="button"
          onPress={() => window.location.reload()}
          style={[styles.button, { backgroundColor: colors.primary }]}
        >
          <Text style={[styles.label, { color: colors.primaryForeground }]}>Reload preview</Text>
        </Pressable>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  bannerText: { flex: 1, fontSize: 13, lineHeight: 18 },
  screen: { flex: 1, minHeight: 300, alignItems: 'center', justifyContent: 'center', padding: 28, gap: 18 },
  title: { fontSize: 25, fontWeight: '700', textAlign: 'center' },
  body: { fontSize: 17, lineHeight: 25, textAlign: 'center', maxWidth: 360 },
  button: { borderRadius: 14, paddingVertical: 15, paddingHorizontal: 24 },
  label: { fontSize: 17, fontWeight: '700' },
});
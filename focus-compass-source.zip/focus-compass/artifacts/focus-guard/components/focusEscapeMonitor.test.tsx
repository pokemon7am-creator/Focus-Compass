import React from 'react';
import TestRenderer, { act } from 'react-test-renderer';

declare const require: (moduleName: string) => {
  _load: (request: string, parent: unknown, isMain: boolean) => unknown;
};

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

const nodeModule = require('node:module');
const originalLoad = nodeModule._load;
let appStateListener: ((state: string) => void) | undefined;
let notificationListener: ((response: { notification: { request: { content: { data: { route: string } } } } }) => void) | undefined;
let blockedAppListener: ((attempt: { appId: string }) => void) | undefined;
let removed = false;
const pushedRoutes: string[] = [];
let pathname = '/guard';
const scheduledNotifications: { content: { data: { route: string } } }[] = [];
const frictionCheck = { required: false, selected: null as string | null, completed: false };
let clearedChecks = 0;

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean })
  .IS_REACT_ACT_ENVIRONMENT = true;

nodeModule._load = (request, parent, isMain) => {
  if (request === 'react-native') {
    return {
      AppState: {
        currentState: 'active',
        addEventListener: (_event: string, listener: (state: string) => void) => {
          appStateListener = listener;
          return { remove: () => { removed = true; } };
        },
      },
      Platform: { OS: 'ios' },
    };
  }
  if (request === 'expo-router') {
    return {
      router: { push: (route: string) => pushedRoutes.push(route) },
       usePathname: () => pathname,
    };
  }
  if (request === 'expo-notifications') {
    return {
      setNotificationHandler: () => undefined,
      getPermissionsAsync: async () => ({ status: 'granted' }),
      requestPermissionsAsync: async () => ({ status: 'granted' }),
       scheduleNotificationAsync: async (notification: { content: { data: { route: string } } }) => {
        scheduledNotifications.push(notification);
      },
       addNotificationResponseReceivedListener: (listener: typeof notificationListener) => {
         notificationListener = listener;
         return { remove: () => { notificationListener = undefined; } };
       },
      AndroidImportance: { HIGH: 'high' },
    };
  }
  if (request.endsWith('/context/FocusContext') || request === '@/context/FocusContext') {
    return {
      useFocus: () => ({
         apps: [{ id: 'instagram', active: true }],
        isRunning: true,
        hasActiveSession: true,
         frictionCheck,
         clearFrictionCheck: () => {
           clearedChecks += 1;
           frictionCheck.required = false;
           frictionCheck.selected = null;
         },
      }),
    };
  }
  if (request.endsWith('/services/appBlocking') || request === '@/services/appBlocking') {
    return {
       isSelectedAppAttempt: (selected: string, attempted: string) => selected === attempted,
       subscribeToBlockedAppAttempts: (listener: typeof blockedAppListener) => {
         blockedAppListener = listener;
         return () => { blockedAppListener = undefined; };
       },
    };
  }
  return originalLoad(request, parent, isMain);
};

async function flushEffects() {
  await new Promise<void>((resolve) => setTimeout(resolve, 0));
}

export async function runFocusEscapeMonitorTests() {
  try {
    const { FocusEscapeMonitor } = await import('./FocusEscapeMonitor');
    let renderer: TestRenderer.ReactTestRenderer;
    await act(async () => {
      renderer = TestRenderer.create(React.createElement(FocusEscapeMonitor));
      await flushEffects();
    });
    assert(appStateListener !== undefined, 'native monitor should subscribe to AppState changes');

    frictionCheck.required = true;
    frictionCheck.selected = 'physical';
    await act(async () => {
      appStateListener?.('background');
      await flushEffects();
    });
    assert(
      scheduledNotifications.length === 1,
      'leaving the app during a running focus session should notify once',
    );
    assert(
      scheduledNotifications[0]?.content.data.route === '/roast?mode=app-switch',
      'off-track notification must open roast, not selectable friction',
    );
    assert(pushedRoutes.length === 0, 'leaving the app should not navigate immediately');

    await act(async () => {
      appStateListener?.('active');
      await flushEffects();
    });
    const pushedRoute = pushedRoutes.at(0);
    assert(
      Number(pushedRoutes.length) === 1 && pushedRoute === '/roast?mode=app-switch',
      'returning to the app should trigger only the roast',
    );
    assert(clearedChecks === 1, 'previously selected friction must be cleared');

    pathname = '/roast';
    await act(async () => {
      renderer.update(React.createElement(FocusEscapeMonitor));
    });
    await act(async () => {
      blockedAppListener?.({ appId: 'instagram' });
      await flushEffects();
    });
    assert(Number(pushedRoutes.length) === 1, 'duplicate attempts while the roast is open must not stack routes');

    pathname = '/guard';
    await act(async () => {
      renderer.update(React.createElement(FocusEscapeMonitor));
    });
    await act(async () => {
      blockedAppListener?.({ appId: 'instagram' });
      await flushEffects();
    });
    assert(Number(pushedRoutes.length) === 2, 'a distinct second incident must open another roast');
    assert(pushedRoutes.at(-1) === '/roast?mode=app-switch', 'selected native app attempts must open roast');
    assert(scheduledNotifications.at(-1)?.content.data.route === '/roast?mode=app-switch', 'native attempt notification must open roast');

    pathname = '/roast';
    await act(async () => {
      renderer.update(React.createElement(FocusEscapeMonitor));
    });
    pathname = '/guard';
    await act(async () => {
      renderer.update(React.createElement(FocusEscapeMonitor));
    });
    await act(async () => {
      notificationListener?.({ notification: { request: { content: { data: { route: '/friction?mode=app-switch' } } } } });
      await flushEffects();
    });
    assert(Number(pushedRoutes.length) === 3, 'another incident may open a roast on the same day');
    assert(pushedRoutes.at(-1) === '/roast?mode=app-switch', 'old friction notifications must open roast');
    assert(Number(clearedChecks) === 3, 'automatic routes must clear old friction selections');

    await act(async () => {
      renderer.unmount();
      await flushEffects();
    });
    assert(removed, 'native monitor should remove its AppState subscription on unmount');
  } finally {
    nodeModule._load = originalLoad;
  }
}

if (process.argv[1]?.endsWith('focusEscapeMonitor.test.tsx')) {
  runFocusEscapeMonitorTests().catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  });
}
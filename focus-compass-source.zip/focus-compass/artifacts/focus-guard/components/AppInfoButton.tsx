import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Modal, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export function AppInfoButton() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [visible, setVisible] = useState(false);
  const bottom = Platform.OS === 'web' ? 98 : insets.bottom + 86;

  return (
    <>
      <Pressable
        testID="app-guide-button"
        accessibilityRole="button"
        accessibilityLabel="Open Focus Compass guide"
        onPress={() => setVisible(true)}
        style={({ pressed }) => [
          styles.floatingButton,
          { right: 18, bottom, backgroundColor: colors.primary, borderColor: colors.primary },
          pressed && styles.pressed,
        ]}
      >
        <Feather name="info" size={18} color={colors.primaryForeground} />
        <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>Guide</Text>
      </Pressable>

      <Modal
        visible={visible}
        transparent
        animationType="fade"
        onRequestClose={() => setVisible(false)}
      >
        <View style={styles.overlay}>
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={styles.cardHeader}>
              <View style={[styles.iconBubble, { backgroundColor: colors.secondary }]}>
                <Feather name="info" size={20} color={colors.primary} />
              </View>
              <Text style={[styles.title, { color: colors.foreground }]}>Focus Compass guide</Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Close guide"
                onPress={() => setVisible(false)}
                style={({ pressed }) => [styles.closeButton, pressed && styles.pressed]}
              >
                <Feather name="x" size={21} color={colors.mutedForeground} />
              </Pressable>
            </View>

            <Text style={[styles.body, { color: colors.mutedForeground }]}>
              Breathe comfortably and use the focus tools at your own pace. Stop any breathing exercise if you feel lightheaded or uncomfortable.
            </Text>

            <Pressable
              accessibilityRole="button"
              accessibilityLabel="Open Terms of Use"
              onPress={() => {
                setVisible(false);
                router.push('/terms');
              }}
              style={({ pressed }) => [
                styles.termsButton,
                { borderColor: colors.border, backgroundColor: colors.secondary },
                pressed && styles.pressed,
              ]}
            >
              <View style={styles.termsCopy}>
                <Text style={[styles.termsTitle, { color: colors.foreground }]}>Terms of Use</Text>
                <Text style={[styles.termsSubtitle, { color: colors.mutedForeground }]}>
                  Read how Focus Compass works and what to expect.
                </Text>
              </View>
              <Feather name="chevron-right" size={19} color={colors.primary} />
            </Pressable>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  floatingButton: {
    position: 'absolute',
    minWidth: 78,
    height: 48,
    borderRadius: 16,
    borderWidth: 1.5,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    zIndex: 50,
    elevation: 12,
    shadowColor: '#000',
    shadowOpacity: 0.18,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  buttonText: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.45)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  card: { width: '100%', maxWidth: 380, borderWidth: 1, borderRadius: 22, padding: 18, gap: 15 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  iconBubble: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  title: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 19 },
  closeButton: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  body: { fontFamily: 'Inter_500Medium', fontSize: 15, lineHeight: 23 },
  termsButton: {
    borderWidth: 1,
    borderRadius: 16,
    padding: 13,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  termsCopy: { flex: 1, gap: 3 },
  termsTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  termsSubtitle: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 18 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.985 }] },
});
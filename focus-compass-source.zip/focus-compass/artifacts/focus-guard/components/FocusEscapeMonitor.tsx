import { router, usePathname } from 'expo-router';
import * as Notifications from 'expo-notifications';
import React, { useEffect, useRef } from 'react';
import { AppState, type AppStateStatus, Platform } from 'react-native';
import { useFocus } from '@/context/FocusContext';
import {
  isSelectedAppAttempt,
  subscribeToBlockedAppAttempts,
} from '@/services/appBlocking';

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: false,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

export function FocusEscapeMonitor() {
  const focus = useFocus();
  const pathname = usePathname();
  const canNotify = useRef(false);
  const notificationSetup = useRef<Promise<boolean> | null>(null);
  const appState = useRef<AppStateStatus>(AppState.currentState);
  const roastPending = useRef(false);
  const roastNavigationPending = useRef(false);

  // A route push can take a render to update pathname. Ignore duplicate native
  // callbacks in that gap, but allow another incident after leaving the roast.
  const openRoast = () => {
    if (pathname === '/roast' || roastNavigationPending.current) return;
    roastNavigationPending.current = true;
    router.push('/roast?mode=app-switch');
  };

  useEffect(() => {
    if (pathname === '/roast') roastNavigationPending.current = false;
  }, [pathname]);

  const sendFocusNotification = async (title: string, body: string) => {
    if (Platform.OS === 'web') return;
    const granted = canNotify.current || (await notificationSetup.current);
    if (!granted) return;
    await Notifications.scheduleNotificationAsync({
      content: {
        title,
        body,
        sound: 'default',
        data: { route: '/roast?mode=app-switch' },
      },
      trigger: null,
    });
  };

  useEffect(() => {
    if (Platform.OS === 'web') return;

    const prepareNotifications = async () => {
      if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('focus-alerts', {
          name: 'Focus alerts',
          importance: Notifications.AndroidImportance.HIGH,
          sound: 'default',
          vibrationPattern: [0, 250, 150, 250],
        });
      }

      const current = await Notifications.getPermissionsAsync();
      const permission =
        current.status === 'granted' ? current : await Notifications.requestPermissionsAsync();
      const granted = permission.status === 'granted';
      canNotify.current = granted;
      return granted;
    };

    notificationSetup.current = prepareNotifications().catch(() => {
      canNotify.current = false;
      return false;
    });

    return () => {
      notificationSetup.current = null;
    };
  }, []);

  useEffect(() => {
    if (Platform.OS === 'web') return;

    const subscription = AppState.addEventListener('change', (nextState) => {
      const previousState = appState.current;
      appState.current = nextState;
      const leavingFlow =
        previousState === 'active' &&
        (nextState === 'inactive' || nextState === 'background');
      const returningToFlow =
        nextState === 'active' &&
        (previousState === 'inactive' || previousState === 'background');

      if (leavingFlow && focus.isRunning && focus.hasActiveSession && pathname !== '/roast') {
        focus.clearFrictionCheck();
        roastPending.current = true;
        void sendFocusNotification(
          'Your Focus Compass session is still active',
          'Return to Focus Compass for your off-track reality check.',
        ).catch(() => undefined);
      }

      if (returningToFlow && roastPending.current) {
        roastPending.current = false;
        if (focus.isRunning && focus.hasActiveSession) openRoast();
      }
    });

    return () => subscription.remove();
  }, [focus.clearFrictionCheck, focus.hasActiveSession, focus.isRunning, pathname]);

  useEffect(() => {
    if (Platform.OS === 'web') return;
    const subscription = Notifications.addNotificationResponseReceivedListener((response) => {
      const route = response.notification.request.content.data?.route;
      if ((route === '/roast?mode=app-switch' || route === '/friction?mode=app-switch') && focus.isRunning && focus.hasActiveSession) {
        roastPending.current = false;
        focus.clearFrictionCheck();
        openRoast();
      }
    });
    return () => subscription.remove();
  }, [focus.clearFrictionCheck, focus.hasActiveSession, focus.isRunning, pathname]);

  useEffect(() => {
    return subscribeToBlockedAppAttempts(({ appId }) => {
      const isSelected = focus.apps.some(
        (app) => app.active && isSelectedAppAttempt(app.id, appId),
      );
      if (!focus.isRunning || !focus.hasActiveSession || !isSelected ||
          pathname === '/roast' || roastNavigationPending.current) return;

      focus.clearFrictionCheck();
      roastPending.current = false;
      void sendFocusNotification(
        'Focus Compass blocked a selected app',
        'That app is on your Guard list. Return to Focus Compass and keep your focus session moving.',
      ).catch(() => undefined);
      openRoast();
    });
  }, [focus.apps, focus.clearFrictionCheck, focus.hasActiveSession, focus.isRunning, pathname]);

  useEffect(() => {
    if (
      !focus.frictionCheck.required ||
      focus.frictionCheck.completed ||
      pathname === '/roast' ||
      pathname === '/friction' ||
      pathname === '/challenge'
    ) {
      return;
    }
    focus.clearFrictionCheck();
    openRoast();
  }, [
    focus.frictionCheck.completed,
    focus.frictionCheck.required,
    focus.clearFrictionCheck,
    pathname,
  ]);

  return null;
}
/** @type {import('@bacons/apple-targets/app.plugin').Config} */
module.exports = {
  type: 'device-activity-monitor',
  name: 'SpaceFocusMonitor',
  displayName: 'Space Focus Monitor',
  bundleIdentifier: '.focus-monitor',
  deploymentTarget: '16.4',
  frameworks: ['DeviceActivity', 'ManagedSettings'],
  entitlements: {
    'com.apple.developer.family-controls': true,
  },
};
import DeviceActivity
import ManagedSettings

final class SpaceFocusMonitorExtension: DeviceActivityMonitor {
  private let store = ManagedSettingsStore(named: .init("SpaceFocus"))

  override func intervalDidEnd(for activity: DeviceActivityName) {
    super.intervalDidEnd(for: activity)
    guard activity.rawValue == "SpaceFocus" else { return }
    store.clearAllSettings()
  }
}
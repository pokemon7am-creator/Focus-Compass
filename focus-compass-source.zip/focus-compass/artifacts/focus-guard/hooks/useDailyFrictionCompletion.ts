import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '@clerk/expo';
import { useFocusEffect } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AppState } from 'react-native';
import { useAuthRecovery } from '@/context/AuthRecoveryContext';
import {
  isCompletedForLocalDay,
  legacyFrictionWasCompletedOnDay,
  localCalendarDay,
} from '@/services/mathDaily';
import { OperationTimeoutError, withTimeout } from '@/services/asyncTimeout';

export type DailyFrictionKind = 'math' | 'physical';
export type DailyFrictionStatus = 'loading' | 'available' | 'completed' | 'error';

export const DAILY_FRICTION_KEY_PREFIXES: Record<DailyFrictionKind, string> = {
  math: 'zen-space-math-completion-day-v1',
  physical: 'zen-space-physical-completion-day-v1',
};

const LEGACY_COMPLETIONS_KEY = 'zen-space-physical-challenges-v1';
const AUTH_READY_TIMEOUT_MS = 10_000;
const STORAGE_READ_TIMEOUT_MS = 8_000;
type Listener = () => void;

const listeners = new Map<string, Set<Listener>>();
const pendingWrites = new Map<string, Promise<void>>();

function storageKey(kind: DailyFrictionKind, scope: string) {
  return `${DAILY_FRICTION_KEY_PREFIXES[kind]}:${scope}`;
}

function channel(kind: DailyFrictionKind, scope: string) {
  return `${kind}:${scope}`;
}

function notify(kind: DailyFrictionKind, scope: string) {
  listeners.get(channel(kind, scope))?.forEach((listener) => listener());
}

function subscribe(kind: DailyFrictionKind, scope: string, listener: Listener) {
  const key = channel(kind, scope);
  const scopedListeners = listeners.get(key) ?? new Set<Listener>();
  scopedListeners.add(listener);
  listeners.set(key, scopedListeners);
  return () => {
    scopedListeners.delete(listener);
    if (scopedListeners.size === 0) listeners.delete(key);
  };
}

function parseLegacyHistory(raw: string | null) {
  if (raw === null) return [];
  const parsed: unknown = JSON.parse(raw);
  if (!Array.isArray(parsed) || !parsed.every((item) => typeof item === 'string')) {
    throw new Error('Challenge history is not readable.');
  }
  return parsed;
}

async function readCompletionDay(kind: DailyFrictionKind, scope: string) {
  const key = storageKey(kind, scope);
  const storedDay = await AsyncStorage.getItem(key);
  if (storedDay !== null) return storedDay;

  // Legacy history is ownerless. Only the guest may inherit it; a signed-in
  // account must never be locked by activity from a previous device guest.
  if (scope === 'guest') {
    const history = parseLegacyHistory(await AsyncStorage.getItem(LEGACY_COMPLETIONS_KEY));
    const today = localCalendarDay();
    if (legacyFrictionWasCompletedOnDay(history, kind, today)) {
      await AsyncStorage.setItem(key, today);
      return today;
    }
  }
  return null;
}

export async function saveDailyFrictionCompletion(
  kind: DailyFrictionKind,
  scope: string,
  now = new Date(),
) {
  const writeKey = channel(kind, scope);
  const activeWrite = pendingWrites.get(writeKey);
  if (activeWrite) return activeWrite;

  const write = (async () => {
    const day = localCalendarDay(now);
    if ((await AsyncStorage.getItem(storageKey(kind, scope))) !== day) {
      await AsyncStorage.setItem(storageKey(kind, scope), day);
    }
    notify(kind, scope);
  })();

  pendingWrites.set(writeKey, write);
  try {
    await write;
  } finally {
    if (pendingWrites.get(writeKey) === write) pendingWrites.delete(writeKey);
  }
}

export function useDailyFrictionCompletion(kind: DailyFrictionKind) {
  const { isLoaded, userId } = useAuth();
  const retryAuth = useAuthRecovery();
  const scope = useMemo(
    () => (isLoaded ? (userId ? `user:${userId}` : 'guest') : null),
    [isLoaded, userId],
  );
  const [state, setState] = useState<{
    kind: DailyFrictionKind;
    scope: string | null;
    status: DailyFrictionStatus;
    error: string;
  }>({ kind, scope: null, status: 'loading', error: '' });
  const refreshSequence = useRef(0);

  const refresh = useCallback(async () => {
    const sequence = ++refreshSequence.current;
    if (!scope) return;
    try {
      const completionDay = await withTimeout(
        readCompletionDay(kind, scope),
        STORAGE_READ_TIMEOUT_MS,
        'Daily completion storage did not respond.',
      );
      if (sequence !== refreshSequence.current) return;
      setState({
        kind,
        scope,
        status: isCompletedForLocalDay(completionDay) ? 'completed' : 'available',
        error: '',
      });
    } catch (error) {
      if (sequence !== refreshSequence.current) return;
      const label = kind[0].toUpperCase() + kind.slice(1);
      setState({
        kind,
        scope,
        status: 'error',
        error: error instanceof OperationTimeoutError
          ? `${label} challenge status timed out on this device. Try again.`
          : `${label} challenge status could not be loaded. Try again.`,
      });
    }
  }, [kind, scope]);

  useEffect(() => {
    setState({ kind, scope, status: 'loading', error: '' });
    if (!scope) {
      if (isLoaded) return;
      const timer = setTimeout(() => {
        setState({
          kind,
          scope: null,
          status: 'error',
          error: 'Could not verify today’s status because sign-in services did not respond. Check your internet connection and try again.',
        });
      }, AUTH_READY_TIMEOUT_MS);
      return () => clearTimeout(timer);
    }
    void refresh();
    return subscribe(kind, scope, () => void refresh());
  }, [isLoaded, kind, refresh, scope]);

  useFocusEffect(useCallback(() => void refresh(), [refresh]));

  useEffect(() => {
    if (!scope) return;
    const appStateSubscription = AppState.addEventListener('change', (nextState) => {
      if (nextState === 'active') void refresh();
    });
    let midnightTimer: ReturnType<typeof setTimeout>;
    const scheduleMidnightRefresh = () => {
      const now = new Date();
      const nextMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      midnightTimer = setTimeout(() => {
        void refresh();
        scheduleMidnightRefresh();
      }, nextMidnight.getTime() - now.getTime() + 50);
    };
    scheduleMidnightRefresh();
    return () => {
      appStateSubscription.remove();
      clearTimeout(midnightTimer);
    };
  }, [refresh, scope]);

  const currentState =
    state.kind === kind && state.scope === scope
      ? state
      : { kind, scope, status: 'loading' as const, error: '' };

  const complete = useCallback(async () => {
    if (!scope || currentState.status !== 'available') {
      throw new Error(`${kind} challenge status is not ready.`);
    }
    await saveDailyFrictionCompletion(kind, scope);
    await refresh();
  }, [currentState.status, kind, refresh, scope]);

  const retry = useCallback(async () => {
    if (!scope) {
      setState({ kind, scope: null, status: 'loading', error: '' });
      retryAuth();
      return;
    }
    await refresh();
  }, [kind, refresh, retryAuth, scope]);

  return {
    status: currentState.status,
    error: currentState.error,
    refresh: retry,
    complete,
  };
}

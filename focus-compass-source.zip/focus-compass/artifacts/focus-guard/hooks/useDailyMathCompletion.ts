import {
  saveDailyFrictionCompletion,
  useDailyFrictionCompletion,
} from '@/hooks/useDailyFrictionCompletion';

/** Compatibility wrapper for existing math challenge consumers. */
export function useDailyMathCompletion() {
  return useDailyFrictionCompletion('math');
}

/** Compatibility wrapper preserving the existing scoped math save API. */
export function saveMathCompletion(scope: string, now = new Date()) {
  return saveDailyFrictionCompletion('math', scope, now);
}
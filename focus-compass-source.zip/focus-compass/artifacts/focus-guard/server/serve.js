/**
 * Standalone production server for Expo static builds.
 *
 * Serves the output of build.js (static-build/) with two special routes:
 * - GET / or /manifest with expo-platform header → platform manifest JSON
 * - GET / without expo-platform → landing page HTML
 * Everything else falls through to static file serving from ./static-build/.
 *
 * Zero external dependencies — uses only Node.js built-ins (http, fs, path).
 */

const http = require('http');
const fs = require('fs');
const path = require('path');

const STATIC_ROOT = path.resolve(__dirname, '..', 'static-build');
const CANONICAL_STATIC_ROOT = fs.existsSync(STATIC_ROOT)
  ? fs.realpathSync(STATIC_ROOT)
  : STATIC_ROOT;
const TEMPLATE_PATH = path.resolve(__dirname, 'templates', 'landing-page.html');
const SUPPORT_PATH = path.resolve(__dirname, '..', 'public', 'support.html');
const PRIVACY_PATH = path.resolve(__dirname, '..', 'public', 'privacy.html');
const basePath = (process.env.BASE_PATH || '/').replace(/\/+$/, '');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf',
  '.map': 'application/json',
};

function isInsideStaticRoot(filePath) {
  return (
    filePath === CANONICAL_STATIC_ROOT ||
    filePath.startsWith(`${CANONICAL_STATIC_ROOT}${path.sep}`)
  );
}

function buildStaticFileIndex(root) {
  const index = new Map();
  if (!fs.existsSync(root)) return index;

  function visit(directory, relativeDirectory = '') {
    for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
      const candidatePath = path.join(directory, entry.name);
      const relativePath = path.join(relativeDirectory, entry.name);

      if (entry.isDirectory()) {
        visit(candidatePath, relativePath);
        continue;
      }

      if (!entry.isFile() && !entry.isSymbolicLink()) continue;

      let fileDescriptor;
      try {
        const canonicalFilePath = fs.realpathSync(candidatePath);
        if (!isInsideStaticRoot(canonicalFilePath) || !fs.statSync(canonicalFilePath).isFile()) continue;
        const assetPath = `/${relativePath.split(path.sep).join('/')}`;
        fileDescriptor = fs.openSync(canonicalFilePath, 'r');
        index.set(assetPath, {
          fileDescriptor,
          size: fs.fstatSync(fileDescriptor).size,
        });
      } catch {
        if (fileDescriptor !== undefined) fs.closeSync(fileDescriptor);
        // Ignore broken links and files that disappear during the index pass.
      }
    }
  }

  visit(root);
  return index;
}

const staticFileIndex = buildStaticFileIndex(CANONICAL_STATIC_ROOT);

function getAppName() {
  try {
    const appJsonPath = path.resolve(__dirname, '..', 'app.json');
    const appJson = JSON.parse(fs.readFileSync(appJsonPath, 'utf-8'));
    return typeof appJson.expo?.name === 'string'
      ? appJson.expo.name
      : 'App Landing Page';
  } catch {
    return 'App Landing Page';
  }
}

function escapeHtml(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

function toScriptString(value) {
  return JSON.stringify(value)
    .replaceAll('<', '\\u003c')
    .replaceAll('>', '\\u003e')
    .replaceAll('&', '\\u0026');
}

function serveManifest(platform, res) {
  const manifestPath =
    platform === 'ios'
      ? path.join(CANONICAL_STATIC_ROOT, 'ios', 'manifest.json')
      : path.join(CANONICAL_STATIC_ROOT, 'android', 'manifest.json');

  if (!fs.existsSync(manifestPath)) {
    res.writeHead(404, { 'content-type': 'application/json' });
    res.end(
      JSON.stringify({ error: `Manifest not found for platform: ${platform}` }),
    );
    return;
  }

  const manifest = fs.readFileSync(manifestPath, 'utf-8');
  res.writeHead(200, {
    'content-type': 'application/json',
    'expo-protocol-version': '1',
    'expo-sfv-version': '0',
  });
  res.end(manifest);
}

function serveLandingPage(req, res, landingPageTemplate, appName) {
  const forwardedProto = req.headers['x-forwarded-proto'];
  const protocol = forwardedProto === 'http' ? 'http' : 'https';
  const rawHost = req.headers['x-forwarded-host'] || req.headers['host'];
  const host = Array.isArray(rawHost) ? rawHost[0] : rawHost?.split(',')[0]?.trim();
  if (!host || !/^[a-z0-9.-]+(?::\d{1,5})?$/i.test(host)) {
    res.writeHead(400);
    res.end('Invalid host');
    return;
  }
  const baseUrl = `${protocol}://${host}`;
  const expsUrl = `exps://${host}${basePath}`;

  const html = landingPageTemplate
    .replace(/BASE_URL_PLACEHOLDER/g, baseUrl)
    .replace(/EXPS_URL_ATTRIBUTE_PLACEHOLDER/g, escapeHtml(expsUrl))
    .replace(/EXPS_URL_JSON_PLACEHOLDER/g, toScriptString(expsUrl))
    .replace(/APP_NAME_PLACEHOLDER/g, escapeHtml(appName));

  res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
  res.end(html);
}

function serveStaticFile(urlPath, res) {
  let decodedPath;
  try {
    decodedPath = decodeURIComponent(urlPath);
  } catch {
    res.writeHead(400);
    res.end('Invalid path');
    return;
  }

  const assetPath = `/${decodedPath.replace(/^[/\\]+/, '').replaceAll('\\', '/')}`;
  const asset = staticFileIndex.get(assetPath);
  if (!asset) {
    res.writeHead(404);
    res.end('Not Found');
    return;
  }

  const ext = path.extname(assetPath).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';
  const content = Buffer.allocUnsafe(asset.size);
  // nosemgrep: javascript.express.file.fs-express.fs-express -- the descriptor comes from the validated static index
  if (asset.size > 0) fs.readSync(asset.fileDescriptor, content, 0, asset.size, 0);
  res.writeHead(200, { 'content-type': contentType });
  res.end(content);
}

const landingPageTemplate = fs.readFileSync(TEMPLATE_PATH, 'utf-8');
const appName = getAppName();

const server = http.createServer((req, res) => {
  res.setHeader('x-content-type-options', 'nosniff');
  res.setHeader('x-frame-options', 'DENY');
  res.setHeader('referrer-policy', 'no-referrer');
  res.setHeader('permissions-policy', 'camera=(), microphone=(), geolocation=()');

  const url = new URL(req.url || '/', `http://${req.headers.host}`);
  let pathname = url.pathname;

  if (basePath && pathname.startsWith(basePath)) {
    pathname = pathname.slice(basePath.length) || '/';
  }

  if (pathname === '/support' || pathname === '/support/' || pathname === '/support.html') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end(fs.readFileSync(SUPPORT_PATH, 'utf-8'));
    return;
  }

  if (pathname === '/privacy' || pathname === '/privacy/' || pathname === '/privacy.html') {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' });
    res.end(fs.readFileSync(PRIVACY_PATH, 'utf-8'));
    return;
  }

  if (pathname === '/' || pathname === '/manifest') {
    const platform = req.headers['expo-platform'];
    if (platform === 'ios' || platform === 'android') {
      return serveManifest(platform, res);
    }

    if (pathname === '/') {
      return serveLandingPage(req, res, landingPageTemplate, appName);
    }
  }

  serveStaticFile(pathname, res);
});

const port = parseInt(process.env.PORT || '3000', 10);
server.listen(port, '0.0.0.0', () => {
  console.log(`Serving static Expo build on port ${port}`);
});

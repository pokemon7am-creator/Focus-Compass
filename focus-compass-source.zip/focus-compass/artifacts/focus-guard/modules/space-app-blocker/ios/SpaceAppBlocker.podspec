Pod::Spec.new do |s|
  s.name           = 'SpaceAppBlocker'
  s.version        = '1.0.0'
  s.summary        = 'Native Screen Time enforcement for Space'
  s.description    = 'Uses FamilyControls and ManagedSettings to select and shield distracting apps.'
  s.license        = { :type => 'MIT' }
  s.author         = 'Space'
  s.homepage       = 'https://replit.com'
  s.platforms      = { :ios => '16.4' }
  s.source         = { :path => '.' }
  s.static_framework = true
  s.dependency 'ExpoModulesCore'
  s.source_files = '**/*.{h,m,mm,swift}'
  s.frameworks = 'DeviceActivity', 'FamilyControls', 'ManagedSettings', 'SwiftUI'
  s.swift_version = '5.9'
end
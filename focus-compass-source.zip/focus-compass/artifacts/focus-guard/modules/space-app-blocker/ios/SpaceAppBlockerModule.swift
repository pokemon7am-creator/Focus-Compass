import ExpoModulesCore
import DeviceActivity
import FamilyControls
import ManagedSettings
import SwiftUI

@available(iOS 16.0, *)
private struct AppPickerView: View {
  @State var selection: FamilyActivitySelection
  let completion: (FamilyActivitySelection?) -> Void

  var body: some View {
    NavigationStack {
      FamilyActivityPicker(selection: $selection)
        .navigationTitle("Apps to block")
        .toolbar {
          ToolbarItem(placement: .cancellationAction) {
            Button("Cancel") { completion(nil) }
          }
          ToolbarItem(placement: .confirmationAction) {
            Button("Done") { completion(selection) }
          }
        }
    }
  }
}

public final class SpaceAppBlockerModule: Module {
  private let store = ManagedSettingsStore(named: .init("SpaceFocus"))
  private let selectionKey = "space.family-selection"
  private var pickerController: UIViewController?
  private let activity = DeviceActivityName("SpaceFocus")

  public func definition() -> ModuleDefinition {
    Name("SpaceAppBlocker")

    AsyncFunction("getStatus") { () -> String in
      guard #available(iOS 16.0, *) else { return "unsupported" }
      return AuthorizationCenter.shared.authorizationStatus == .approved ? "ready" : "needs-permission"
    }

    AsyncFunction("requestPermission") { () async throws -> Bool in
      guard #available(iOS 16.0, *) else { return false }
      do {
        try await AuthorizationCenter.shared.requestAuthorization(for: .individual)
        return AuthorizationCenter.shared.authorizationStatus == .approved
      } catch {
        return false
      }
    }

    AsyncFunction("pickApps") { (promise: Promise) in
      guard #available(iOS 16.0, *),
            AuthorizationCenter.shared.authorizationStatus == .approved,
            let presenting = self.topViewController() else {
        promise.reject("permission_required", "Screen Time permission is required before choosing apps.")
        return
      }

      let previous = self.loadSelection()
      let view = AppPickerView(selection: previous) { [weak self] selection in
        guard let self else { return }
        self.pickerController?.dismiss(animated: true)
        self.pickerController = nil
        guard let selection else {
          promise.resolve([])
          return
        }
        self.saveSelection(selection)
        let apps = selection.applicationTokens.enumerated().map { index, token in
          [
            "id": self.encode(token),
            "name": "Selected app \(index + 1)",
            "category": "Screen Time"
          ]
        }
        promise.resolve(apps)
      }
      let controller = UIHostingController(rootView: view)
      controller.modalPresentationStyle = .pageSheet
      self.pickerController = controller
      presenting.present(controller, animated: true)
    }

    AsyncFunction("startBlocking") { (appIds: [String], durationSeconds: Double) in
      guard #available(iOS 16.0, *),
            AuthorizationCenter.shared.authorizationStatus == .approved else {
        throw NSError(domain: "SpaceAppBlocker", code: 1, userInfo: [NSLocalizedDescriptionKey: "Screen Time permission is not approved."])
      }
      guard durationSeconds.isFinite, durationSeconds > 0 else {
        throw NSError(domain: "SpaceAppBlocker", code: 2, userInfo: [NSLocalizedDescriptionKey: "Blocking duration must be greater than zero."])
      }
      let tokens = Set(appIds.compactMap(self.decode))
      guard !tokens.isEmpty else {
        throw NSError(domain: "SpaceAppBlocker", code: 3, userInfo: [NSLocalizedDescriptionKey: "No valid Screen Time app selections were provided."])
      }
      try self.scheduleSystemManagedStop(after: durationSeconds)
      self.store.shield.applications = tokens
    }

    AsyncFunction("stopBlocking") {
      DeviceActivityCenter().stopMonitoring([self.activity])
      self.clearShield()
    }
  }

  private func topViewController() -> UIViewController? {
    let scene = UIApplication.shared.connectedScenes.compactMap { $0 as? UIWindowScene }.first
    var controller = scene?.keyWindow?.rootViewController
    while let presented = controller?.presentedViewController { controller = presented }
    return controller
  }

  @available(iOS 16.0, *)
  private func scheduleSystemManagedStop(after seconds: Double) throws {
    let center = DeviceActivityCenter()
    center.stopMonitoring([activity])
    let now = Date()
    // DeviceActivity intervals must span at least fifteen minutes. Starting the
    // one-time interval in the past keeps short focus sessions eligible while
    // preserving the requested future end time.
    let intervalStart = Calendar.current.dateComponents(
      [.era, .year, .month, .day, .hour, .minute, .second],
      from: now.addingTimeInterval(-15 * 60)
    )
    let intervalEnd = Calendar.current.dateComponents(
      [.era, .year, .month, .day, .hour, .minute, .second],
      from: now.addingTimeInterval(max(1, seconds))
    )
    let schedule = DeviceActivitySchedule(
      intervalStart: intervalStart,
      intervalEnd: intervalEnd,
      repeats: false
    )
    try center.startMonitoring(activity, during: schedule)
  }

  private func clearShield() {
    store.clearAllSettings()
  }

  @available(iOS 16.0, *)
  private func saveSelection(_ selection: FamilyActivitySelection) {
    if let data = try? PropertyListEncoder().encode(selection) {
      UserDefaults.standard.set(data, forKey: selectionKey)
    }
  }

  @available(iOS 16.0, *)
  private func loadSelection() -> FamilyActivitySelection {
    guard let data = UserDefaults.standard.data(forKey: selectionKey),
          let selection = try? PropertyListDecoder().decode(FamilyActivitySelection.self, from: data) else {
      return FamilyActivitySelection()
    }
    return selection
  }

  @available(iOS 16.0, *)
  private func encode(_ token: ApplicationToken) -> String {
    (try? PropertyListEncoder().encode(token).base64EncodedString()) ?? ""
  }

  @available(iOS 16.0, *)
  private func decode(_ value: String) -> ApplicationToken? {
    guard let data = Data(base64Encoded: value) else { return nil }
    return try? PropertyListDecoder().decode(ApplicationToken.self, from: data)
  }
}
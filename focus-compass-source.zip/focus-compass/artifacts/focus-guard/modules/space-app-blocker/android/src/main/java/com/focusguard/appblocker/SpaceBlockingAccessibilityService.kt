package com.focusguard.appblocker

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class SpaceBlockingAccessibilityService : AccessibilityService() {
  private val protectedPackages by lazy { BlockingPackagePolicy.protectedPackages(this) }

  override fun onServiceConnected() {
    super.onServiceConnected()
    val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
    if (prefs.getLong(BLOCKED_UNTIL, 0) <= System.currentTimeMillis()) {
      prefs.edit().remove(BLOCKED_PACKAGES).remove(BLOCKED_UNTIL).apply()
    }
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) {
    val packageName = event?.packageName?.toString() ?: return
    if (protectedPackages.contains(packageName)) return
    val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
    val blockedUntil = prefs.getLong(BLOCKED_UNTIL, 0)
    val blocked = prefs.getStringSet(BLOCKED_PACKAGES, emptySet()) ?: emptySet()
    if (System.currentTimeMillis() >= blockedUntil) {
      if (blockedUntil != 0L || blocked.isNotEmpty()) {
        prefs.edit().remove(BLOCKED_PACKAGES).remove(BLOCKED_UNTIL).apply()
      }
      return
    }
    if (!blocked.contains(packageName)) return

    val returnedHome = performGlobalAction(GLOBAL_ACTION_HOME) || runCatching {
      val home = Intent(Intent.ACTION_MAIN).apply {
        addCategory(Intent.CATEGORY_HOME)
        flags = Intent.FLAG_ACTIVITY_NEW_TASK
      }
      startActivity(home)
      true
    }.getOrDefault(false)
    if (returnedHome) {
      SpaceAppBlockerModule.emitBlockedAttempt(packageName)
    }
  }

  override fun onInterrupt() = Unit

  companion object {
    const val PREFS = "space_app_blocker"
    const val BLOCKED_PACKAGES = "blocked_packages"
    const val BLOCKED_UNTIL = "blocked_until"
  }
}
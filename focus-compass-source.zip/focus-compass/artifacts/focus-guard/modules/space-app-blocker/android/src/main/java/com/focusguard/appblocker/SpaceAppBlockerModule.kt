package com.focusguard.appblocker

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import expo.modules.kotlin.functions.Queues
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.lang.ref.WeakReference

class SpaceAppBlockerModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("SpaceAppBlocker")
    Events("SpaceBlockedAppAttempt")

    OnCreate { currentModule = WeakReference(this@SpaceAppBlockerModule) }
    OnDestroy { currentModule = null }

    AsyncFunction("getStatus") {
      if (!isAccessibilityEnabled()) {
        "needs-permission"
      } else {
        val preferences = prefs()
        val blockedUntil = preferences.getLong(SpaceBlockingAccessibilityService.BLOCKED_UNTIL, 0)
        val blocked = preferences.getStringSet(
          SpaceBlockingAccessibilityService.BLOCKED_PACKAGES,
          emptySet()
        ).orEmpty()
        if (blockedUntil > System.currentTimeMillis() && blocked.isNotEmpty()) {
          "active"
        } else {
          if (blockedUntil != 0L || blocked.isNotEmpty()) clearBlocking()
          "ready"
        }
      }
    }

    AsyncFunction("requestPermission") { promise: expo.modules.kotlin.Promise ->
      if (isAccessibilityEnabled()) {
        promise.resolve(true)
        return@AsyncFunction
      }
      val activity = appContext.currentActivity
      if (activity == null) {
        promise.reject("activity_unavailable", "Android Accessibility settings cannot be opened right now.", null)
        return@AsyncFunction
      }

      AlertDialog.Builder(activity)
        .setTitle(R.string.space_accessibility_disclosure_title)
        .setMessage(R.string.space_accessibility_disclosure_body)
        .setNegativeButton(R.string.space_accessibility_not_now) { _, _ -> promise.resolve(false) }
        .setPositiveButton(R.string.space_accessibility_continue) { _, _ ->
          try {
            activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            promise.resolve(true)
          } catch (error: Exception) {
            promise.reject(
              "settings_unavailable",
              "Android Accessibility settings could not be opened.",
              error
            )
          }
        }
        .setOnCancelListener { promise.resolve(false) }
        .show()
    }.runOnQueue(Queues.MAIN)

    AsyncFunction("pickApps") { promise: expo.modules.kotlin.Promise ->
      val activity = appContext.currentActivity
      if (activity == null || !isAccessibilityEnabled()) {
        promise.reject("permission_required", "Enable Space in Accessibility settings first.", null)
        return@AsyncFunction
      }
      val packageManager = activity.packageManager
      val apps = BlockingPackagePolicy.eligibleLauncherApps(activity)
        .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
      val labels = apps.map { packageManager.getApplicationLabel(it).toString() }.toTypedArray()
      val checked = BooleanArray(apps.size)
      AlertDialog.Builder(activity)
        .setTitle("Apps to block")
        .setMultiChoiceItems(labels, checked) { _, which, selected -> checked[which] = selected }
        .setNegativeButton("Cancel") { _, _ -> promise.resolve(emptyList<Map<String, String>>()) }
        .setPositiveButton("Done") { _, _ ->
          val result = apps.mapIndexedNotNull { index, app ->
            if (!checked[index]) null else mapOf(
              "id" to app.packageName,
              "name" to packageManager.getApplicationLabel(app).toString(),
              "category" to categoryName(app)
            )
          }
          promise.resolve(result)
        }
        .setOnCancelListener { promise.resolve(emptyList<Map<String, String>>()) }
        .show()
    }.runOnQueue(Queues.MAIN)

    AsyncFunction("startBlocking") { appIds: List<String>, durationSeconds: Double ->
      if (!isAccessibilityEnabled()) throw IllegalStateException("Accessibility permission is not enabled.")
      if (!durationSeconds.isFinite() || durationSeconds <= 0) {
        throw IllegalArgumentException("Blocking duration must be greater than zero.")
      }
      val requestedPackages = appIds.map { it.trim() }.filter { it.isNotEmpty() }.toSet()
      val eligiblePackages = BlockingPackagePolicy.eligibleLauncherApps(
        requireNotNull(appContext.reactContext)
      ).mapTo(mutableSetOf()) { it.packageName }
      val packages = requestedPackages.intersect(eligiblePackages)
      if (packages.isEmpty()) {
        throw IllegalArgumentException("Select at least one installed app that can be safely blocked.")
      }
      prefs().edit()
        .putStringSet(SpaceBlockingAccessibilityService.BLOCKED_PACKAGES, packages)
        .putLong(SpaceBlockingAccessibilityService.BLOCKED_UNTIL, System.currentTimeMillis() + (durationSeconds * 1000).toLong())
        .apply()
    }

    AsyncFunction("stopBlocking") {
      clearBlocking()
    }
  }

  private fun prefs() = requireNotNull(appContext.reactContext)
    .getSharedPreferences(SpaceBlockingAccessibilityService.PREFS, Context.MODE_PRIVATE)

  private fun clearBlocking() {
    prefs().edit().remove(SpaceBlockingAccessibilityService.BLOCKED_PACKAGES)
      .remove(SpaceBlockingAccessibilityService.BLOCKED_UNTIL).apply()
  }

  private fun isAccessibilityEnabled(): Boolean {
    val context = appContext.reactContext ?: return false
    val manager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
      .any { it.resolveInfo.serviceInfo.packageName == context.packageName &&
        it.resolveInfo.serviceInfo.name.endsWith("SpaceBlockingAccessibilityService") }
  }

  private fun categoryName(app: ApplicationInfo): String = when (app.category) {
    ApplicationInfo.CATEGORY_GAME -> "Games"
    ApplicationInfo.CATEGORY_VIDEO -> "Video"
    ApplicationInfo.CATEGORY_SOCIAL -> "Social"
    ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
    else -> "App"
  }

  companion object {
    private var currentModule: WeakReference<SpaceAppBlockerModule>? = null
    fun emitBlockedAttempt(packageName: String) {
      currentModule?.get()?.sendEvent("SpaceBlockedAppAttempt", mapOf("appId" to packageName))
    }
  }
}

internal object BlockingPackagePolicy {
  fun protectedPackages(context: Context): Set<String> {
    val packageManager = context.packageManager
    val protected = mutableSetOf(context.packageName, "android", "com.android.settings")
    val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    packageManager.queryIntentActivities(homeIntent, PackageManager.MATCH_ALL)
      .mapTo(protected) { it.activityInfo.packageName }
    packageManager.resolveActivity(Intent(Settings.ACTION_SETTINGS), PackageManager.MATCH_DEFAULT_ONLY)
      ?.activityInfo?.packageName?.let(protected::add)
    return protected
  }

  fun eligibleLauncherApps(context: Context): List<ApplicationInfo> {
    val packageManager = context.packageManager
    val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val protected = protectedPackages(context)
    return packageManager.queryIntentActivities(launcherIntent, PackageManager.MATCH_ALL)
      .filter { it.activityInfo.enabled && it.activityInfo.applicationInfo.enabled }
      .map { it.activityInfo.applicationInfo }
      .distinctBy { it.packageName }
      .filterNot { protected.contains(it.packageName) }
  }
}
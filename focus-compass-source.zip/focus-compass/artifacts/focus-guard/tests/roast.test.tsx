import React from 'react';
import TestRenderer, { act } from 'react-test-renderer';

declare const require: (moduleName: string) => {
  _load: (request: string, parent: unknown, isMain: boolean) => unknown;
};

function assert(condition: boolean, message: string): asserts condition {
  if (!condition) throw new Error(message);
}

const nodeModule = require('node:module');
const originalLoad = nodeModule._load;
const generated: unknown[] = [];
let storageReads = 0;
let backs = 0;
const today = new Date().toLocaleDateString('en-CA');
// An old roast completion record exists for today, but must never be consulted.
const storedCompletion = { 'zen-space-roast-completion-day-v1:guest': today };

(globalThis as typeof globalThis & { IS_REACT_ACT_ENVIRONMENT?: boolean })
  .IS_REACT_ACT_ENVIRONMENT = true;

nodeModule._load = (request, parent, isMain) => {
  if (request === '@react-native-async-storage/async-storage') {
    return { getItem: async (key: keyof typeof storedCompletion) => {
      storageReads += 1;
      return storedCompletion[key] ?? null;
    } };
  }
  if (request === '@expo/vector-icons') return { Feather: 'Feather' };
  if (request === 'react-native') {
    return {
      Platform: { OS: 'ios' },
      Pressable: 'Pressable',
      Text: 'Text',
      View: 'View',
      StyleSheet: { create: (styles: unknown) => styles },
    };
  }
  if (request === 'expo-router') {
    return {
      router: { back: () => { backs += 1; }, replace: () => undefined },
      useLocalSearchParams: () => ({ mode: 'override' }),
    };
  }
  if (request === '@workspace/api-client-react') {
    return { useGenerateRoast: () => ({
      mutate: (data: unknown) => { generated.push(data); },
      data: { roast: 'Back to your focus plan.' },
    }) };
  }
  if (request === '@/components/Screen') return { Screen: 'Screen' };
  if (request === '@/context/FocusContext') {
    return { useFocus: () => ({
      sessionSeconds: 1500,
      remainingSeconds: 1200,
      overridesToday: 0,
      recordOverride: () => undefined,
    }) };
  }
  if (request === '@/context/RewardsContext') {
    return { useRewards: () => ({ equipped: { roast: 'classic' } }) };
  }
  if (request === '@/hooks/useColors') {
    return { useColors: () => ({
      primary: 'green',
      foreground: 'black',
      mutedForeground: 'gray',
      accent: 'white',
      accentForeground: 'black',
      card: 'white',
      border: 'gray',
      success: 'green',
      primaryForeground: 'white',
    }) };
  }
  return originalLoad(request, parent, isMain);
};

async function runRoastTests() {
  try {
    const { default: RoastScreen } = await import('../app/roast');
    for (let attempt = 1; attempt <= 2; attempt += 1) {
      let renderer: TestRenderer.ReactTestRenderer;
      await act(async () => {
        renderer = TestRenderer.create(React.createElement(RoastScreen));
      });
      assert(generated.length === attempt, 'each same-day visit must request its own roast');
      assert(renderer!.root.findAllByProps({ testID: 'override-guard' }).length === 1,
        'old completion must not replace the roast with a completed-today screen');
      await act(async () => {
        renderer!.root.findByProps({ testID: 'return-to-focus' }).props.onPress();
        renderer!.unmount();
      });
    }
    assert(storageReads === 0, 'legacy daily roast completion must not be read');
    assert(backs === 2, 'both same-day roast visits must allow returning to focus');
  } finally {
    nodeModule._load = originalLoad;
  }
}

if (process.argv[1]?.endsWith('roast.test.tsx')) {
  runRoastTests().catch((error: unknown) => {
    console.error(error);
    process.exitCode = 1;
  });
}
import React, { useCallback, useEffect, useState } from 'react';
import { Platform } from 'react-native';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ClerkProvider, useAuth } from '@clerk/expo';
import { tokenCache } from '@clerk/expo/token-cache';
import { setAuthTokenGetter, setBaseUrl } from '@workspace/api-client-react';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { AppInfoButton } from '@/components/AppInfoButton';
import { StartupLoading } from '@/components/StartupLoading';
import { FocusEscapeMonitor } from '@/components/FocusEscapeMonitor';
import { PracticeSyncBridge } from '@/components/PracticeSyncBridge';
import { FocusProvider } from '@/context/FocusContext';
import { AuthRecoveryProvider } from '@/context/AuthRecoveryContext';
import { RewardsProvider } from '@/context/RewardsContext';
import { ProgressionProvider } from '@/context/ProgressionContext';
import { RevenueCatProvider } from '@/context/RevenueCatContext';
import {
  Inter_400Regular,
  Inter_500Medium,
  Inter_600SemiBold,
  Inter_700Bold,
  useFonts,
} from '@expo-google-fonts/inter';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';

if (Platform.OS !== 'web') void SplashScreen.preventAutoHideAsync().catch(() => undefined);
const queryClient = new QueryClient();
const domain = process.env.EXPO_PUBLIC_DOMAIN;
if (domain) setBaseUrl(`https://${domain}`);
const clerkPubKey = process.env.EXPO_PUBLIC_CLERK_PUBLISHABLE_KEY ?? '';
const clerkProxyUrl = process.env.EXPO_PUBLIC_CLERK_PROXY_URL || undefined;

function AuthTokenBridge() {
  const { getToken } = useAuth();

  useEffect(() => {
    setAuthTokenGetter(() => getToken());
  }, [getToken]);

  return null;
}

function AuthStatusBanner() {
  const { isLoaded } = useAuth();
  return isLoaded ? null : (
    <StartupLoading variant="compact" message="Connecting to sign-in services…" />
  );
}

function RootLayoutNav() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen name="tutorial" />
      <Stack.Screen name="login" />
      <Stack.Screen name="signup" />
      <Stack.Screen name="challenge" />
      <Stack.Screen name="friction" options={{ presentation: 'fullScreenModal', gestureEnabled: false }} />
      <Stack.Screen name="(tabs)" />
      <Stack.Screen name="paywall" options={{ presentation: 'modal' }} />
      <Stack.Screen name="roast" options={{ presentation: 'fullScreenModal' }} />
      <Stack.Screen name="reflection" options={{ presentation: 'fullScreenModal', gestureEnabled: false }} />
      <Stack.Screen name="terms" />
    </Stack>
  );
}

export default function RootLayout() {
  const [fontWaitExpired, setFontWaitExpired] = useState(false);
  const [clerkAttempt, setClerkAttempt] = useState(0);
  const retryAuth = useCallback(() => setClerkAttempt((attempt) => attempt + 1), []);
  const [fontsLoaded, fontError] = useFonts({
    Inter_400Regular,
    Inter_500Medium,
    Inter_600SemiBold,
    Inter_700Bold,
  });

  useEffect(() => {
    const timer = setTimeout(() => setFontWaitExpired(true), 8000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (fontsLoaded || fontError || fontWaitExpired || Platform.OS === 'web') {
      void SplashScreen.hideAsync().catch(() => undefined);
    }
  }, [fontsLoaded, fontError, fontWaitExpired]);

  if (!fontsLoaded && !fontError && !fontWaitExpired && Platform.OS !== 'web') {
    return <StartupLoading message="Loading display fonts…" />;
  }

  return (
    <SafeAreaProvider>
      <ErrorBoundary>
        <QueryClientProvider client={queryClient}>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <KeyboardProvider>
              <AuthRecoveryProvider retryAuth={retryAuth}>
                <ClerkProvider
                  key={clerkAttempt}
                  publishableKey={clerkPubKey}
                  tokenCache={tokenCache}
                  proxyUrl={clerkProxyUrl}
                >
                  <AuthTokenBridge />
                  <AuthStatusBanner />
                  <RevenueCatProvider>
                    <RewardsProvider>
                      <FocusProvider>
                        <PracticeSyncBridge>
                        <ProgressionProvider>
                          <FocusEscapeMonitor />
                          <RootLayoutNav />
                          <AppInfoButton />
                        </ProgressionProvider>
                        </PracticeSyncBridge>
                      </FocusProvider>
                    </RewardsProvider>
                  </RevenueCatProvider>
                </ClerkProvider>
              </AuthRecoveryProvider>
            </KeyboardProvider>
          </GestureHandlerRootView>
        </QueryClientProvider>
      </ErrorBoundary>
    </SafeAreaProvider>
  );
}
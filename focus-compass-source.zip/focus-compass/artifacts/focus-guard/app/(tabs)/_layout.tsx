import React, { useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type MenuTabBarProps = {
  state: {
    index: number;
    routes: Array<{ key: string; name: string }>;
  };
  navigation: {
    navigate: (routeName: string) => void;
  };
};

const routeMeta: Record<string, { label: string; icon: React.ComponentProps<typeof Feather>['name'] }> = {
  index: { label: 'Today', icon: 'clock' },
  compass: { label: 'Compass', icon: 'compass' },
  guard: { label: 'Guard', icon: 'shield' },
  insights: { label: 'Insights', icon: 'bar-chart-2' },
  stillness: { label: 'Stillness', icon: 'wind' },
  shop: { label: 'Shop', icon: 'shopping-bag' },
  pass: { label: 'Focus Compass Pass', icon: 'award' },
  tutor: { label: 'Tutor', icon: 'book-open' },
};

function MenuTabBar({ state, navigation }: MenuTabBarProps) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [open, setOpen] = useState(false);
  const activeRoute = state.routes[state.index];
  const active = routeMeta[activeRoute.name] ?? routeMeta.index;
  const topOffset = Platform.OS === 'web' ? Math.max(insets.top, 67) + 10 : insets.top + 10;

  return (
    <View pointerEvents="box-none" style={styles.barRoot}>
      {open ? (
        <>
          <Pressable
            accessibilityLabel="Close navigation menu"
            onPress={() => setOpen(false)}
            style={styles.backdrop}
          />
          <View pointerEvents="box-none" style={styles.menuLayer}>
          <View
            style={[
              styles.menuPanel,
              {
                backgroundColor: colors.card,
                borderColor: colors.border,
                paddingTop: topOffset + 62,
                paddingBottom: Math.max(insets.bottom, 14),
              },
            ]}
          >
            <View style={styles.menuHeader}>
              <View style={styles.menuHeaderCopy}>
                <Text style={[styles.menuEyebrow, { color: colors.primary }]}>FOCUS COMPASS</Text>
                <Text style={[styles.menuTitle, { color: colors.foreground }]}>Go to</Text>
              </View>
              <Text style={[styles.menuHint, { color: colors.mutedForeground }]}>Navigation</Text>
            </View>
            {state.routes.map((route) => {
              const item = routeMeta[route.name];
              if (!item) return null;
              const selected = route.key === activeRoute.key;
              return (
                <Pressable
                  key={route.key}
                  accessibilityRole="button"
                  accessibilityState={{ selected }}
                  onPress={() => {
                    setOpen(false);
                    navigation.navigate(route.name);
                  }}
                  style={({ pressed }) => [
                    styles.menuItem,
                    selected && { backgroundColor: colors.secondary },
                    pressed && styles.pressed,
                  ]}
                >
                  <View
                    style={[
                      styles.itemIcon,
                      { backgroundColor: selected ? colors.card : colors.background },
                    ]}
                  >
                    <Feather name={item.icon} size={19} color={selected ? colors.primary : colors.mutedForeground} />
                  </View>
                  <Text style={[styles.menuLabel, { color: selected ? colors.foreground : colors.mutedForeground }]}>
                    {item.label}
                  </Text>
                  {selected ? <View style={[styles.selectedDot, { backgroundColor: colors.primary }]} /> : null}
                </Pressable>
              );
            })}
          </View>
        </View>
        </>
      ) : null}
      <Pressable
        accessibilityRole="button"
        accessibilityLabel={open ? 'Close navigation menu' : 'Open navigation menu'}
        onPress={() => setOpen((value) => !value)}
        style={({ pressed }) => [
          styles.menuButton,
          {
            top: topOffset,
            backgroundColor: open ? colors.foreground : colors.secondary,
            borderColor: open ? colors.foreground : colors.border,
          },
          pressed && styles.pressed,
        ]}
      >
        <Feather
          name={open ? 'x' : 'menu'}
          size={22}
          color={open ? colors.primaryForeground : colors.primary}
        />
      </Pressable>
    </View>
  );
}

export default function TabLayout() {
  return (
    <Tabs screenOptions={{ headerShown: false }} tabBar={(props) => <MenuTabBar {...props} />}>
      <Tabs.Screen name="index" options={{ title: 'Today' }} />
      <Tabs.Screen name="compass" options={{ title: 'Compass' }} />
      <Tabs.Screen name="guard" options={{ title: 'Guard' }} />
      <Tabs.Screen name="insights" options={{ title: 'Insights' }} />
      <Tabs.Screen name="stillness" options={{ title: 'Stillness' }} />
      <Tabs.Screen name="shop" options={{ title: 'Shop' }} />
      <Tabs.Screen name="pass" options={{ title: 'Focus Compass Pass' }} />
      <Tabs.Screen name="tutor" options={{ title: 'Tutor' }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  barRoot: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    zIndex: 20,
  },
  backdrop: {
    ...StyleSheet.absoluteFill,
    backgroundColor: 'rgba(18, 27, 25, 0.22)',
  },
  menuLayer: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: '100%',
    alignItems: 'flex-end',
  },
  menuPanel: {
    width: '82%',
    maxWidth: 340,
    height: '100%',
    borderLeftWidth: 1,
    paddingHorizontal: 12,
    gap: 4,
    shadowColor: '#000',
    shadowOpacity: 0.24,
    shadowRadius: 24,
    shadowOffset: { width: -8, height: 0 },
    elevation: 16,
  },
  menuHeader: {
    minHeight: 65,
    paddingHorizontal: 10,
    paddingTop: 10,
    paddingBottom: 16,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6
  },
  menuHeaderCopy: {
    alignItems: 'center'
  },
  menuEyebrow: {
    fontFamily: 'Inter_700Bold',
    fontSize: 11,
    letterSpacing: 1.2,
    textAlign: 'center'
  },
  menuTitle: {
    fontFamily: 'Inter_700Bold',
    fontSize: 22,
    letterSpacing: -0.4,
    marginTop: 2,
    textAlign: 'center'
  },
  menuHint: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 12,
    marginBottom: 3,
    textAlign: 'center'
  },
  menuItem: {
    minHeight: 54,
    borderRadius: 17,
    paddingHorizontal: 9,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
  },
  itemIcon: {
    width: 36,
    height: 36,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  menuLabel: {
    flex: 1,
    fontFamily: 'Inter_700Bold',
    fontSize: 16,
  },
  selectedDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  menuButton: {
    position: 'absolute',
    right: 16,
    width: 52,
    height: 52,
    borderRadius: 18,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
    elevation: 4,
  },
  pressed: {
    opacity: 0.75,
    transform: [{ scale: 0.985 }],
  },
});
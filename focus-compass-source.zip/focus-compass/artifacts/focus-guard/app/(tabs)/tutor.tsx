import { Feather } from '@expo/vector-icons';
import { useExplainTutorQuestion } from '@workspace/api-client-react';
import { CameraView, useCameraPermissions } from 'expo-camera';
import React, { useRef, useState } from 'react';
import { ActivityIndicator, Alert, Image, Linking, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { Screen } from '@/components/Screen';
import { useColors } from '@/hooks/useColors';

const subjects = ['Math', 'Science', 'History', 'Language', 'Coding', 'Any subject'];
const studyStarters = [
  { title: 'Break it down', body: 'Ask for the idea in smaller steps.' },
  { title: 'Use an analogy', body: 'Connect a hard idea to something familiar.' },
  { title: 'Check my work', body: 'Paste your attempt and ask where it changed.' },
];

export default function TutorScreen() {
  const colors = useColors();
  const [subject, setSubject] = useState('Math');
  const [customSubject, setCustomSubject] = useState('');
  const [materials, setMaterials] = useState('');
  const [question, setQuestion] = useState('');
  const [imageDataUrl, setImageDataUrl] = useState<string>();
  const [cameraOpen, setCameraOpen] = useState(false);
  const cameraRef = useRef<CameraView>(null);
  const [permission, requestPermission] = useCameraPermissions();
  const tutor = useExplainTutorQuestion();
  const activeSubject = subject === 'Any subject' && customSubject.trim() ? customSubject.trim() : subject;
  const canAsk = Boolean(question.trim()) && !tutor.isPending;

  const askTutor = (nextQuestion: string) => {
    const trimmedQuestion = nextQuestion.trim();
    if (!trimmedQuestion || tutor.isPending) return;
    setQuestion(trimmedQuestion);
    tutor.mutate({
      data: {
        subject: activeSubject,
        materials: materials.trim() || undefined,
        imageDataUrl,
        question: trimmedQuestion,
      },
    });
  };

  const openCamera = async () => {
    if (Platform.OS === 'web') {
      Alert.alert('Use Focus Compass on your phone', 'Camera capture is available in the native Focus Compass app.');
      return;
    }

    if (!permission?.granted) {
      if (permission?.status === 'denied' && !permission.canAskAgain) {
        await Linking.openSettings();
        return;
      }
      const nextPermission = await requestPermission();
      if (!nextPermission.granted) return;
    }

    setCameraOpen(true);
  };

  const capturePhoto = async () => {
    const photo = await cameraRef.current?.takePictureAsync({ base64: true, quality: 0.7 });
    if (!photo?.base64) return;
    setImageDataUrl(`data:image/jpeg;base64,${photo.base64}`);
    setCameraOpen(false);
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>STUDY COMPASS</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Understand the next step.</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Bring a question, notes, or a lesson. The tutor can explain it in a new way and keep the conversation moving.
        </Text>
      </View>

      <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.cardHeader}>
          <View style={[styles.iconBubble, { backgroundColor: colors.secondary }]}>
            <Feather name="book-open" size={22} color={colors.secondaryForeground} />
          </View>
          <View style={styles.cardCopy}>
            <Text style={[styles.cardTitle, { color: colors.foreground }]}>Choose a subject</Text>
            <Text style={[styles.cardBody, { color: colors.mutedForeground }]}>Any subject works. Start broad or name the exact class.</Text>
          </View>
        </View>
        <View style={styles.subjects}>
          {subjects.map((item) => (
            <Pressable
              key={item}
              testID={`tutor-subject-${item}`}
              onPress={() => setSubject(item)}
              style={[
                styles.subjectChip,
                { borderColor: subject === item ? colors.primary : colors.border },
                subject === item && { backgroundColor: colors.secondary },
              ]}
            >
              <Text style={[styles.subjectText, { color: subject === item ? colors.secondaryForeground : colors.mutedForeground }]}>
                {item}
              </Text>
            </Pressable>
          ))}
        </View>
        {subject === 'Any subject' ? (
          <TextInput
            testID="tutor-custom-subject"
            value={customSubject}
            onChangeText={setCustomSubject}
            placeholder="Name the subject or topic"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
          />
        ) : null}
        <TextInput
          testID="tutor-materials"
          value={materials}
          onChangeText={setMaterials}
          multiline
          textAlignVertical="top"
          placeholder="Paste notes, a study guide, or the part you are reading (optional)"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.materialInput, { color: colors.foreground, borderColor: colors.border, backgroundColor: colors.background }]}
        />
        {cameraOpen ? (
          <View style={[styles.cameraFrame, { borderColor: colors.primary }]}>
            <CameraView ref={cameraRef} style={styles.camera} facing="back" />
            <View style={styles.cameraControls}>
              <Pressable onPress={() => setCameraOpen(false)} style={[styles.cameraButton, { backgroundColor: colors.card }]}>
                <Text style={[styles.cameraButtonText, { color: colors.foreground }]}>Cancel</Text>
              </Pressable>
              <Pressable onPress={capturePhoto} style={[styles.captureButton, { backgroundColor: colors.primary }]}>
                <Feather name="camera" size={20} color={colors.primaryForeground} />
              </Pressable>
            </View>
          </View>
        ) : (
          <Pressable
            testID="tutor-take-picture"
            onPress={openCamera}
            style={({ pressed }) => [
              styles.photoButton,
              { backgroundColor: colors.secondary, borderColor: colors.border },
              pressed && styles.pressed,
            ]}
          >
            <View style={[styles.photoIcon, { backgroundColor: colors.card }]}>
              <Feather name={imageDataUrl ? 'refresh-cw' : 'camera'} size={19} color={colors.primary} />
            </View>
            <View style={styles.photoCopy}>
              <Text style={[styles.photoTitle, { color: colors.foreground }]}>
                {imageDataUrl ? 'Replace study photo' : 'Take a picture'}
              </Text>
              <Text style={[styles.photoBody, { color: colors.secondaryForeground }]}>
                {imageDataUrl ? 'Use a clearer page or problem.' : 'Capture homework, notes, or a diagram.'}
              </Text>
            </View>
            <Feather name="chevron-right" size={18} color={colors.secondaryForeground} />
          </Pressable>
        )}
        {imageDataUrl ? (
          <View style={[styles.photoPreview, { backgroundColor: colors.background, borderColor: colors.border }]}>
            <Image source={{ uri: imageDataUrl }} style={styles.photoImage} resizeMode="cover" />
            <Pressable onPress={() => setImageDataUrl(undefined)} style={styles.removePhoto}>
              <Feather name="x" size={17} color={colors.foreground} />
            </Pressable>
          </View>
        ) : null}
        <TextInput
          testID="tutor-question"
          value={question}
          onChangeText={setQuestion}
          multiline
          textAlignVertical="top"
          placeholder="What do you not understand yet?"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.questionInput, { color: colors.foreground, borderColor: colors.primary, backgroundColor: colors.background }]}
        />
        <Pressable
          testID="tutor-explain"
          disabled={!canAsk}
          onPress={() => askTutor(question)}
          style={({ pressed }) => [
            styles.askButton,
            { backgroundColor: canAsk ? colors.primary : colors.muted },
            pressed && styles.pressed,
          ]}
        >
          {tutor.isPending ? <ActivityIndicator color={colors.primaryForeground} /> : <Feather name="message-circle" size={19} color={canAsk ? colors.primaryForeground : colors.mutedForeground} />}
          <Text style={[styles.askText, { color: canAsk ? colors.primaryForeground : colors.mutedForeground }]}>
            {tutor.isPending ? 'Thinking…' : 'Explain it to me'}
          </Text>
        </Pressable>
        {tutor.isError ? (
          <View style={[styles.errorBox, { backgroundColor: colors.secondary }]}>
            <Feather name="wifi-off" size={18} color={colors.secondaryForeground} />
            <Text style={[styles.errorText, { color: colors.secondaryForeground }]}>
              The tutor connection is temporarily unavailable. Your notes and photo stay on this screen.
            </Text>
          </View>
        ) : null}
      </View>

      {tutor.data ? (
        <View style={[styles.answerCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.answerHeader}>
            <View style={[styles.answerIcon, { backgroundColor: colors.accent }]}>
              <Feather name="sun" size={20} color={colors.accentForeground} />
            </View>
            <View>
              <Text style={[styles.answerEyebrow, { color: colors.mutedForeground }]}>TUTOR EXPLANATION</Text>
              <Text style={[styles.answerTitle, { color: colors.cardForeground }]}>{activeSubject}</Text>
            </View>
          </View>
          <Text style={[styles.answerBody, { color: colors.cardForeground }]}>{tutor.data.explanation}</Text>
          <Text style={[styles.keyHeading, { color: colors.cardForeground }]}>Key ideas</Text>
          {tutor.data.keyIdeas.map((idea) => (
            <View key={idea} style={styles.ideaRow}>
              <Feather name="check" size={16} color={colors.primary} />
              <Text style={[styles.ideaText, { color: colors.cardForeground }]}>{idea}</Text>
            </View>
          ))}
          <Pressable
            testID="tutor-follow-up"
            accessibilityRole="button"
            accessibilityLabel={`Ask follow-up: ${tutor.data.followUp}`}
            disabled={tutor.isPending}
            onPress={() => askTutor(tutor.data.followUp)}
            style={({ pressed }) => [
              styles.followUp,
              { backgroundColor: colors.secondary },
              tutor.isPending && styles.disabled,
              pressed && styles.pressed,
            ]}
          >
            <Feather name="corner-down-right" size={17} color={colors.secondaryForeground} />
            <View style={styles.followUpCopy}>
              <Text style={[styles.followUpLabel, { color: colors.secondaryForeground }]}>ASK THIS NEXT</Text>
              <Text style={[styles.followUpText, { color: colors.secondaryForeground }]}>{tutor.data.followUp}</Text>
            </View>
            <Feather name="arrow-up-right" size={17} color={colors.secondaryForeground} />
          </Pressable>
        </View>
      ) : (
        <View style={styles.starters}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Good ways to ask</Text>
          {studyStarters.map((starter) => (
            <Pressable
              key={starter.title}
              onPress={() => setQuestion(starter.body)}
              style={({ pressed }) => [styles.starter, { borderColor: colors.border }, pressed && styles.pressed]}
            >
              <Feather name="arrow-up-right" size={17} color={colors.primary} />
              <View style={styles.starterCopy}>
                <Text style={[styles.starterTitle, { color: colors.foreground }]}>{starter.title}</Text>
                <Text style={[styles.starterBody, { color: colors.mutedForeground }]}>{starter.body}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', marginBottom: 20 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, marginBottom: 7, textAlign: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.7, textAlign: 'center' },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, marginTop: 7, textAlign: 'center' },
  card: { borderWidth: 1, borderRadius: 24, padding: 17, gap: 13 },
  cardHeader: { flexDirection: 'row', gap: 12, alignItems: 'center' },
  iconBubble: { width: 45, height: 45, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  cardCopy: { flex: 1 },
  cardTitle: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  cardBody: { fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 19, marginTop: 3 },
  subjects: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  subjectChip: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 9 },
  subjectText: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  input: { minHeight: 48, borderWidth: 1, borderRadius: 14, paddingHorizontal: 13, fontFamily: 'Inter_500Medium', fontSize: 15 },
  materialInput: { minHeight: 88, borderWidth: 1, borderRadius: 15, padding: 13, fontFamily: 'Inter_500Medium', fontSize: 15, lineHeight: 21 },
  photoButton: { minHeight: 65, borderWidth: 1, borderRadius: 16, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 10 },
  photoIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  photoCopy: { flex: 1, gap: 2 },
  photoTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  photoBody: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 17 },
  cameraFrame: { height: 280, borderWidth: 1.5, borderRadius: 18, overflow: 'hidden' },
  camera: { flex: 1 },
  cameraControls: { position: 'absolute', left: 0, right: 0, bottom: 0, padding: 12, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cameraButton: { minHeight: 40, borderRadius: 12, paddingHorizontal: 14, justifyContent: 'center' },
  cameraButtonText: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  captureButton: { width: 54, height: 54, borderRadius: 27, alignItems: 'center', justifyContent: 'center', borderWidth: 4, borderColor: '#FFF9F1' },
  photoPreview: { height: 150, borderWidth: 1, borderRadius: 16, overflow: 'hidden', position: 'relative' },
  photoImage: { width: '100%', height: '100%' },
  removePhoto: { position: 'absolute', top: 8, right: 8, width: 30, height: 30, borderRadius: 15, backgroundColor: '#FFF9F1', alignItems: 'center', justifyContent: 'center' },
  questionInput: { minHeight: 92, borderWidth: 1.5, borderRadius: 15, padding: 13, fontFamily: 'Inter_600SemiBold', fontSize: 16, lineHeight: 23 },
  askButton: { minHeight: 54, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  askText: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  errorBox: { borderRadius: 14, padding: 12, flexDirection: 'row', gap: 9, alignItems: 'flex-start' },
  errorText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 13, lineHeight: 19 },
  answerCard: { borderWidth: 1, borderRadius: 24, padding: 19, gap: 13 },
  answerHeader: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  answerIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  answerEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1 },
  answerTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, marginTop: 3 },
  answerBody: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 25 },
  keyHeading: { fontFamily: 'Inter_700Bold', fontSize: 15, marginTop: 3 },
  ideaRow: { flexDirection: 'row', gap: 8, alignItems: 'flex-start' },
  ideaText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21 },
  followUp: { borderRadius: 14, padding: 12, flexDirection: 'row', gap: 8, alignItems: 'flex-start', marginTop: 3 },
  followUpCopy: { flex: 1, gap: 3 },
  followUpLabel: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 0.8 },
  followUpText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 21 },
  starters: { gap: 10 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 19, marginBottom: 2 },
  starter: { borderWidth: 1, borderRadius: 17, padding: 14, flexDirection: 'row', gap: 10, alignItems: 'center' },
  starterCopy: { flex: 1 },
  starterTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  starterBody: { fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 19, marginTop: 3 },
  pressed: { opacity: 0.75, transform: [{ scale: 0.985 }] },
  disabled: { opacity: 0.6 },
});
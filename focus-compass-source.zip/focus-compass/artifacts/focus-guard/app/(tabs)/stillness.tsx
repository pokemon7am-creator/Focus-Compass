import { Feather } from '@expo/vector-icons';
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import * as Haptics from 'expo-haptics';
import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Animated, Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { BreathStyle, useRewards } from '@/context/RewardsContext';
import { useColors } from '@/hooks/useColors';
import { ambientAudioSources, soundscapeLabels } from '@/services/ambientAudio';

const durations = [1, 3, 5];

type BreathPhase = {
  name: string;
  seconds: number;
  scale: number;
};

type BreathVisual = {
  name: string;
  collection: string;
  icon: 'wind' | 'moon' | 'star' | 'sun' | 'zap' | 'file-text';
  card: string;
  tag: string;
  accent: string;
  inner: string;
  ink: string;
  shape: 'circle' | 'moon' | 'diamond' | 'sun' | 'aurora' | 'paper';
  rhythm: string;
  phases: readonly BreathPhase[];
};

const breathVisuals: Record<BreathStyle, BreathVisual> = {
  classic: {
    name: 'Classic',
    collection: 'Focus Compass Original',
    icon: 'wind',
    card: '#17242B',
    tag: '#294039',
    accent: '#328C68',
    inner: '#DCEADF',
    ink: '#174D3A',
    shape: 'circle',
    rhythm: '4 in · 2 hold · 6 out',
    phases: [
      { name: 'Breathe in', seconds: 4, scale: 1.42 },
      { name: 'Hold gently', seconds: 2, scale: 1.42 },
      { name: 'Breathe out', seconds: 6, scale: 1 },
    ],
  },
  moonlight: {
    name: 'Moonlight',
    collection: 'Moon Garden',
    icon: 'moon',
    card: '#18213A',
    tag: '#2A3557',
    accent: '#7888C7',
    inner: '#FFF1B8',
    ink: '#4B467A',
    shape: 'moon',
    rhythm: '4 in · 4 hold · 8 out',
    phases: [
      { name: 'Breathe in slowly', seconds: 4, scale: 1.4 },
      { name: 'Rest in the pause', seconds: 4, scale: 1.4 },
      { name: 'Long breath out', seconds: 8, scale: 1 },
    ],
  },
  starlight: {
    name: 'Starlight',
    collection: 'Paper Planets',
    icon: 'star',
    card: '#20213B',
    tag: '#38385E',
    accent: '#A887D8',
    inner: '#F4E9FF',
    ink: '#684D94',
    shape: 'diamond',
    rhythm: '5 in · 2 hold · 5 out',
    phases: [
      { name: 'Draw the breath in', seconds: 5, scale: 1.38 },
      { name: 'Hold the point', seconds: 2, scale: 1.38 },
      { name: 'Release evenly', seconds: 5, scale: 1 },
    ],
  },
  sunrise: {
    name: 'Sunrise',
    collection: 'Golden Hour',
    icon: 'sun',
    card: '#3B2722',
    tag: '#5A392C',
    accent: '#F19A4B',
    inner: '#FFF0C8',
    ink: '#9A4B24',
    shape: 'sun',
    rhythm: '4 in · 1 hold · 4 out',
    phases: [
      { name: 'Bright breath in', seconds: 4, scale: 1.45 },
      { name: 'Pause', seconds: 1, scale: 1.45 },
      { name: 'Easy breath out', seconds: 4, scale: 1 },
    ],
  },
  aurora: {
    name: 'Aurora',
    collection: 'Night Flight',
    icon: 'zap',
    card: '#172E33',
    tag: '#24484A',
    accent: '#45B8A8',
    inner: '#D9FFF4',
    ink: '#176F6C',
    shape: 'aurora',
    rhythm: '5 in · 3 hold · 7 out',
    phases: [
      { name: 'Breathe in deeply', seconds: 5, scale: 1.36 },
      { name: 'Float in the pause', seconds: 3, scale: 1.36 },
      { name: 'Flow the breath out', seconds: 7, scale: 1 },
    ],
  },
  paperfold: {
    name: 'Paper Fold',
    collection: 'Paper Planets',
    icon: 'file-text',
    card: '#21322F',
    tag: '#344943',
    accent: '#D99A3B',
    inner: '#FFF4D6',
    ink: '#6B4715',
    shape: 'paper',
    rhythm: '4 in · 4 hold · 6 out',
    phases: [
      { name: 'Unfold the breath', seconds: 4, scale: 1.4 },
      { name: 'Hold the fold', seconds: 4, scale: 1.4 },
      { name: 'Let the page settle', seconds: 6, scale: 1 },
    ],
  },
};

function formatTime(seconds: number) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
  const remainder = (seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${remainder}`;
}

export default function StillnessScreen() {
  const colors = useColors();
  const rewards = useRewards();
  const [selectedMinutes, setSelectedMinutes] = useState(3);
  const [remainingSeconds, setRemainingSeconds] = useState(3 * 60);
  const [targetEndAt, setTargetEndAt] = useState<number | null>(null);
  const [isRunning, setIsRunning] = useState(false);
  const [phaseIndex, setPhaseIndex] = useState(0);
  const [completed, setCompleted] = useState(false);
  const rewarded = useRef(false);
  const orbScale = useRef(new Animated.Value(1)).current;
  const breathVisual = breathVisuals[rewards.equipped.breath];
  const audioSource = rewards.soundscape === 'none' ? null : ambientAudioSources[rewards.soundscape];
  const audioPlayer = useAudioPlayer(audioSource, { updateInterval: 1000 });
  const audioStatus = useAudioPlayerStatus(audioPlayer);
  const [audioError, setAudioError] = useState<string | null>(null);

  useEffect(() => {
    if (!isRunning || rewards.soundscape === 'none') {
      try {
        audioPlayer.pause();
        audioPlayer.setActiveForLockScreen(false);
      } catch {
        // The player may already be released after a native audio interruption.
      }
      return;
    }

    let cancelled = false;
    void setAudioModeAsync({
      playsInSilentMode: true,
      interruptionMode: 'doNotMix',
      shouldPlayInBackground: true,
    })
      .then(() => {
        if (cancelled) return;
        audioPlayer.loop = true;
        audioPlayer.volume = 0.28;
        audioPlayer.setActiveForLockScreen(true, {
          title: soundscapeLabels[rewards.soundscape],
          artist: 'Focus Compass',
          albumTitle: 'Lo-fi focus',
        });
        audioPlayer.play();
      })
      .catch(() => {
        if (!cancelled) setAudioError('This soundscape could not start on this device.');
      });
    return () => {
      cancelled = true;
      try {
        audioPlayer.pause();
        audioPlayer.setActiveForLockScreen(false);
      } catch {
        // Playback errors are surfaced below and never interrupt Stillness.
      }
    };
  }, [audioPlayer, isRunning, rewards.soundscape]);

  useEffect(() => {
    if (audioStatus.error) setAudioError('This soundscape is unavailable right now.');
  }, [audioStatus.error]);

  const finishSession = useCallback(() => {
    if (rewarded.current) return;
    rewarded.current = true;
    setIsRunning(false);
    setTargetEndAt(null);
    setRemainingSeconds(0);
    setCompleted(true);
    rewards.completeStillness(selectedMinutes);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  }, [rewards, selectedMinutes]);

  useEffect(() => {
    if (!isRunning || !targetEndAt) return;
    const tick = () => {
      const next = Math.max(0, Math.ceil((targetEndAt - Date.now()) / 1000));
      setRemainingSeconds(next);
      if (next === 0) finishSession();
    };
    const timer = setInterval(tick, 250);
    tick();
    return () => clearInterval(timer);
  }, [finishSession, isRunning, targetEndAt]);

  useEffect(() => {
    if (!isRunning) {
      orbScale.stopAnimation();
      return;
    }

    const phases = breathVisual.phases;
    const phase = phases[phaseIndex];
    Animated.timing(orbScale, {
      toValue: phase.scale,
      duration: phase.seconds * 1000,
      useNativeDriver: true,
    }).start();
    const timer = setTimeout(() => setPhaseIndex((value) => (value + 1) % phases.length), phase.seconds * 1000);
    return () => clearTimeout(timer);
  }, [breathVisual.phases, isRunning, orbScale, phaseIndex]);

  const start = () => {
    rewarded.current = false;
    setCompleted(false);
    setPhaseIndex(0);
    setRemainingSeconds(selectedMinutes * 60);
    setTargetEndAt(Date.now() + selectedMinutes * 60 * 1000);
    setIsRunning(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  const togglePause = () => {
    if (isRunning) {
      const next = targetEndAt
        ? Math.max(0, Math.ceil((targetEndAt - Date.now()) / 1000))
        : remainingSeconds;
      setRemainingSeconds(next);
      setTargetEndAt(null);
      setIsRunning(false);
    } else if (remainingSeconds > 0) {
      setTargetEndAt(Date.now() + remainingSeconds * 1000);
      setIsRunning(true);
    }
    Haptics.selectionAsync();
  };

  const selectDuration = (minutes: number) => {
    if (isRunning) return;
    setSelectedMinutes(minutes);
    setRemainingSeconds(minutes * 60);
    setCompleted(false);
    rewarded.current = false;
  };

  const selectSoundscape = (soundscape: typeof rewards.soundscape) => {
    setAudioError(null);
    rewards.setSoundscape(soundscape);
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>STILLNESS</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Breathe. Grow your grove.</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Follow the circle. Every completed minute earns one leaf.
        </Text>
      </View>

      <View style={[styles.groveCard, { backgroundColor: colors.secondary }]}>
        <View style={styles.groveCopy}>
          <Text style={[styles.groveLabel, { color: colors.secondaryForeground }]}>YOUR GROVE</Text>
          <Text style={[styles.groveValue, { color: colors.secondaryForeground }]}>{rewards.leaves} leaves</Text>
          <Text style={[styles.groveCaption, { color: colors.mutedForeground }]}>
            {rewards.mindfulMinutes} mindful {rewards.mindfulMinutes === 1 ? 'minute' : 'minutes'} completed
          </Text>
        </View>
        <View style={[styles.tree, { backgroundColor: colors.card }]}>
          <Feather name={rewards.leaves > 0 ? 'feather' : 'circle'} size={29} color={colors.primary} />
        </View>
      </View>

      <View
        style={[
          styles.breatheCard,
          { backgroundColor: breathVisual.card, borderColor: breathVisual.accent },
          styles.themedBreatheCard,
        ]}
      >
        <View style={[styles.breathThemeTag, { backgroundColor: breathVisual.tag }]}>
          <Feather name={breathVisual.icon} size={14} color={breathVisual.inner} />
          <Text style={[styles.breathThemeText, { color: breathVisual.inner }]}>
            {breathVisual.collection.toUpperCase()} · {breathVisual.name.toUpperCase()}
          </Text>
        </View>
        <Text style={styles.phase}>
          {completed ? 'Stillness complete' : isRunning ? breathVisual.phases[phaseIndex].name : 'Ready when you are'}
        </Text>
        <Text style={[styles.rhythm, { color: breathVisual.inner }]}>{breathVisual.rhythm}</Text>
        <View style={styles.orbStage}>
          <Animated.View
            style={[
              styles.orbOuter,
              breathVisual.shape === 'diamond' && styles.starlightOrbOuter,
              breathVisual.shape === 'sun' && styles.sunriseOrbOuter,
              breathVisual.shape === 'aurora' && styles.auroraOrbOuter,
              breathVisual.shape === 'paper' && styles.paperOrbOuter,
              {
                backgroundColor: breathVisual.accent,
                borderColor: breathVisual.inner,
                transform:
                  breathVisual.shape === 'paper'
                    ? [{ scale: orbScale }, { rotate: '-4deg' }]
                    : breathVisual.shape === 'diamond'
                      ? [{ scale: orbScale }, { rotate: '45deg' }]
                      : [{ scale: orbScale }],
              },
            ]}
          >
            {breathVisual.shape === 'paper' || breathVisual.shape === 'diamond' || breathVisual.shape === 'moon' ? (
              <>
                <View style={[styles.orbitDot, styles.orbitDotOne, { backgroundColor: breathVisual.inner }]} />
                <View style={[styles.orbitDot, styles.orbitDotTwo, { backgroundColor: breathVisual.inner }]} />
                <View style={[styles.orbitDot, styles.orbitDotThree, { backgroundColor: breathVisual.inner }]} />
              </>
            ) : null}
            {breathVisual.shape === 'sun' ? (
              <>
                <View style={[styles.sunRay, styles.sunRayTop, { backgroundColor: breathVisual.inner }]} />
                <View style={[styles.sunRay, styles.sunRayRight, { backgroundColor: breathVisual.inner }]} />
                <View style={[styles.sunRay, styles.sunRayBottom, { backgroundColor: breathVisual.inner }]} />
                <View style={[styles.sunRay, styles.sunRayLeft, { backgroundColor: breathVisual.inner }]} />
              </>
            ) : null}
            {breathVisual.shape === 'aurora' ? (
              <>
                <View style={[styles.auroraBand, styles.auroraBandOne]} />
                <View style={[styles.auroraBand, styles.auroraBandTwo]} />
                <View style={[styles.auroraBand, styles.auroraBandThree]} />
              </>
            ) : null}
            <View
              style={[
                styles.orbInner,
                { backgroundColor: breathVisual.inner },
                breathVisual.shape === 'diamond' && styles.starlightOrbInner,
                breathVisual.shape === 'sun' && styles.sunriseOrbInner,
                breathVisual.shape === 'aurora' && styles.auroraOrbInner,
                breathVisual.shape === 'paper' && styles.paperOrbInner,
                breathVisual.shape === 'diamond' && { transform: [{ rotate: '-45deg' }] },
              ]}
            >
              {breathVisual.shape === 'paper' ? <View style={styles.foldedCorner} /> : null}
              <Feather
                name={completed ? 'check' : breathVisual.icon}
                size={34}
                color={breathVisual.ink}
              />
            </View>
          </Animated.View>
        </View>
        <Text style={styles.timer}>{formatTime(remainingSeconds)}</Text>

        {!isRunning && !completed && remainingSeconds === selectedMinutes * 60 ? (
          <>
            <View style={styles.durationRow}>
              {durations.map((duration) => (
                <Pressable
                  key={duration}
                  onPress={() => selectDuration(duration)}
                  style={[
                    styles.duration,
                    {
                      borderColor: selectedMinutes === duration ? colors.accent : '#63716C',
                      backgroundColor: selectedMinutes === duration ? '#31433F' : 'transparent',
                    },
                  ]}
                >
                  <Text style={[styles.durationText, { color: selectedMinutes === duration ? colors.accent : '#F4F0E7' }]}>
                    {duration} min
                  </Text>
                </Pressable>
              ))}
            </View>
            <Pressable
              testID="start-stillness"
              onPress={start}
              style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary }, pressed && styles.pressed]}
            >
              <Feather name="play" size={19} color={colors.primaryForeground} />
              <Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Begin breathing</Text>
            </Pressable>
          </>
        ) : completed ? (
          <Pressable
            testID="reset-stillness"
            onPress={() => selectDuration(selectedMinutes)}
            style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary }, pressed && styles.pressed]}
          >
            <Feather name="refresh-cw" size={19} color={colors.primaryForeground} />
            <Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Breathe again</Text>
          </Pressable>
        ) : (
          <Pressable
            testID="pause-stillness"
            onPress={togglePause}
            style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.card }, pressed && styles.pressed]}
          >
            <Feather name={isRunning ? 'pause' : 'play'} size={19} color={colors.foreground} />
            <Text style={[styles.primaryText, { color: colors.foreground }]}>{isRunning ? 'Pause' : 'Continue'}</Text>
          </Pressable>
        )}
      </View>

      <View style={[styles.soundCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.soundHeading}>
          <View style={styles.soundCopy}>
            <Text style={[styles.soundTitle, { color: colors.foreground }]}>Ambient focus sounds</Text>
            <Text style={[styles.soundSubtitle, { color: colors.mutedForeground }]}>
              Original lo-fi tracks loop during Stillness, even while Focus Compass is in the background.
            </Text>
          </View>
          <Feather name="volume-2" size={21} color={colors.primary} />
        </View>
        <View style={styles.soundOptions}>
          {(Object.keys(soundscapeLabels) as Array<typeof rewards.soundscape>).map((soundscape) => (
            <Pressable
              key={soundscape}
              testID={`soundscape-${soundscape}`}
              onPress={() => selectSoundscape(soundscape)}
              style={[
                styles.soundOption,
                {
                  borderColor: rewards.soundscape === soundscape ? colors.primary : colors.border,
                  backgroundColor: rewards.soundscape === soundscape ? colors.secondary : 'transparent',
                },
              ]}
            >
              <Text style={[styles.soundOptionText, { color: rewards.soundscape === soundscape ? colors.secondaryForeground : colors.foreground }]}>
                {soundscapeLabels[soundscape]}
              </Text>
            </Pressable>
          ))}
        </View>
        {audioError ? <Text style={[styles.soundError, { color: colors.destructive }]}>{audioError}</Text> : null}
      </View>

    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', marginBottom: 20 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, marginBottom: 7, textAlign: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.7, textAlign: 'center' },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, marginTop: 7, textAlign: 'center' },
  groveCard: { borderRadius: 22, padding: 18, flexDirection: 'row', alignItems: 'center' },
  groveCopy: { flex: 1 },
  groveLabel: { fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 1 },
  groveValue: { fontFamily: 'Inter_700Bold', fontSize: 25, marginTop: 7 },
  groveCaption: { fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 20, marginTop: 3 },
  tree: { width: 58, height: 58, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  breatheCard: { borderRadius: 28, padding: 22, minHeight: 430, alignItems: 'center' },
  themedBreatheCard: { borderWidth: 1 },
  breathThemeTag: { minHeight: 30, borderRadius: 15, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 7 },
  breathThemeText: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.8 },
  phase: { color: '#F4F0E7', fontFamily: 'Inter_700Bold', fontSize: 20, textAlign: 'center', marginTop: 14 },
  rhythm: { fontFamily: 'Inter_600SemiBold', fontSize: 13, letterSpacing: 0.3, marginTop: 5 },
  orbStage: { height: 170, alignItems: 'center', justifyContent: 'center' },
  orbOuter: { width: 116, height: 116, borderRadius: 58, alignItems: 'center', justifyContent: 'center', opacity: 0.94 },
  starlightOrbOuter: { width: 104, height: 104, borderRadius: 26, borderWidth: 2, opacity: 1 },
  sunriseOrbOuter: { width: 106, height: 106, borderRadius: 53, borderWidth: 4, opacity: 1 },
  auroraOrbOuter: { width: 100, height: 126, borderRadius: 50, borderWidth: 2, opacity: 1, overflow: 'hidden' },
  paperOrbOuter: { borderRadius: 24, borderWidth: 2, borderColor: '#FFE8A6', opacity: 1 },
  orbInner: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center' },
  starlightOrbInner: { width: 66, height: 66, borderRadius: 18 },
  sunriseOrbInner: { width: 62, height: 62, borderRadius: 31 },
  auroraOrbInner: { width: 62, height: 82, borderRadius: 31, borderWidth: 1, borderColor: '#A5F0D8' },
  paperOrbInner: { width: 78, height: 86, borderRadius: 12, borderWidth: 1, borderColor: '#D7B774', overflow: 'hidden' },
  foldedCorner: { position: 'absolute', top: 0, right: 0, width: 20, height: 20, backgroundColor: '#E9CD8E', borderBottomLeftRadius: 8 },
  orbitDot: { position: 'absolute', width: 8, height: 8, borderRadius: 4 },
  orbitDotOne: { top: 12, left: 16 },
  orbitDotTwo: { right: 10, top: 42, width: 6, height: 6, borderRadius: 3 },
  orbitDotThree: { bottom: 12, left: 24, width: 5, height: 5, borderRadius: 3 },
  sunRay: { position: 'absolute', width: 5, height: 17, borderRadius: 3 },
  sunRayTop: { top: -14 },
  sunRayRight: { right: -8, transform: [{ rotate: '90deg' }] },
  sunRayBottom: { bottom: -14 },
  sunRayLeft: { left: -8, transform: [{ rotate: '90deg' }] },
  auroraBand: { position: 'absolute', width: 150, height: 18, borderRadius: 9, transform: [{ rotate: '-28deg' }] },
  auroraBandOne: { top: 13, backgroundColor: '#83D9B7' },
  auroraBandTwo: { top: 48, backgroundColor: '#6D93D1' },
  auroraBandThree: { bottom: 9, backgroundColor: '#C68AD1' },
  timer: { color: '#FFF9F1', fontFamily: 'Inter_700Bold', fontSize: 43, letterSpacing: -1.5 },
  durationRow: { flexDirection: 'row', gap: 9, marginTop: 18 },
  duration: { borderWidth: 1, borderRadius: 16, paddingHorizontal: 13, paddingVertical: 9 },
  durationText: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  primaryButton: { width: '100%', height: 56, borderRadius: 18, marginTop: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  primaryText: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  soundCard: { borderWidth: 1, borderRadius: 20, padding: 16, gap: 13 },
  soundHeading: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  soundCopy: { flex: 1 },
  soundTitle: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  soundSubtitle: { fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 19, marginTop: 4 },
  soundOptions: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  soundOption: { borderWidth: 1, borderRadius: 13, paddingHorizontal: 11, paddingVertical: 9 },
  soundOptionText: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  soundError: { fontFamily: 'Inter_600SemiBold', fontSize: 12, lineHeight: 18 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.985 }] },
});
import { Feather } from '@expo/vector-icons';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useFocus } from '@/context/FocusContext';
import { useColors } from '@/hooks/useColors';

function formatProtectedDate(dateKey: string | null) {
  if (!dateKey) return 'No day protected yet';
  const [year, month, day] = dateKey.split('-').map(Number);
  return `Latest protection: ${new Date(year, month - 1, day).toLocaleDateString(undefined, {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })}`;
}

export default function InsightsScreen() {
  const colors = useColors();
  const focus = useFocus();
  const maxMinutes = Math.max(...focus.weeklyMinutes.map((item) => item.minutes), 0);
  const chartScale = Math.max(maxMinutes, 1);

  return (
    <Screen>
      <View>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>YOUR WEEK</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Attention is compounding.</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>A steady week beats a perfect day.</Text>
      </View>

      <View style={[styles.hero, { backgroundColor: colors.foreground }]}>
        <View>
          <Text style={styles.heroLabel}>FOCUS THIS WEEK</Text>
          <Text style={[styles.heroValue, { color: colors.accent }]}>{focus.minutesFocusedThisWeek}m</Text>
          <Text style={styles.heroDelta}>
            {focus.sessionsThisWeek} completed {focus.sessionsThisWeek === 1 ? 'session' : 'sessions'}
          </Text>
        </View>
        <View style={[styles.ring, { borderColor: colors.primary }]}>
          <Feather name="trending-up" size={29} color={colors.primary} />
        </View>
      </View>

      <View style={[styles.chartCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.chartHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Protected minutes</Text>
          <Text style={[styles.chartTotal, { color: colors.primary }]}>{focus.minutesFocusedThisWeek}m</Text>
        </View>
        <View style={styles.chartScale} accessibilityLabel={`Chart scale: zero to ${maxMinutes} minutes`}>
          <Text style={[styles.scaleLabel, { color: colors.mutedForeground }]}>
            {maxMinutes}m
          </Text>
          <Text style={[styles.scaleLabel, { color: colors.mutedForeground }]}>0m</Text>
        </View>
        <View style={styles.bars}>
          {focus.weeklyMinutes.map((item, index) => (
            <View
              key={item.dateKey}
              accessible
              accessibilityLabel={`${item.day}, ${item.date}: ${item.minutes} recorded ${item.minutes === 1 ? 'minute' : 'minutes'}`}
              style={styles.barColumn}
            >
              <Text style={[styles.barValue, { color: colors.foreground }]}>
                {item.minutes}m
              </Text>
              <View style={[styles.barTrack, { backgroundColor: colors.muted }]}>
                <View
                  style={[
                    styles.bar,
                    {
                      height: item.minutes ? `${(item.minutes / chartScale) * 100}%` : '0%',
                      backgroundColor: index === focus.weeklyMinutes.length - 1 ? colors.primary : colors.sage,
                    },
                  ]}
                />
              </View>
              <Text style={[styles.day, { color: colors.mutedForeground }]}>{item.day}</Text>
              <Text style={[styles.date, { color: colors.mutedForeground }]}>{item.date}</Text>
            </View>
          ))}
        </View>
      </View>

      <View style={styles.metrics}>
        <View style={[styles.metric, { backgroundColor: colors.secondary }]}>
          <Feather name="repeat" size={19} color={colors.secondaryForeground} />
          <Text style={[styles.metricValue, { color: colors.secondaryForeground }]}>{focus.overridesToday}</Text>
          <Text style={[styles.metricLabel, { color: colors.mutedForeground }]}>override today</Text>
        </View>
        <View style={[styles.metric, { backgroundColor: colors.accent }]}>
          <Feather name="calendar" size={19} color={colors.accentForeground} />
          <Text style={[styles.metricValue, { color: colors.accentForeground }]}>{focus.streakDays}</Text>
          <Text style={[styles.metricLabel, { color: colors.accentForeground }]}>day streak</Text>
        </View>
      </View>

      <View style={[styles.stasisCard, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
        <View style={[styles.stasisIcon, { backgroundColor: colors.accent }]}>
          <Feather name="shield" size={22} color={colors.accentForeground} />
        </View>
        <View style={styles.stasisCopy}>
          <View style={styles.stasisHeader}>
            <Text style={[styles.stasisTitle, { color: colors.secondaryForeground }]}>Stasis protection</Text>
            <Text style={[styles.stasisBalance, { color: colors.secondaryForeground }]}>
              {focus.stasisTokens} {focus.stasisTokens === 1 ? 'token' : 'tokens'}
            </Text>
          </View>
          <Text style={[styles.stasisBody, { color: colors.mutedForeground }]}>
            One token automatically protects the next missed local day after a focused day, so your streak can keep its shape.
          </Text>
          <Text style={[styles.stasisDate, { color: colors.secondaryForeground }]}>
            {formatProtectedDate(focus.latestProtectedDate)}
          </Text>
        </View>
      </View>

      <View style={[styles.reflectionCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.reflectionHeader}>
          <View>
            <Text style={[styles.reflectionEyebrow, { color: colors.primary }]}>REFLECTION PATTERN</Text>
            <Text style={[styles.reflectionTitle, { color: colors.foreground }]}>How focus felt this week</Text>
          </View>
          <Feather name="edit-3" size={22} color={colors.primary} />
        </View>
        <View style={styles.reflectionMetrics}>
          {[
            { label: 'Clear', value: focus.reflectionSummary.clear, icon: 'sun' as const },
            { label: 'Okay', value: focus.reflectionSummary.okay, icon: 'minus-circle' as const },
            { label: 'Scattered', value: focus.reflectionSummary.scattered, icon: 'cloud' as const },
          ].map((item) => (
            <View key={item.label} style={[styles.reflectionMetric, { backgroundColor: colors.secondary }]}>
              <Feather name={item.icon} size={17} color={colors.secondaryForeground} />
              <Text style={[styles.reflectionValue, { color: colors.secondaryForeground }]}>{item.value}</Text>
              <Text style={[styles.reflectionLabel, { color: colors.mutedForeground }]}>{item.label}</Text>
            </View>
          ))}
        </View>
        <Text style={[styles.reflectionNote, { color: colors.mutedForeground }]}>
          {focus.latestReflectionNote
            ? `Latest note: “${focus.latestReflectionNote}”`
            : 'Finish a focus session and add a reflection to see patterns here.'}
        </Text>
      </View>

      <View style={[styles.insight, { borderColor: colors.border }]}>
        <Feather name="compass" size={22} color={colors.primary} />
        <View style={styles.insightCopy}>
          <Text style={[styles.insightTitle, { color: colors.foreground }]}>
            {focus.minutesFocusedThisWeek
              ? `${focus.minutesFocusedThisWeek} verified focus minutes this week`
              : 'No completed sessions recorded yet'}
          </Text>
          <Text style={[styles.insightBody, { color: colors.mutedForeground }]}>
            {focus.minutesFocusedThisWeek
              ? 'Completed timers and recorded partial sessions count toward this total.'
              : 'Finish a focus timer to start building your weekly history.'}
          </Text>
        </View>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, marginBottom: 7 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.7 },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, marginTop: 7 },
  hero: { borderRadius: 24, padding: 22, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  heroLabel: { color: '#D6DEDA', fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 1 },
  heroValue: { fontFamily: 'Inter_700Bold', fontSize: 48, letterSpacing: -2, marginTop: 5 },
  heroDelta: { color: '#E0E6E3', fontFamily: 'Inter_600SemiBold', fontSize: 14, marginTop: 3 },
  ring: { width: 74, height: 74, borderRadius: 37, borderWidth: 8, alignItems: 'center', justifyContent: 'center' },
  chartCard: { borderRadius: 22, borderWidth: 1, padding: 18 },
  chartHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 19 },
  chartTotal: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  chartScale: { height: 18, justifyContent: 'space-between', alignItems: 'flex-end', marginTop: 14 },
  scaleLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  bars: { height: 172, flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginTop: 2 },
  barColumn: { flex: 1, alignItems: 'center', gap: 3 },
  barValue: { fontFamily: 'Inter_700Bold', fontSize: 11, height: 16 },
  barTrack: { width: '100%', height: 112, borderRadius: 8, overflow: 'hidden', justifyContent: 'flex-end' },
  bar: { width: '100%', borderRadius: 10 },
  day: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  date: { fontFamily: 'Inter_500Medium', fontSize: 10 },
  metrics: { flexDirection: 'row', gap: 12 },
  metric: { flex: 1, borderRadius: 20, padding: 16 },
  metricValue: { fontFamily: 'Inter_700Bold', fontSize: 26, marginTop: 13 },
  metricLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 13, marginTop: 3 },
  stasisCard: { borderRadius: 20, borderWidth: 1, padding: 16, flexDirection: 'row', gap: 13 },
  stasisIcon: { width: 46, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  stasisCopy: { flex: 1, gap: 5 },
  stasisHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 8 },
  stasisTitle: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  stasisBalance: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  stasisBody: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21 },
  stasisDate: { fontFamily: 'Inter_600SemiBold', fontSize: 13, marginTop: 2 },
  reflectionCard: { borderRadius: 22, borderWidth: 1, padding: 17 },
  reflectionHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  reflectionEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.9 },
  reflectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 18, marginTop: 5 },
  reflectionMetrics: { flexDirection: 'row', gap: 8, marginTop: 15 },
  reflectionMetric: { flex: 1, minHeight: 88, borderRadius: 16, padding: 11 },
  reflectionValue: { fontFamily: 'Inter_700Bold', fontSize: 22, marginTop: 8 },
  reflectionLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 11, marginTop: 2 },
  reflectionNote: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21, marginTop: 14 },
  insight: { borderTopWidth: 1, paddingTop: 17, flexDirection: 'row', gap: 13 },
  insightCopy: { flex: 1 },
  insightTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  insightBody: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 22, marginTop: 5 },
});
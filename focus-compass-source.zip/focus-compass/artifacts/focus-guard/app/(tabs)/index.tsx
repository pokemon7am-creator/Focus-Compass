import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useFocus } from '@/context/FocusContext';
import { useRevenueCat } from '@/context/RevenueCatContext';
import { useColors } from '@/hooks/useColors';

const durations = [15, 25, 45];

function formatTime(seconds: number) {
  const minutes = Math.floor(seconds / 60).toString().padStart(2, '0');
  const remainder = (seconds % 60).toString().padStart(2, '0');
  return `${minutes}:${remainder}`;
}

function formatMinutes(minutes: number) {
  if (minutes < 60) return `${minutes}m`;
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  return remainder ? `${hours}h ${remainder}m` : `${hours}h`;
}

export default function TodayScreen() {
  const colors = useColors();
  const focus = useFocus();
  const revenueCat = useRevenueCat();
  const [selectedMinutes, setSelectedMinutes] = useState(25);
  const isIOS = Platform.OS === 'ios';
  const activeCount = focus.apps.filter((app) => app.active).length;
  const progress = focus.sessionSeconds ? focus.remainingSeconds / focus.sessionSeconds : 0;
  const dateLabel = new Intl.DateTimeFormat(undefined, {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  }).format(new Date()).toUpperCase();
  const todayMinutes = focus.weeklyMinutes.at(-1)?.minutes ?? 0;

  useEffect(() => {
    if (!focus.hydrated || !focus.pendingReflectionId || focus.hasActiveSession) return;
    router.replace('/reflection');
  }, [focus.hydrated, focus.hasActiveSession, focus.pendingReflectionId]);

  return (
    <Screen>
      <View style={styles.header}>
        <View style={styles.headerCopy}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>{dateLabel}</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Protect your attention.</Text>
        </View>
        <Pressable
          testID="open-premium"
          accessibilityLabel="Open Focus Compass Premium"
          onPress={() => router.push('/paywall')}
          style={({ pressed }) => [
            styles.premiumButton,
            { backgroundColor: revenueCat.isPremium ? colors.accent : colors.card, borderColor: colors.border },
            pressed && styles.pressed,
          ]}
        >
          <Feather name={revenueCat.isPremium ? 'award' : 'zap'} size={19} color={colors.foreground} />
          <Text style={[styles.premiumButtonText, { color: colors.foreground }]}>
            {revenueCat.isPremium ? 'Member' : 'Focus Compass Premium'}
          </Text>
        </Pressable>
      </View>

      <LinearGradient
        colors={[colors.foreground, '#293C3A']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.timerCard}
      >
        <View style={styles.timerTop}>
          <View style={styles.guardPill}>
            <View style={[styles.dot, { backgroundColor: focus.isRunning ? colors.success : colors.warning }]} />
              <Text style={styles.guardPillText}>
                {focus.isRunning
                  ? 'FOCUSING NOW'
                  : isIOS
                    ? focus.hasActiveSession
                      ? 'FOCUS PAUSED'
                      : 'FOCUS TIMER READY'
                    : `${activeCount} APPS SELECTED`}
              </Text>
          </View>
            <Feather name={isIOS ? 'clock' : 'shield'} size={24} color={colors.accent} />
        </View>
        <Text style={styles.timer}>{formatTime(focus.remainingSeconds)}</Text>
        <Text style={styles.timerCaption}>
          {focus.isRunning
            ? isIOS
              ? 'Stay with your intention until the timer ends.'
              : 'Timer running. App selection does not yet enforce device-level blocking.'
            : isIOS && focus.hasActiveSession
              ? 'Your focus timer is paused.'
              : 'Choose a focus window and begin.'}
        </Text>
        {!focus.hasActiveSession ? (
          <>
            <View style={styles.durationRow}>
              {durations.map((duration) => (
                <Pressable
                  key={duration}
                  onPress={() => setSelectedMinutes(duration)}
                  style={[
                    styles.duration,
                    { borderColor: selectedMinutes === duration ? colors.accent : '#52605E' },
                    selectedMinutes === duration && { backgroundColor: '#3B4947' },
                  ]}
                >
                  <Text style={[styles.durationText, { color: selectedMinutes === duration ? colors.accent : '#D9DFDC' }]}>
                    {duration}m
                  </Text>
                </Pressable>
              ))}
            </View>
            <Pressable
              testID="start-focus"
              onPress={() => focus.startSession(selectedMinutes)}
              style={({ pressed }) => [styles.startButton, { backgroundColor: colors.primary }, pressed && styles.pressed]}
            >
              <Feather name="play" size={18} color={colors.primaryForeground} />
              <Text style={[styles.startText, { color: colors.primaryForeground }]}>Start focus</Text>
            </Pressable>
          </>
        ) : (
          <View style={styles.sessionActions}>
            <Pressable
              testID="pause-focus"
              onPress={focus.toggleSession}
              style={({ pressed }) => [styles.roundButton, pressed && styles.pressed]}
            >
              <Feather name={focus.isRunning ? 'pause' : 'play'} size={22} color={colors.foreground} />
            </Pressable>
            <Pressable
              testID="end-focus"
              onPress={() => router.push('/roast?mode=end-session')}
              style={({ pressed }) => [styles.endButton, pressed && styles.pressed]}
            >
              <Text style={styles.endText}>End session</Text>
            </Pressable>
          </View>
        )}
        <View style={styles.progressTrack}>
          <View
            style={[
              styles.progressFill,
              {
                width: `${Math.max(0, Math.min(100, progress * 100))}%`,
                backgroundColor: colors.accent,
              },
            ]}
          />
        </View>
      </LinearGradient>

      <View style={styles.statsRow}>
        {[
          { value: String(focus.streakDays), label: 'day streak', icon: 'sun' as const },
          { value: formatMinutes(focus.minutesFocused), label: 'focused', icon: 'clock' as const },
          { value: String(focus.completedSessions), label: 'today', icon: 'check-circle' as const },
        ].map((stat) => (
          <View key={stat.label} style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <Feather name={stat.icon} size={17} color={colors.primary} />
            <Text style={[styles.statValue, { color: colors.foreground }]}>{stat.value}</Text>
            <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{stat.label}</Text>
          </View>
        ))}
      </View>

      <View style={[styles.nudge, { backgroundColor: colors.secondary }]}>
        <View style={[styles.nudgeIcon, { backgroundColor: colors.card }]}>
          <Feather name="trending-up" size={19} color={colors.secondaryForeground} />
        </View>
        <View style={styles.nudgeCopy}>
          <Text style={[styles.nudgeTitle, { color: colors.secondaryForeground }]}>
            {todayMinutes ? `${formatMinutes(todayMinutes)} focused today` : 'Build your first real insight'}
          </Text>
          <Text style={[styles.nudgeBody, { color: colors.mutedForeground }]}>
            {todayMinutes
              ? `${focus.completedSessions} completed ${focus.completedSessions === 1 ? 'session' : 'sessions'} recorded today.`
              : 'Complete a timer and Focus Compass will record it here.'}
          </Text>
        </View>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', gap: 12, marginBottom: 20 },
  headerCopy: { alignItems: 'center' },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, marginBottom: 7, textAlign: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.7, textAlign: 'center' },
  premiumButton: { minHeight: 44, borderRadius: 17, borderWidth: 1, paddingHorizontal: 16, paddingVertical: 10, flexDirection: 'row', alignItems: 'center', gap: 6 },
  premiumButtonText: { fontFamily: 'Inter_700Bold', fontSize: 13, textAlign: 'center', flexShrink: 1 },
  timerCard: { borderRadius: 28, padding: 22, minHeight: 390 },
  timerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  guardPill: { flexDirection: 'row', alignItems: 'center', gap: 8, borderRadius: 20, backgroundColor: '#FFFFFF14', paddingHorizontal: 12, paddingVertical: 8 },
  dot: { width: 7, height: 7, borderRadius: 4 },
  guardPillText: { color: '#F4F0E7', fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 0.8 },
  timer: { color: '#FFF9F1', fontFamily: 'Inter_700Bold', fontSize: 68, letterSpacing: -2.5, textAlign: 'center', marginTop: 42 },
  timerCaption: { color: '#E1E7E4', fontFamily: 'Inter_500Medium', fontSize: 16, textAlign: 'center', lineHeight: 24, paddingHorizontal: 8, marginTop: 4 },
  durationRow: { flexDirection: 'row', gap: 10, justifyContent: 'center', marginTop: 28 },
  duration: { borderWidth: 1, borderRadius: 18, paddingHorizontal: 16, paddingVertical: 9 },
  durationText: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  startButton: { minHeight: 54, borderRadius: 18, marginTop: 18, flexDirection: 'row', gap: 9, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 16, paddingVertical: 12 },
  startText: { fontFamily: 'Inter_700Bold', fontSize: 17, textAlign: 'center', flexShrink: 1 },
  sessionActions: { flexDirection: 'row', justifyContent: 'center', gap: 12, marginTop: 32 },
  roundButton: { width: 54, height: 54, borderRadius: 27, backgroundColor: '#FFF9F1', alignItems: 'center', justifyContent: 'center' },
  endButton: { height: 54, borderRadius: 27, backgroundColor: '#FFFFFF14', paddingHorizontal: 22, justifyContent: 'center' },
  endText: { color: '#FFF9F1', fontFamily: 'Inter_700Bold', fontSize: 16 },
  progressTrack: { height: 4, borderRadius: 2, backgroundColor: '#FFFFFF1A', overflow: 'hidden', marginTop: 'auto' },
  progressFill: { height: 4, borderRadius: 2 },
  statsRow: { flexDirection: 'row', gap: 10 },
  statCard: { flex: 1, borderWidth: 1, borderRadius: 18, padding: 13, minHeight: 98 },
  statValue: { fontFamily: 'Inter_700Bold', fontSize: 21, marginTop: 8 },
  statLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 13, marginTop: 3 },
  nudge: { flexDirection: 'row', padding: 16, borderRadius: 20, alignItems: 'center', gap: 13 },
  nudgeIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  nudgeCopy: { flex: 1 },
  nudgeTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  nudgeBody: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21, marginTop: 4 },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});

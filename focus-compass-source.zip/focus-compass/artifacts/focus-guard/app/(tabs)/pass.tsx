import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useFocus } from '@/context/FocusContext';
import { PassReward, useProgression } from '@/context/ProgressionContext';
import { paperPlanetsCollectibles, useRewards } from '@/context/RewardsContext';
import { useColors } from '@/hooks/useColors';
import { soundscapeLabels } from '@/services/ambientAudio';

function RewardLane({
  reward,
  premium,
  unlocked,
  claimed,
  isPremium,
  busy,
  onClaim,
}: {
  reward: PassReward;
  premium: boolean;
  unlocked: boolean;
  claimed: boolean;
  isPremium: boolean;
  busy: boolean;
  onClaim: () => void;
}) {
  const colors = useColors();
  const premiumLocked = premium && !isPremium;
  const canPress = unlocked || premiumLocked;

  return (
    <View style={[styles.lane, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <View style={styles.laneHeading}>
        <Text style={[styles.laneLabel, { color: colors.foreground }]}>{premium ? 'PREMIUM' : 'FREE'}</Text>
        {premium ? <Feather name="zap" size={13} color={colors.accentForeground} /> : <Feather name="check" size={13} color={colors.primary} />}
      </View>
      <View style={[styles.laneIcon, { backgroundColor: premium ? colors.accent : colors.secondary }]}>
        <Feather name={reward.icon} size={18} color={premium ? colors.accentForeground : colors.secondaryForeground} />
      </View>
      <Text numberOfLines={2} style={[styles.laneTitle, { color: colors.foreground }]}>{reward.title}</Text>
      <Text numberOfLines={3} style={[styles.laneDescription, { color: colors.mutedForeground }]}>
        {reward.description}
      </Text>
      <Pressable
        testID={`pass-reward-${premium ? 'premium' : 'free'}-${reward.tier}`}
        disabled={busy || claimed || !canPress}
        onPress={onClaim}
        style={({ pressed }) => [
          styles.claimButton,
          {
            backgroundColor: claimed ? colors.secondary : canPress ? colors.primary : colors.muted,
          },
          pressed && styles.pressed,
        ]}
      >
        <Text style={[styles.claimText, { color: claimed || canPress ? colors.primaryForeground : colors.mutedForeground }]}>
          {claimed ? 'Claimed' : busy ? 'Please wait…' : premiumLocked ? 'Focus Compass Premium' : unlocked ? 'Claim' : 'Locked'}
        </Text>
      </Pressable>
    </View>
  );
}

export default function PassScreen() {
  const colors = useColors();
  const progression = useProgression();
  const rewards = useRewards();
  const focus = useFocus();
  const [claimNotice, setClaimNotice] = useState<string | null>(null);
  const progress = progression.level === progression.maxLevels
    ? progression.minutesIntoLevel / progression.minutesPerLevel
    : progression.minutesIntoLevel / progression.minutesPerLevel;
  const endLabel = new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(
    new Date(progression.seasonEndsAt),
  );
  const claim = async (reward: PassReward) => {
    setClaimNotice(null);
    const result = await progression.claimReward(reward);
    if (result.status === 'claimed') {
      setClaimNotice(
        reward.kind === 'unlock'
          ? `${reward.title} unlocked and equipped. You can change it in Shop.`
          : `${reward.title} added to your Shop wallet.`,
      );
    } else {
      setClaimNotice(result.status === 'already-claimed' ? 'This reward has already been claimed.' : result.message ?? 'Could not claim this reward.');
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <View style={styles.headerCopy}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>FOCUS COMPASS PASS</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>A new season every month.</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {progression.themeSubtitle} Earn one level for every 20 verified focus minutes.
          </Text>
        </View>
        <View style={styles.levelBadgeContainer}>
          <View style={[styles.levelBadge, { backgroundColor: colors.accent }]}>
            <Text style={[styles.levelNumber, { color: colors.accentForeground }]}>{progression.level}</Text>
            <Text style={[styles.levelLabel, { color: colors.accentForeground }]}>OF 50</Text>
          </View>
        </View>
      </View>

      <View style={[styles.hero, { backgroundColor: colors.deepBackground }]}>
        <View style={styles.heroTop}>
          <View style={styles.heroCopy}>
            <View style={styles.themeRow}>
              <Feather name={progression.themeIcon} size={15} color={colors.accent} />
              <Text style={[styles.seasonLabel, { color: colors.deepMuted }]}>{progression.themeName.toUpperCase()}</Text>
            </View>
            <Text style={[styles.heroTitle, { color: colors.deepForeground }]}>{progression.seasonName}</Text>
          </View>
          <Text style={[styles.levelCount, { color: colors.deepForeground }]}>{progression.level} / 50</Text>
        </View>
        <View style={styles.progressCopy}>
          <Text style={[styles.minutesText, { color: colors.deepForeground }]}>
            {progression.minutesIntoLevel} / {progression.minutesPerLevel} focus minutes
          </Text>
          <Text style={[styles.xpHint, { color: colors.deepMuted }]}>
            {progression.focusMinutes} monthly minutes · resets {endLabel}
          </Text>
        </View>
        <View style={styles.progressTrack}>
          <View style={[styles.progressFill, { width: `${Math.round(progress * 100)}%`, backgroundColor: colors.accent }]} />
        </View>
      </View>

      <View style={[styles.tierGuide, { backgroundColor: colors.secondary }]}>
        <View style={styles.tierGuideItem}>
          <View style={[styles.tierDot, { backgroundColor: colors.primary }]} />
          <Text style={[styles.tierGuideText, { color: colors.secondaryForeground }]}>Free lane</Text>
        </View>
        <View style={styles.tierGuideItem}>
          <View style={[styles.tierDot, { backgroundColor: colors.accent }]} />
          <Text style={[styles.tierGuideText, { color: colors.secondaryForeground }]}>Focus Compass Premium lane</Text>
        </View>
        <Text style={[styles.tierGuideHint, { color: colors.mutedForeground }]}>20 min / level</Text>
      </View>
      {claimNotice ? (
        <View style={[styles.claimNotice, { backgroundColor: colors.secondary }]}>
          <Feather name="info" size={18} color={colors.primary} />
          <Text style={[styles.claimNoticeText, { color: colors.secondaryForeground }]}>{claimNotice}</Text>
        </View>
      ) : null}
      {progression.claiming ? (
        <Text accessibilityLiveRegion="polite" style={[styles.claimNoticeText, { color: colors.foreground }]}>Confirming your reward…</Text>
      ) : !progression.claimsReady ? (
        <Text style={[styles.claimNoticeText, { color: colors.mutedForeground }]}>Claims will be ready after your practice syncs. Signed-in claims need an internet connection.</Text>
      ) : null}
      {rewards.storageError ? (
        <Text accessibilityRole="alert" style={[styles.claimNoticeText, { color: colors.destructive }]}>{rewards.storageError}</Text>
      ) : null}

      <View style={styles.sectionHeader}>
        <View>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Weekly missions</Text>
          <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
            Verified from this week’s real Focus and Stillness completions.
          </Text>
        </View>
        <Feather name="target" size={22} color={colors.primary} />
      </View>
      <View style={styles.missionList}>
        {progression.weeklyMissions.map((mission) => {
          const claimed = progression.claimedWeeklyMissions.includes(mission.id);
          const complete = mission.progress >= mission.goal;
          return (
            <View key={mission.id} style={[styles.missionCard, { backgroundColor: colors.card, borderColor: complete ? colors.primary : colors.border }]}>
              <View style={styles.missionTop}>
                <View style={[styles.missionIcon, { backgroundColor: complete ? colors.secondary : colors.muted }]}>
                  <Feather name={claimed ? 'check' : 'target'} size={17} color={complete ? colors.secondaryForeground : colors.mutedForeground} />
                </View>
                <View style={styles.missionCopy}>
                  <Text style={[styles.missionTitle, { color: colors.foreground }]}>{mission.title}</Text>
                  <Text style={[styles.missionDescription, { color: colors.mutedForeground }]}>{mission.description}</Text>
                </View>
                <Text style={[styles.missionProgress, { color: colors.primary }]}>{mission.progress}/{mission.goal}</Text>
              </View>
              <View style={styles.missionBottom}>
                <Text style={[styles.missionReward, { color: colors.accentForeground }]}>{mission.rewardLabel}</Text>
                <Pressable
                  testID={`weekly-mission-${mission.id}`}
                  disabled={!complete || claimed || progression.claiming}
                  onPress={async () => {
                    setClaimNotice(null);
                    const result = await progression.claimWeeklyMission(mission);
                    if (result.status === 'claimed') {
                      setClaimNotice(`${mission.rewardLabel} added to your rewards.`);
                    } else {
                      setClaimNotice(result.status === 'already-claimed' ? 'This reward has already been claimed.' : result.message ?? 'Could not claim this reward.');
                    }
                  }}
                  style={[styles.missionButton, { backgroundColor: claimed ? colors.secondary : complete ? colors.primary : colors.muted }]}
                >
                  <Text style={[styles.missionButtonText, { color: claimed || complete ? colors.primaryForeground : colors.mutedForeground }]}>
                    {claimed ? 'Claimed' : complete ? 'Claim' : 'In progress'}
                  </Text>
                </Pressable>
              </View>
            </View>
          );
        })}
      </View>

      <View style={[styles.showcaseCard, { backgroundColor: colors.deepBackground }]}>
        <View style={styles.showcaseHeading}>
          <View>
            <Text style={[styles.showcaseEyebrow, { color: colors.accent }]}>REWARD SHOWCASE</Text>
            <Text style={[styles.showcaseTitle, { color: colors.deepForeground }]}>
              {rewards.selectedCollectible
                ? paperPlanetsCollectibles.find((item) => item.id === rewards.selectedCollectible)?.title
                : 'Choose a paper planet in Shop'}
            </Text>
          </View>
          <Feather name="award" size={25} color={colors.accent} />
        </View>
        <Text style={[styles.showcaseLine, { color: colors.deepMuted }]}>
          {rewards.ownedCollectibles.length}/{paperPlanetsCollectibles.length} collectibles · {rewards.equipped.breath} breathing · {soundscapeLabels[rewards.soundscape]}
        </Text>
        <Text style={[styles.showcaseHint, { color: colors.deepMuted }]}>
          {focus.stasisTokens} Stasis Tokens available for future focus protection. Find rare tokens in Shop capsules.
        </Text>
      </View>

      <View style={styles.sectionHeader}>
        <View>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>50-level reward track</Text>
          <Text style={[styles.sectionSubtitle, { color: colors.mutedForeground }]}>
            Both lanes follow the same measured focus progress. Focus Compass Premium opens the bonus rewards.
          </Text>
        </View>
        <Feather name="gift" size={22} color={colors.primary} />
      </View>

      <View style={styles.track}>
        {Array.from({ length: progression.maxLevels }, (_, index) => {
          const tier = index + 1;
          const freeReward = progression.rewards.find((reward) => reward.tier === tier && !reward.premium);
          const premiumReward = progression.rewards.find((reward) => reward.tier === tier && reward.premium);
          if (!freeReward || !premiumReward) return null;
          const unlocked = progression.level >= tier;
          const freeKey = `${progression.seasonKey}-free-${tier}`;
          const premiumKey = `${progression.seasonKey}-premium-${tier}`;

          return (
            <View
              key={tier}
              style={[
                styles.levelCard,
                { backgroundColor: colors.card, borderColor: unlocked ? colors.primary : colors.border },
              ]}
            >
              <View style={styles.levelHeader}>
                <View style={[styles.tierBubble, { backgroundColor: unlocked ? colors.secondary : colors.muted }]}>
                  <Text style={[styles.tierText, { color: unlocked ? colors.secondaryForeground : colors.mutedForeground }]}>
                    {tier}
                  </Text>
                </View>
                <Text style={[styles.levelTheme, { color: colors.foreground }]}>{freeReward.title.split(' ').slice(0, 2).join(' ')}</Text>
                <Text style={[styles.levelRequirement, { color: colors.mutedForeground }]}>{tier * 20} min</Text>
              </View>
              <View style={styles.lanes}>
                <RewardLane
                  reward={freeReward}
                  premium={false}
                  unlocked={unlocked}
                  claimed={progression.claimedRewards.includes(freeKey)}
                  isPremium={progression.isPremium}
                  busy={progression.claiming}
                  onClaim={() => claim(freeReward)}
                />
                <RewardLane
                  reward={premiumReward}
                  premium
                  unlocked={unlocked}
                  claimed={progression.claimedRewards.includes(premiumKey)}
                  isPremium={progression.isPremium}
                  busy={progression.claiming}
                  onClaim={() => {
                    if (!progression.isPremium) router.push('/paywall');
                    else claim(premiumReward);
                  }}
                />
              </View>
            </View>
          );
        })}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', marginBottom: 20 },
  headerCopy: { alignItems: 'center' },
  levelBadgeContainer: { position: 'absolute', right: 0, top: 0, zIndex: 10 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, marginBottom: 7, textAlign: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.7, textAlign: 'center' },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, marginTop: 7, textAlign: 'center' },
  levelBadge: { width: 63, height: 63, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  levelNumber: { fontFamily: 'Inter_700Bold', fontSize: 24, lineHeight: 26 },
  levelLabel: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.8 },
  hero: { borderRadius: 25, padding: 21, gap: 18 },
  heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 },
  heroCopy: { flex: 1 },
  themeRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  seasonLabel: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 1 },
  heroTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, lineHeight: 27, marginTop: 8 },
  levelCount: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  progressCopy: { gap: 4 },
  minutesText: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  xpHint: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  progressTrack: { height: 9, borderRadius: 5, backgroundColor: '#FFFFFF1A', overflow: 'hidden' },
  progressFill: { height: 9, borderRadius: 5 },
  tierGuide: { borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 13, flexWrap: 'wrap' },
  tierGuideItem: { flexDirection: 'row', alignItems: 'center', gap: 6, flexShrink: 1 },
  tierDot: { width: 9, height: 9, borderRadius: 5 },
  tierGuideText: { fontFamily: 'Inter_700Bold', fontSize: 13, flexShrink: 1 },
  tierGuideHint: { fontFamily: 'Inter_600SemiBold', fontSize: 12, marginLeft: 'auto' },
  claimNotice: { borderRadius: 15, padding: 12, flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  claimNoticeText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13, lineHeight: 19 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 14 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 21 },
  sectionSubtitle: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21, marginTop: 4, maxWidth: 310 },
  track: { gap: 12 },
  levelCard: { borderWidth: 1, borderRadius: 21, padding: 12, gap: 10 },
  levelHeader: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  tierBubble: { width: 31, height: 31, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  tierText: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  levelTheme: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 14 },
  levelRequirement: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  lanes: { flexDirection: 'row', gap: 8 },
  lane: { flex: 1, minWidth: 0, borderWidth: 1, borderRadius: 15, padding: 10, gap: 7 },
  laneHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  laneLabel: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 0.6 },
  laneIcon: { width: 34, height: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  laneTitle: { fontFamily: 'Inter_700Bold', fontSize: 12, lineHeight: 16, minHeight: 32 },
  laneDescription: { fontFamily: 'Inter_500Medium', fontSize: 11, lineHeight: 15, minHeight: 30 },
  claimButton: { minHeight: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5, paddingVertical: 8 },
  claimText: { fontFamily: 'Inter_700Bold', fontSize: 11, textAlign: 'center', flexShrink: 1 },
  pressed: { opacity: 0.75, transform: [{ scale: 0.985 }] },
  missionList: { gap: 10 },
  missionCard: { borderWidth: 1, borderRadius: 18, padding: 14, gap: 12 },
  missionTop: { flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  missionIcon: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  missionCopy: { flex: 1, gap: 3 },
  missionTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  missionDescription: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 17 },
  missionProgress: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  missionBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  missionReward: { fontFamily: 'Inter_700Bold', fontSize: 12 },
  missionButton: { minWidth: 88, minHeight: 34, borderRadius: 11, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 10 },
  missionButtonText: { fontFamily: 'Inter_700Bold', fontSize: 11 },
  showcaseCard: { borderRadius: 22, padding: 18, gap: 9 },
  showcaseHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 },
  showcaseEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1 },
  showcaseTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, marginTop: 6 },
  showcaseLine: { fontFamily: 'Inter_700Bold', fontSize: 13, lineHeight: 20 },
  showcaseHint: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 18 },
});
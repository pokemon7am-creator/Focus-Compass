import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Platform, Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { ReminderAppList } from '@/components/ReminderAppList';
import { useFocus } from '@/context/FocusContext';
import { useColors } from '@/hooks/useColors';
import { useDailyFrictionCompletion } from '@/hooks/useDailyFrictionCompletion';

export default function GuardScreen() {
  const colors = useColors();
  const focus = useFocus();
  const physicalDaily = useDailyFrictionCompletion('physical');
  const mathDaily = useDailyFrictionCompletion('math');
  const [pickerMessage, setPickerMessage] = useState('');
  const [isChoosingApps, setIsChoosingApps] = useState(false);
  const [setupMessage, setSetupMessage] = useState('');
  const [isSettingUp, setIsSettingUp] = useState(false);
  const isAndroid = Platform.OS === 'android';
  const isReminderMode = !isAndroid;
  const activeCount = focus.apps.filter((app) => app.active).length;
  const blockingCopy = {
    unsupported: {
      title: 'Preview-only protection',
      body: 'A custom iPhone or Android build is required for real app blocking.',
      action: 'How to enable',
    },
    'needs-permission': {
      title: 'Permission needed',
      body: 'Allow Focus Compass to enforce your selected apps on this device.',
      action: 'Set up blocking',
    },
    ready: {
      title: 'Device protection ready',
      body: 'Selected apps will be blocked when a focus session starts.',
      action: 'Check permission',
    },
    active: {
      title: 'Blocking active',
      body: 'Focus Compass is enforcing your selected apps for this focus session.',
      action: 'Manage permission',
    },
  }[focus.blockingStatus];

  const setupDeviceBlocking = async () => {
    if (isSettingUp) return;
    setSetupMessage('');
    setIsSettingUp(true);
    try {
      const opened = await focus.setupDeviceBlocking();
      if (!opened) {
        setSetupMessage(
          focus.blockingStatus === 'unsupported'
            ? 'App blocking is not available in Preview. Install a custom iPhone or Android build to enable it.'
            : 'Permission is still needed. Allow Focus Compass in device settings, then try again.',
        );
      }
    } catch {
      setSetupMessage('Device settings could not be opened. Open system settings and allow Focus Compass, then try again.');
    } finally {
      setIsSettingUp(false);
    }
  };

  const chooseAppsFromDevice = async () => {
    if (isChoosingApps) return;
    setPickerMessage('');
    setIsChoosingApps(true);
    try {
      const result = await focus.chooseAppsFromDevice();
      if (result === 'permission-denied') {
        setPickerMessage('Permission was not granted. Allow access in device settings, then try again.');
      } else if (result === 'unavailable') {
        setPickerMessage('The protected app picker is available after installing a custom iPhone or Android build.');
      } else if (result === 'updated') {
        setPickerMessage('Selected apps updated.');
      }
    } catch {
      setPickerMessage('The app picker could not be opened. Check device access, then try again.');
    } finally {
      setIsChoosingApps(false);
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>{isReminderMode ? 'ATTENTION RESET' : 'YOUR GUARD'}</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>
          {isReminderMode ? 'Return to what matters.' : 'Choose the easy exits.'}
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          {isReminderMode
            ? 'Name the apps you want to avoid, then use a quick reset whenever your attention drifts.'
            : `${activeCount} ${activeCount === 1 ? 'app is' : 'apps are'} selected.`}
        </Text>
      </View>

      {isAndroid ? (
        <>
          <Pressable
            testID="setup-device-blocking"
            accessibilityRole="button"
            accessibilityState={{ busy: isSettingUp, disabled: isSettingUp }}
            disabled={isSettingUp}
            onPress={() => void setupDeviceBlocking()}
            style={({ pressed }) => [
              styles.statusCard,
              { backgroundColor: colors.deepBackground },
              pressed && styles.pressed,
            ]}
          >
            <View style={[styles.shield, { backgroundColor: colors.primary }]}>
              <Feather name="shield" size={27} color={colors.primaryForeground} />
            </View>
            <View style={styles.statusCopy}>
              <Text style={[styles.statusTitle, { color: colors.deepForeground }]}>{blockingCopy.title}</Text>
              <Text style={[styles.statusBody, { color: colors.deepForeground }]}>{blockingCopy.body}</Text>
            </View>
            <View style={[styles.livePill, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.liveText, { color: colors.secondaryForeground }]}>
                {isSettingUp ? 'CHECKING…' : blockingCopy.action.toUpperCase()}
              </Text>
            </View>
          </Pressable>
          {setupMessage ? (
            <View style={[styles.setupMessage, { backgroundColor: colors.secondary }]}>
              <Feather name="info" size={17} color={colors.secondaryForeground} />
              <Text style={[styles.setupMessageText, { color: colors.secondaryForeground }]}>
                {setupMessage}
              </Text>
            </View>
          ) : null}
           <View style={[styles.accessibilityDisclosure, { backgroundColor: colors.card, borderColor: colors.border }]}>
             <Feather name="eye" size={18} color={colors.primary} />
             <Text style={[styles.accessibilityDisclosureText, { color: colors.mutedForeground }]}>
               Android Accessibility access detects the name of the app you open during a timed focus session so a
               selected app can be sent back to Home. Focus Compass does not read screen content or type for you.
               Access can be turned off in Android Settings, so blocking is not bypass-proof.
             </Text>
           </View>

          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Selected apps</Text>
            <Pressable
              testID="choose-device-apps"
              accessibilityRole="button"
              accessibilityState={{ busy: isChoosingApps, disabled: isChoosingApps }}
              disabled={isChoosingApps}
              onPress={() => void chooseAppsFromDevice()}
              style={({ pressed }) => [
                styles.chooseButton,
                { backgroundColor: colors.secondary, borderColor: colors.border },
                pressed && styles.pressed,
              ]}
            >
              <Feather name="smartphone" size={18} color={colors.secondaryForeground} />
              <Text style={[styles.chooseButtonText, { color: colors.secondaryForeground }]}>
                {isChoosingApps ? 'Checking device access…' : 'Allow access and choose apps'}
              </Text>
              <Feather name="chevron-right" size={18} color={colors.secondaryForeground} />
            </Pressable>
            {pickerMessage ? (
              <View style={[styles.pickerMessage, { backgroundColor: colors.secondary }]}>
                <Feather name="info" size={17} color={colors.secondaryForeground} />
                <Text style={[styles.pickerMessageText, { color: colors.secondaryForeground }]}>
                  {pickerMessage}
                </Text>
              </View>
            ) : null}
            <View style={[styles.list, { backgroundColor: colors.card, borderColor: colors.border }]}>
              {focus.apps.length === 0 ? (
                <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                  No apps selected. Focus sessions will not block anything.
                </Text>
              ) : (
                focus.apps.map((app, index) => (
                  <View
                    key={app.id}
                    style={[
                      styles.appRow,
                      index < focus.apps.length - 1 && { borderBottomWidth: 1, borderBottomColor: colors.border },
                    ]}
                  >
                    <View style={[styles.appIcon, { backgroundColor: app.active ? colors.accent : colors.muted }]}>
                      <Text style={[styles.appInitial, { color: colors.foreground }]}>{app.name.slice(0, 1)}</Text>
                    </View>
                    <View style={styles.appCopy}>
                      <Text style={[styles.appName, { color: colors.foreground }]}>{app.name}</Text>
                      <Text style={[styles.appCategory, { color: colors.mutedForeground }]}>{app.category}</Text>
                    </View>
                    <Switch
                      testID={`toggle-${app.id}`}
                      value={app.active}
                      onValueChange={() => focus.toggleApp(app.id)}
                      trackColor={{ false: colors.muted, true: colors.sage }}
                      thumbColor={app.active ? colors.foreground : colors.card}
                    />
                  </View>
                ))
              )}
            </View>
          </View>
        </>
      ) : null}

      {isReminderMode ? <ReminderAppList /> : null}

      <View>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Off-topic resets</Text>
        <Text style={[styles.sectionBody, { color: colors.mutedForeground }]}>
          Choose a reset whenever you notice your attention has drifted. Roasts are always available.
        </Text>
        <Pressable
          testID="try-roast"
          onPress={() => router.push('/roast')}
          style={({ pressed }) => [
            styles.friction,
            { backgroundColor: colors.card, borderColor: colors.border },
            pressed && styles.pressed,
          ]}
        >
          <View style={[styles.frictionIcon, { backgroundColor: colors.accent }]}>
            <Feather name="message-circle" size={21} color={colors.accentForeground} />
          </View>
          <View style={styles.frictionCopy}>
            <Text style={[styles.frictionTitle, { color: colors.foreground }]}>Roast reset</Text>
            <Text style={[styles.frictionBody, { color: colors.mutedForeground }]}>
              Take a playful reality check whenever you need one.
            </Text>
          </View>
          <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
        </Pressable>
        <Pressable
          testID="try-physical-challenge"
          accessibilityState={{ disabled: physicalDaily.status !== 'available' }}
          disabled={physicalDaily.status !== 'available'}
          onPress={() => router.push('/challenge')}
          style={({ pressed }) => [
            styles.friction,
            { backgroundColor: colors.card, borderColor: colors.border },
            physicalDaily.status !== 'available' && styles.disabled,
            pressed && styles.pressed,
          ]}
        >
          <View style={[styles.frictionIcon, { backgroundColor: colors.accent }]}>
            <Feather name="activity" size={21} color={colors.accentForeground} />
          </View>
          <View style={styles.frictionCopy}>
            <Text style={[styles.frictionTitle, { color: colors.foreground }]}>Physical challenge</Text>
            <Text style={[styles.frictionBody, { color: colors.mutedForeground }]}>
              {physicalDaily.status === 'completed'
                ? 'Completed today · Available tomorrow'
                : physicalDaily.status === 'loading'
                  ? 'Checking today’s availability…'
                  : physicalDaily.status === 'error'
                    ? physicalDaily.error
                    : 'Movement difficulty scales with the focused time you interrupted.'}
            </Text>
          </View>
          <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
        </Pressable>
        <Pressable
          testID="try-math-challenge"
          accessibilityState={{ disabled: mathDaily.status !== 'available' }}
          disabled={mathDaily.status !== 'available'}
          onPress={() => router.push('/challenge?kind=math')}
          style={({ pressed }) => [
            styles.friction,
            { backgroundColor: colors.card, borderColor: colors.border },
            mathDaily.status !== 'available' && styles.disabled,
            pressed && styles.pressed,
          ]}
        >
          <View style={[styles.frictionIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="hash" size={21} color={colors.secondaryForeground} />
          </View>
          <View style={styles.frictionCopy}>
            <Text style={[styles.frictionTitle, { color: colors.foreground }]}>Math challenge</Text>
            <Text style={[styles.frictionBody, { color: colors.mutedForeground }]}>
              {mathDaily.status === 'completed'
                ? 'Completed today · Available tomorrow'
                : mathDaily.status === 'loading'
                  ? 'Checking today’s availability…'
                  : mathDaily.status === 'error'
                    ? mathDaily.error
                    : 'Solve a harder problem after longer focus blocks.'}
            </Text>
          </View>
          <Feather name="chevron-right" size={20} color={colors.mutedForeground} />
        </Pressable>
        {mathDaily.status === 'error' ? (
          <Pressable testID="retry-guard-math-status" onPress={() => void mathDaily.refresh()}>
            <Text style={[styles.retryText, { color: colors.primary }]}>Retry math status</Text>
          </Pressable>
        ) : null}
        {physicalDaily.status === 'error' ? (
          <Pressable testID="retry-guard-physical-status" onPress={() => void physicalDaily.refresh()}>
            <Text style={[styles.retryText, { color: colors.primary }]}>Retry physical status</Text>
          </Pressable>
        ) : null}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', marginBottom: 20 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, marginBottom: 7, textAlign: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.7, textAlign: 'center' },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, marginTop: 7, maxWidth: 350, textAlign: 'center' },
  statusCard: { borderRadius: 22, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 13 },
  shield: { width: 50, height: 50, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  statusCopy: { flex: 1 },
  statusTitle: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  statusBody: { color: '#D4DBD7', fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 18, marginTop: 3 },
  livePill: { borderRadius: 12, paddingHorizontal: 10, paddingVertical: 7 },
  liveText: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 0.7 },
  setupMessage: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, borderRadius: 14, padding: 13, marginTop: 10 },
  setupMessageText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13, lineHeight: 19 },
  accessibilityDisclosure: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, borderWidth: 1, borderRadius: 16, padding: 13 },
  accessibilityDisclosureText: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 19 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 20, marginBottom: 11 },
  sectionBody: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21, marginTop: -4, marginBottom: 11 },
  chooseButton: { minHeight: 52, borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
  chooseButtonText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 15 },
  pickerMessage: { flexDirection: 'row', alignItems: 'flex-start', gap: 9, borderRadius: 14, padding: 13, marginBottom: 10 },
  pickerMessageText: { flex: 1, fontFamily: 'Inter_700Bold', fontSize: 13, lineHeight: 19 },
  list: { borderRadius: 22, borderWidth: 1, overflow: 'hidden' },
  emptyText: { padding: 18, fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21 },
  appRow: { flexDirection: 'row', alignItems: 'center', padding: 14 },
  appIcon: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  appInitial: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  appCopy: { flex: 1, marginLeft: 12 },
  appName: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  appCategory: { fontFamily: 'Inter_500Medium', fontSize: 13, marginTop: 3 },
  friction: { borderWidth: 1, borderRadius: 20, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
  frictionIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  frictionCopy: { flex: 1 },
  frictionTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  frictionBody: { fontFamily: 'Inter_500Medium', fontSize: 13, marginTop: 4 },
  pressed: { opacity: 0.72, transform: [{ scale: 0.99 }] },
  disabled: { opacity: 0.55 },
  retryText: { alignSelf: 'flex-end', fontFamily: 'Inter_700Bold', fontSize: 14, paddingVertical: 7 },
});
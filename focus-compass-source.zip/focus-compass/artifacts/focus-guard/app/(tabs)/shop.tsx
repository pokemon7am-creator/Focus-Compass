import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { Animated, Platform } from 'react-native';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useFocus } from '@/context/FocusContext';
import { STASIS_CAPSULE_COST, STASIS_TOKEN_CHANCE, useProgression } from '@/context/ProgressionContext';
import { useRevenueCat } from '@/context/RevenueCatContext';
import { paperPlanetsCollectibles, RewardCategory, useRewards } from '@/context/RewardsContext';
import { useColors } from '@/hooks/useColors';
import { soundscapeLabels } from '@/services/ambientAudio';

const rewardItems: {
  id: string;
  category: RewardCategory;
    icon: 'wind' | 'moon' | 'star' | 'sun' | 'zap' | 'coffee' | 'message-circle' | 'book-open' | 'edit-3';
  name: string;
  description: string;
  cost: number;
}[] = [
  {
    id: 'breath-classic',
    category: 'breath',
    icon: 'wind',
    name: 'Classic breath',
    description: 'Green circle · balanced 4–2–6 breathing',
    cost: 0,
  },
  {
    id: 'breath-moonlight',
    category: 'breath',
    icon: 'moon',
    name: 'Moonlight breath',
    description: 'Night sky · calming 4–4–8 breathing',
    cost: 12,
  },
  {
    id: 'breath-starlight',
    category: 'breath',
    icon: 'star',
    name: 'Starlight breath',
    description: 'Purple diamond · even 5–2–5 breathing',
    cost: 24,
  },
  {
    id: 'breath-sunrise',
    category: 'breath',
    icon: 'sun',
    name: 'Sunrise breath',
    description: 'Sun and rays · energizing 4–1–4 breathing',
    cost: 40,
  },
  {
    id: 'breath-aurora',
    category: 'breath',
    icon: 'zap',
    name: 'Aurora breath',
    description: 'Flowing color bands · deep 5–3–7 breathing',
    cost: 75,
  },
  {
    id: 'breath-paperfold',
    category: 'breath',
    icon: 'book-open',
    name: 'Paper Fold breath',
    description: 'Folded paper · steady 4–4–6 breathing',
    cost: 65,
  },
  {
    id: 'roast-bold',
    category: 'roast',
    icon: 'message-circle',
    name: 'Bold roast pack',
    description: 'Sharper lines for switches and early endings',
    cost: 30,
  },
  {
    id: 'roast-dry',
    category: 'roast',
    icon: 'coffee',
    name: 'Dry roast pack',
    description: 'Calm, deadpan accountability',
    cost: 55,
  },
  {
    id: 'roast-chaos',
    category: 'roast',
    icon: 'zap',
    name: 'Chaos roast pack',
    description: 'The rarest and least forgiving lines',
    cost: 90,
  },
  {
    id: 'roast-margin-notes',
    category: 'roast',
    icon: 'edit-3',
    name: 'Margin Notes roast pack',
    description: 'Thoughtful footnotes for abandoned focus plans',
    cost: 80,
  },
];

export default function ShopScreen() {
  const colors = useColors();
  const focus = useFocus();
  const progression = useProgression();
  const revenueCat = useRevenueCat();
  const rewards = useRewards();
  const [previewId, setPreviewId] = useState<string | null>(null);
  const [capsuleNotice, setCapsuleNotice] = useState('');
  const [planetNotice, setPlanetNotice] = useState('');
  const selectedPlanet = paperPlanetsCollectibles.find((item) => item.id === rewards.selectedCollectible);
  const canChooseFirstPlanet = rewards.hydrated && rewards.ownedCollectibles.length === 0;
  const [isDrawingCapsule, setIsDrawingCapsule] = useState(false);
  const capsuleDrawLock = useRef(false);
  const [capsuleAttempt, setCapsuleAttempt] = useState(0);
  const capsuleReady = progression.hydrated && focus.hydrated && rewards.hydrated;
  const leavesNeeded = Math.max(0, STASIS_CAPSULE_COST - rewards.leaves);
  const previewScale = useRef(new Animated.Value(1)).current;
  const monthly = revenueCat.offering?.monthly ?? revenueCat.offering?.availablePackages[0] ?? null;

  useEffect(() => {
    previewScale.stopAnimation();
    previewScale.setValue(1);
    if (!previewId) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(previewScale, { toValue: 1.18, duration: 850, useNativeDriver: true }),
        Animated.timing(previewScale, { toValue: 1, duration: 1100, useNativeDriver: true }),
      ]),
    );
    loop.start();
    return () => loop.stop();
  }, [previewId, previewScale]);

  useEffect(() => {
    capsuleDrawLock.current = false;
  }, [capsuleAttempt]);

  const drawStasisCapsule = () => {
    if (capsuleDrawLock.current) return;
    capsuleDrawLock.current = true;
    setIsDrawingCapsule(true);
    setCapsuleAttempt((attempt) => attempt + 1);
    const result = progression.drawStasisCapsule();
    if (result === 'stasis-token') {
      setCapsuleNotice('Rare pull: 1 Stasis Token added. It protects one eligible missed day automatically.');
    } else if (result === 'consolation') {
      setCapsuleNotice('No Stasis Token this time. The capsule returned 5 Leaves.');
    } else if (result === 'insufficient-leaves') {
      setCapsuleNotice(`You have ${rewards.leaves} Leaves. Earn ${leavesNeeded} more through Stillness or weekly missions to draw.`);
    } else {
      setCapsuleNotice('Rewards are still loading. Try again in a moment.');
    }
    setIsDrawingCapsule(false);
  };

  return (
    <Screen>
      <View style={styles.header}>
        <View style={styles.headerCopy}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>FOCUS COMPASS MEMBERSHIP</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Focus deeper.</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Focus Compass Premium tools and earned rewards for a steadier practice.
          </Text>
          <Pressable onPress={() => router.push('/login')} style={styles.accountLink}>
            <Feather name="user" size={14} color={colors.primary} />
            <Text style={[styles.accountLinkText, { color: colors.primary }]}>Sign in to sync your practice</Text>
          </Pressable>
        </View>
        <View style={styles.bagContainer}>
          <View style={[styles.bag, { backgroundColor: colors.secondary }]}>
            <Feather name="shopping-bag" size={24} color={colors.secondaryForeground} />
          </View>
        </View>
      </View>

      <View style={[styles.membership, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.membershipTop}>
          <View style={[styles.premiumMark, { backgroundColor: colors.primary }]}>
            <Feather name="zap" size={22} color={colors.primaryForeground} />
          </View>
          <View style={[styles.bestValue, { backgroundColor: colors.accent }]}>
            <Text style={[styles.bestValueText, { color: colors.accentForeground }]}>
              {revenueCat.isPremium ? 'ACTIVE' : 'MONTHLY'}
            </Text>
          </View>
        </View>
        <Text style={[styles.planLabel, { color: colors.primary }]}>MEMBERSHIP PLAN</Text>
        <Text style={[styles.membershipName, { color: colors.foreground }]}>Focus Compass Premium</Text>
        <Text style={[styles.membershipDescription, { color: colors.mutedForeground }]}>
          {Platform.OS === 'ios'
            ? 'Focus Compass Premium membership for a steadier practice, linked to your store account.'
            : 'Focus Compass Premium tools for a steadier practice. Native app blocking and Family Guard are still in development.'}
        </Text>
        <View style={styles.priceRow}>
          <Text style={[styles.price, { color: colors.foreground }]}>{monthly?.product.priceString ?? 'Monthly plan'}</Text>
          {monthly ? <Text style={[styles.period, { color: colors.mutedForeground }]}> / month</Text> : null}
        </View>
        <Pressable
          testID="shop-premium"
          onPress={() => router.push('/paywall')}
          style={({ pressed }) => [
            styles.shopButton,
            { backgroundColor: revenueCat.isPremium ? colors.secondary : colors.primary },
            pressed && styles.pressed,
          ]}
        >
          <Text
            style={[
              styles.shopButtonText,
              { color: revenueCat.isPremium ? colors.secondaryForeground : colors.primaryForeground },
            ]}
          >
            {revenueCat.isPremium ? 'View membership' : 'Get Focus Compass Premium'}
          </Text>
          <Feather
            name="arrow-up-right"
            size={18}
            color={revenueCat.isPremium ? colors.secondaryForeground : colors.primaryForeground}
          />
        </Pressable>
      </View>

      <View>
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Leaf rewards</Text>
          <Text style={[styles.included, { color: colors.primary }]}>{rewards.leaves} LEAVES</Text>
        </View>
        <Text style={[styles.rewardHelp, { color: colors.mutedForeground }]}>
          One completed Stillness minute earns one leaf. Rare rewards take consistency.
        </Text>
        <View style={styles.collection}>
          {rewardItems.map((item) => {
            const rewardName = item.id.replace(`${item.category}-`, '');
            const isUnlocked = item.cost === 0 || rewards.unlockedRewards.includes(item.id);
            const isEquipped = rewards.equipped[item.category] === rewardName;
            const canUnlock = isUnlocked || rewards.leaves >= item.cost;

            const isPreviewing = previewId === item.id;
            return (
              <View
                key={item.id}
                testID={`shop-${item.id}`}
                style={[
                  styles.item,
                  { backgroundColor: colors.card, borderColor: isEquipped ? colors.primary : colors.border },
                  !canUnlock && styles.disabled,
                ]}
              >
                <View style={[styles.itemIcon, { backgroundColor: colors.secondary }]}>
                  <Feather name={item.icon} size={22} color={colors.secondaryForeground} />
                </View>
                <View style={styles.itemCopy}>
                  <Text style={[styles.itemName, { color: colors.foreground }]}>{item.name}</Text>
                  <Text style={[styles.itemDescription, { color: colors.mutedForeground }]}>{item.description}</Text>
                </View>
                <View style={styles.itemActions}>
                  {item.category === 'breath' ? (
                    <Pressable
                      testID={`shop-preview-${item.id}`}
                      onPress={() => setPreviewId(isPreviewing ? null : item.id)}
                      style={({ pressed }) => [styles.previewButton, { borderColor: isPreviewing ? colors.accent : colors.border }, pressed && styles.pressed]}
                    >
                      <Feather name={isPreviewing ? 'pause' : 'eye'} size={12} color={isPreviewing ? colors.accentForeground : colors.foreground} />
                      <Text style={[styles.previewText, { color: isPreviewing ? colors.accentForeground : colors.foreground }]}>
                        {isPreviewing ? 'Close' : 'Preview'}
                      </Text>
                    </Pressable>
                  ) : null}
                  <Pressable
                    testID={`shop-${item.id}`}
                    disabled={isEquipped || !canUnlock}
                    onPress={() => rewards.unlockAndEquip(item.id, item.cost, item.category)}
                    style={({ pressed }) => [
                      styles.rewardAction,
                      {
                        backgroundColor: isEquipped ? colors.secondary : canUnlock ? colors.primary : 'transparent',
                        borderColor: isEquipped ? colors.secondary : canUnlock ? colors.primary : colors.border,
                      },
                      pressed && styles.pressed,
                    ]}
                  >
                    <Feather
                      name={isEquipped ? 'check' : isUnlocked ? 'sliders' : canUnlock ? 'unlock' : 'lock'}
                      size={12}
                      color={isEquipped ? colors.secondaryForeground : canUnlock ? colors.primaryForeground : colors.mutedForeground}
                    />
                    <Text
                      style={[
                        styles.rewardActionText,
                        { color: isEquipped ? colors.secondaryForeground : canUnlock ? colors.primaryForeground : colors.mutedForeground },
                      ]}
                    >
                      {isEquipped ? 'Equipped' : isUnlocked ? 'Equip' : canUnlock ? 'Unlock' : `${item.cost} leaves`}
                    </Text>
                  </Pressable>
                </View>
                {isPreviewing ? (
                  <View style={[styles.previewPanel, { backgroundColor: colors.deepBackground }]}>
                    <Animated.View
                      style={[
                        styles.previewOrb,
                        item.id === 'breath-moonlight' && styles.previewMoon,
                        item.id === 'breath-starlight' && styles.previewDiamond,
                        item.id === 'breath-sunrise' && styles.previewSun,
                        item.id === 'breath-aurora' && styles.previewAurora,
                        item.id === 'breath-paperfold' && styles.previewPaper,
                        { backgroundColor: colors.accent, transform: [{ scale: previewScale }] },
                        item.id === 'breath-starlight' && { transform: [{ scale: previewScale }, { rotate: '45deg' }] },
                      ]}
                    >
                      <Feather name={item.icon} size={17} color={colors.accentForeground} />
                    </Animated.View>
                    <View style={styles.previewCopy}>
                      <Text style={[styles.previewLabel, { color: colors.deepForeground }]}>LIVE PREVIEW</Text>
                      <Text style={[styles.previewRhythm, { color: colors.deepMuted }]}>
                        {item.description.split('·')[1]?.trim() ?? 'A steady breathing rhythm'}
                      </Text>
                    </View>
                  </View>
                ) : null}
              </View>
            );
          })}
        </View>
      </View>

      <View style={[styles.capsuleCard, { backgroundColor: colors.deepBackground }]}>
        <View style={styles.capsuleTop}>
          <View style={[styles.capsuleIcon, { backgroundColor: colors.accent }]}>
            <Feather name="shield" size={23} color={colors.accentForeground} />
          </View>
          <View style={styles.capsuleCopy}>
            <Text style={[styles.capsuleEyebrow, { color: colors.accent }]}>RARE GACHA ITEM</Text>
            <Text style={[styles.capsuleTitle, { color: colors.deepForeground }]}>Stasis Capsule</Text>
          </View>
          <Text style={[styles.capsuleBalance, { color: colors.deepForeground }]}>
            {focus.stasisTokens} {focus.stasisTokens === 1 ? 'token' : 'tokens'}
          </Text>
        </View>
        <Text style={[styles.capsuleBody, { color: colors.deepMuted }]}>
          Spend {STASIS_CAPSULE_COST} Leaves for an {Math.round(STASIS_TOKEN_CHANCE * 100)}% chance at 1 Stasis Token. A miss returns 5 Leaves.
        </Text>
        <Text testID="capsule-wallet-status" accessibilityLiveRegion="polite" style={[styles.capsuleBody, { color: colors.deepForeground }]}>
          {!capsuleReady
            ? 'Loading your wallet and rewards… No Leaves will be spent until they are ready.'
            : leavesNeeded > 0
              ? `Your balance: ${rewards.leaves} Leaves · ${leavesNeeded} more needed`
              : `Your balance: ${rewards.leaves} Leaves · Ready to draw`}
        </Text>
        <Pressable
          testID="draw-stasis-capsule"
          accessibilityRole="button"
          accessibilityHint="Draws when you have enough Leaves, otherwise explains what is needed."
          disabled={isDrawingCapsule}
          onPress={drawStasisCapsule}
          style={({ pressed }) => [
            styles.capsuleButton,
            {
              backgroundColor: colors.primary,
              opacity: isDrawingCapsule ? 0.65 : 1,
            },
            pressed && styles.pressed,
          ]}
        >
          <Feather name="gift" size={18} color={colors.primaryForeground} />
          <Text style={[styles.capsuleButtonText, { color: colors.primaryForeground }]}>
            {isDrawingCapsule ? 'Drawing…' : !capsuleReady ? 'Check draw availability' : leavesNeeded > 0 ? `Need ${leavesNeeded} more Leaves` : `Draw capsule · ${STASIS_CAPSULE_COST} Leaves`}
          </Text>
        </Pressable>
        {capsuleReady && leavesNeeded > 0 ? (
          <View style={{ gap: 10 }}>
            <Pressable accessibilityRole="button" onPress={() => router.push('/(tabs)/stillness')} style={[styles.capsuleButton, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.capsuleButtonText, { color: colors.secondaryForeground }]}>Earn Leaves in Stillness</Text>
            </Pressable>
            <Pressable accessibilityRole="button" onPress={() => router.push('/(tabs)/pass')} style={[styles.capsuleButton, { backgroundColor: colors.secondary }]}>
              <Text style={[styles.capsuleButtonText, { color: colors.secondaryForeground }]}>View weekly missions</Text>
            </Pressable>
          </View>
        ) : null}
        {capsuleNotice ? (
          <Text key={capsuleAttempt} accessibilityRole="alert" style={[styles.capsuleNotice, { color: colors.accent }]}>
            {capsuleNotice}
          </Text>
        ) : null}
      </View>

      <View style={[styles.showcaseCard, { backgroundColor: colors.deepBackground }]}>
        <View style={styles.showcaseTop}>
          <View style={styles.showcaseCopy}>
            <Text style={[styles.showcaseEyebrow, { color: colors.accent }]}>REWARD SHOWCASE</Text>
            <Text style={[styles.showcaseTitle, { color: colors.deepForeground }]}>
              {selectedPlanet
                ? selectedPlanet.title
                : 'Select a Paper Planet'}
            </Text>
            <Text style={[styles.showcaseDetails, { color: colors.deepMuted }]}>
              {rewards.equipped.breath} breath · {soundscapeLabels[rewards.soundscape]}
            </Text>
          </View>
          <Feather name={selectedPlanet?.icon ?? 'award'} size={40} color={colors.accent} />
        </View>
        <Text testID="paper-planet-selection" accessibilityLiveRegion="polite" style={[styles.capsuleBody, { color: colors.deepForeground }]}>
          {!rewards.hydrated
            ? 'Loading your Paper Planets…'
            : selectedPlanet
              ? `Selected: ${selectedPlanet.title}. ${selectedPlanet.description}`
              : canChooseFirstPlanet
                ? 'Choose your first Paper Planet below — it is free. Earn more through weekly missions.'
                : 'Tap an owned Paper Planet to display it here.'}
        </Text>
        <Text style={[styles.collectionProgress, { color: colors.deepMuted }]}>
          Paper Planets collection · {rewards.ownedCollectibles.length}/{paperPlanetsCollectibles.length}
        </Text>
        <View style={styles.collectibleGrid}>
          {paperPlanetsCollectibles.map((collectible) => {
            const owned = rewards.ownedCollectibles.includes(collectible.id);
            const selected = rewards.selectedCollectible === collectible.id;
            return (
              <Pressable
                key={collectible.id}
                testID={`collectible-${collectible.id}`}
                accessibilityRole="button"
                accessibilityLabel={`${collectible.title}. ${selected ? 'Selected' : owned ? 'Select' : canChooseFirstPlanet ? 'Choose free starter' : 'Locked — view unlock details'}`}
                accessibilityState={{ selected }}
                onPress={() => {
                  if (!rewards.hydrated) {
                    setPlanetNotice('Your collection is still loading. Please try again in a moment.');
                  } else if (rewards.selectCollectible(collectible.id)) {
                    setPlanetNotice(`${collectible.title} selected for your showcase.`);
                  } else {
                    const weeklyPlanet = progression.weeklyMissions.find((mission) => mission.collectibleId === collectible.id);
                    setPlanetNotice(weeklyPlanet
                      ? `Unlock ${collectible.title} by completing “${weeklyPlanet.title}” and claiming it in weekly missions.`
                      : `${collectible.title} is locked. Paper Planets rotate as weekly mission rewards; check back when this planet is featured.`);
                  }
                }}
                style={({ pressed }) => [
                  styles.collectible,
                  { borderColor: selected ? colors.accent : colors.deepMuted, borderWidth: selected ? 2 : 1 },
                  pressed && styles.pressed,
                ]}
              >
                <Feather name={collectible.icon} size={24} color={selected ? colors.accent : colors.deepForeground} />
                <View style={{ flex: 1, gap: 4 }}>
                  <Text style={[styles.collectibleText, { color: colors.deepForeground }]}>{collectible.title}</Text>
                  <Text style={[styles.collectibleStatus, { color: colors.deepMuted }]}>
                    {!rewards.hydrated ? 'Loading…' : selected ? 'Selected' : owned ? 'Tap to select' : canChooseFirstPlanet ? 'Choose free starter' : 'Locked · Tap for details'}
                  </Text>
                </View>
                <Feather name={selected ? 'check-circle' : owned || canChooseFirstPlanet ? 'chevron-right' : 'lock'} size={20} color={colors.accent} />
              </Pressable>
            );
          })}
        </View>
        {planetNotice ? (
          <Text accessibilityRole="alert" style={[styles.capsuleBody, { color: colors.accent }]}>{planetNotice}</Text>
        ) : null}
        <Pressable accessibilityRole="button" onPress={() => router.push('/(tabs)/pass')} style={[styles.capsuleButton, { backgroundColor: colors.secondary }]}>
          <Text style={[styles.capsuleButtonText, { color: colors.secondaryForeground }]}>Earn more in weekly missions</Text>
        </Pressable>
      </View>

      <View style={[styles.promise, { backgroundColor: colors.secondary }]}>
        <Feather name="shield" size={19} color={colors.secondaryForeground} />
        <Text style={[styles.promiseText, { color: colors.secondaryForeground }]}>
          Purchases and pricing are securely handled for your plan.
        </Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', marginBottom: 20 },
  headerCopy: { alignItems: 'center' },
  bagContainer: { position: 'absolute', right: 0, top: 0, zIndex: 10 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, marginBottom: 7, textAlign: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.7, textAlign: 'center' },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, marginTop: 7, textAlign: 'center' },
  accountLink: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 11, justifyContent: 'center' },
  accountLinkText: { fontFamily: 'Inter_700Bold', fontSize: 14, textAlign: 'center' },
  bag: { width: 48, height: 48, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  membership: { borderRadius: 26, borderWidth: 1, padding: 20 },
  membershipTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  premiumMark: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  bestValue: { borderRadius: 12, paddingHorizontal: 10, paddingVertical: 7 },
  bestValueText: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.9 },
  planLabel: { fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 1, marginTop: 22 },
  membershipName: { fontFamily: 'Inter_700Bold', fontSize: 27, lineHeight: 33, marginTop: 7, flexShrink: 1 },
  membershipDescription: { fontFamily: 'Inter_600SemiBold', fontSize: 16, lineHeight: 25, marginTop: 9 },
  priceRow: { flexDirection: 'row', alignItems: 'baseline', marginTop: 19 },
  price: { fontFamily: 'Inter_700Bold', fontSize: 24 },
  period: { fontFamily: 'Inter_600SemiBold', fontSize: 16 },
  shopButton: { minHeight: 56, borderRadius: 17, marginTop: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 12, paddingHorizontal: 16 },
  shopButtonText: { fontFamily: 'Inter_700Bold', fontSize: 18, textAlign: 'center', flexShrink: 1 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 11 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  included: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.9 },
  rewardHelp: { fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 21, marginBottom: 11 },
  collection: { gap: 10 },
  item: { borderWidth: 1, borderRadius: 20, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12, flexWrap: 'wrap' },
  itemIcon: { width: 44, height: 44, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  itemCopy: { flex: 1 },
  itemName: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  itemDescription: { fontFamily: 'Inter_500Medium', fontSize: 13, lineHeight: 20, marginTop: 4 },
  rewardAction: { minWidth: 76, borderWidth: 1, borderRadius: 14, paddingHorizontal: 9, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5 },
  rewardActionText: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 0.2 },
  itemActions: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  previewButton: { minWidth: 68, borderWidth: 1, borderRadius: 14, paddingHorizontal: 8, paddingVertical: 8, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 4 },
  previewText: { fontFamily: 'Inter_700Bold', fontSize: 10 },
  previewPanel: { width: '100%', borderRadius: 14, minHeight: 66, padding: 10, flexDirection: 'row', alignItems: 'center', gap: 10 },
  previewOrb: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  previewMoon: { borderRadius: 13, borderTopLeftRadius: 23 },
  previewDiamond: { width: 36, height: 36, borderRadius: 8 },
  previewSun: { width: 46, height: 46, borderWidth: 3 },
  previewAurora: { width: 34, height: 48, borderRadius: 18 },
  previewPaper: { width: 37, height: 45, borderRadius: 8 },
  previewCopy: { flex: 1, gap: 3 },
  previewLabel: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.9 },
  previewRhythm: { fontFamily: 'Inter_600SemiBold', fontSize: 12, lineHeight: 16 },
  showcaseCard: { borderRadius: 22, padding: 18, gap: 12 },
  showcaseTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 },
  showcaseCopy: { flex: 1 },
  showcaseEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 1 },
  showcaseTitle: { fontFamily: 'Inter_700Bold', fontSize: 21, marginTop: 6 },
  showcaseDetails: { fontFamily: 'Inter_600SemiBold', fontSize: 13, marginTop: 5 },
  collectionProgress: { fontFamily: 'Inter_500Medium', fontSize: 12 },
  collectibleGrid: { gap: 10 },
  collectible: { flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderRadius: 14, padding: 14, minHeight: 72 },
  collectibleText: { fontFamily: 'Inter_700Bold', fontSize: 16, flexShrink: 1 },
  collectibleStatus: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  capsuleCard: { borderRadius: 22, padding: 18, gap: 12 },
  capsuleTop: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  capsuleIcon: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  capsuleCopy: { flex: 1, gap: 3 },
  capsuleEyebrow: { fontFamily: 'Inter_700Bold', fontSize: 10, letterSpacing: 0.9 },
  capsuleTitle: { fontFamily: 'Inter_700Bold', fontSize: 20 },
  capsuleBalance: { fontFamily: 'Inter_700Bold', fontSize: 13 },
  capsuleBody: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21 },
  capsuleButton: { minHeight: 52, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingHorizontal: 14 },
  capsuleButtonText: { fontFamily: 'Inter_700Bold', fontSize: 15, textAlign: 'center' },
  capsuleNotice: { fontFamily: 'Inter_700Bold', fontSize: 13, lineHeight: 19 },
  promise: { borderRadius: 18, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  promiseText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 21 },
  disabled: { opacity: 0.58 },
  pressed: { opacity: 0.75, transform: [{ scale: 0.985 }] },
});
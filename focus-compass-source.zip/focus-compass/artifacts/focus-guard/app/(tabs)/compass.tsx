import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Pressable, ScrollView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import Animated, {
  useAnimatedStyle,
  withSpring,
  withTiming,
  useSharedValue,
  Easing,
  withRepeat,
  withSequence,
} from 'react-native-reanimated';
import Svg, { Circle, G, Line, Path, Defs, LinearGradient, RadialGradient, Stop } from 'react-native-svg';
import { useColors } from '@/hooks/useColors';
import { useFocus } from '@/context/FocusContext';

const COMPASS_SIZE = 280;

export default function CompassScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    minutesFocusedToday,
    todaySessions,
    dailyGoalMinutes,
    setDailyGoalMinutes,
  } = useFocus();
  
  const [editingGoal, setEditingGoal] = useState(false);
  const [tempGoal, setTempGoal] = useState(dailyGoalMinutes);
  const [showTodaySessions, setShowTodaySessions] = useState(false);

  const isGoalMet = minutesFocusedToday >= dailyGoalMinutes;
  
  // 0 to 1 progress mapping to angle
  const progress = Math.min(minutesFocusedToday / dailyGoalMinutes, 1);
  const targetRotation = -135 * (1 - progress);

  const needleRotation = useSharedValue(targetRotation);
  const needlePulse = useSharedValue(1);

  useEffect(() => {
    needleRotation.value = withSpring(targetRotation, {
      damping: 15,
      stiffness: 90,
      mass: 1,
    });

    if (isGoalMet) {
      needlePulse.value = withRepeat(
        withSequence(
          withTiming(1.05, { duration: 1000, easing: Easing.inOut(Easing.ease) }),
          withTiming(1, { duration: 1000, easing: Easing.inOut(Easing.ease) })
        ),
        -1,
        true
      );
    } else {
      needlePulse.value = withSpring(1);
    }
  }, [targetRotation, isGoalMet]);

  const animatedNeedleStyle = useAnimatedStyle(() => {
    return {
      transform: [
        { rotate: `${needleRotation.value}deg` },
        { scale: needlePulse.value }
      ],
    };
  });

  const handleSaveGoal = () => {
    setDailyGoalMinutes(Math.max(1, tempGoal));
    setEditingGoal(false);
  };

  const adjustGoal = (amount: number) => {
    setTempGoal(prev => Math.max(5, prev + amount));
  };

  const sortedTodaySessions = [...todaySessions].sort(
    (a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime(),
  );

  const formatSessionTimestamp = (completedAt: string) => {
    const date = new Date(completedAt);
    if (Number.isNaN(date.getTime())) return completedAt;
    return `${date.toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric',
    })} · ${date.toLocaleTimeString(undefined, {
      hour: 'numeric',
      minute: '2-digit',
    })}`;
  };

  const renderTicks = () => {
    const ticks = [];
    for (let i = 0; i < 120; i++) {
      const angle = i * 3;
      const isMajor = i % 10 === 0; 
      const isMedium = i % 5 === 0 && !isMajor; 
      
      const r1 = 124;
      const r2 = isMajor ? 112 : (isMedium ? 116 : 119);
      const strokeWidth = isMajor ? 2 : 1;
      const stroke = isMajor ? "#2c241b" : "rgba(44, 36, 27, 0.5)";
      
      const rad = (angle - 90) * (Math.PI / 180);
      const x1 = 140 + r1 * Math.cos(rad);
      const y1 = 140 + r1 * Math.sin(rad);
      const x2 = 140 + r2 * Math.cos(rad);
      const y2 = 140 + r2 * Math.sin(rad);
      
      ticks.push(
        <Line key={`tick-${i}`} x1={x1} y1={y1} x2={x2} y2={y2} stroke={stroke} strokeWidth={strokeWidth} strokeLinecap={isMajor ? "round" : "butt"} />
      );
    }
    
    ticks.push(
      <Circle key="inner-ring" cx="140" cy="140" r="90" fill="none" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="1" />
    );
    ticks.push(
      <Circle key="outer-ring" cx="140" cy="140" r="111" fill="none" stroke="#2c241b" strokeWidth="1.5" />
    );
    return ticks;
  };

  const renderCompassRose = () => {
    return (
      <G transform="translate(140, 140)">
        <Path d="M 0 -85 L 12 -15 L 0 0 Z" fill="rgba(44, 36, 27, 0.1)" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="0.5" />
        <Path d="M 0 -85 L -12 -15 L 0 0 Z" fill="rgba(44, 36, 27, 0.03)" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="0.5" />
        
        <Path d="M 85 0 L 15 12 L 0 0 Z" fill="rgba(44, 36, 27, 0.1)" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="0.5" />
        <Path d="M 85 0 L 15 -12 L 0 0 Z" fill="rgba(44, 36, 27, 0.03)" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="0.5" />
        
        <Path d="M 0 85 L -12 15 L 0 0 Z" fill="rgba(44, 36, 27, 0.1)" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="0.5" />
        <Path d="M 0 85 L 12 15 L 0 0 Z" fill="rgba(44, 36, 27, 0.03)" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="0.5" />
        
        <Path d="M -85 0 L -15 -12 L 0 0 Z" fill="rgba(44, 36, 27, 0.1)" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="0.5" />
        <Path d="M -85 0 L -15 12 L 0 0 Z" fill="rgba(44, 36, 27, 0.03)" stroke="rgba(44, 36, 27, 0.2)" strokeWidth="0.5" />
        
        <Path d="M 55 -55 L 12 -12 L 0 0 Z" fill="rgba(44, 36, 27, 0.08)" stroke="rgba(44, 36, 27, 0.15)" strokeWidth="0.5" />
        <Path d="M 55 -55 L 6 -16 L 0 0 Z" fill="rgba(44, 36, 27, 0.02)" stroke="rgba(44, 36, 27, 0.15)" strokeWidth="0.5" />

        <Path d="M 55 55 L 6 16 L 0 0 Z" fill="rgba(44, 36, 27, 0.08)" stroke="rgba(44, 36, 27, 0.15)" strokeWidth="0.5" />
        <Path d="M 55 55 L 12 12 L 0 0 Z" fill="rgba(44, 36, 27, 0.02)" stroke="rgba(44, 36, 27, 0.15)" strokeWidth="0.5" />

        <Path d="M -55 55 L -12 12 L 0 0 Z" fill="rgba(44, 36, 27, 0.08)" stroke="rgba(44, 36, 27, 0.15)" strokeWidth="0.5" />
        <Path d="M -55 55 L -6 16 L 0 0 Z" fill="rgba(44, 36, 27, 0.02)" stroke="rgba(44, 36, 27, 0.15)" strokeWidth="0.5" />

        <Path d="M -55 -55 L -6 -16 L 0 0 Z" fill="rgba(44, 36, 27, 0.08)" stroke="rgba(44, 36, 27, 0.15)" strokeWidth="0.5" />
        <Path d="M -55 -55 L -12 -12 L 0 0 Z" fill="rgba(44, 36, 27, 0.02)" stroke="rgba(44, 36, 27, 0.15)" strokeWidth="0.5" />
      </G>
    );
  };

  const renderBezel = () => {
    return (
      <>
        <Defs>
          <LinearGradient id="brassOuter" x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0%" stopColor="#b58d3d" />
            <Stop offset="25%" stopColor="#e3c784" />
            <Stop offset="50%" stopColor="#8a6327" />
            <Stop offset="75%" stopColor="#f5e09f" />
            <Stop offset="100%" stopColor="#634516" />
          </LinearGradient>
          <LinearGradient id="brassInner" x1="0" y1="1" x2="1" y2="0">
            <Stop offset="0%" stopColor="#7a5519" />
            <Stop offset="30%" stopColor="#cfae61" />
            <Stop offset="50%" stopColor="#fdf0ba" />
            <Stop offset="80%" stopColor="#966e2d" />
            <Stop offset="100%" stopColor="#4a310b" />
          </LinearGradient>
          <RadialGradient id="ivoryFace" cx="50%" cy="50%" r="50%" fx="30%" fy="30%">
            <Stop offset="0%" stopColor="#fdfaf3" />
            <Stop offset="70%" stopColor="#efe5d0" />
            <Stop offset="90%" stopColor="#e0ceb1" />
            <Stop offset="100%" stopColor="#cca976" />
          </RadialGradient>
        </Defs>
        <Circle cx="140" cy="140" r="140" fill="url(#brassOuter)" />
        <Circle cx="140" cy="140" r="132" fill="url(#brassInner)" />
        <Circle cx="140" cy="140" r="124" fill="url(#ivoryFace)" />
        <Circle cx="140" cy="140" r="124" fill="none" stroke="rgba(74, 49, 11, 0.2)" strokeWidth="6" />
        <Circle cx="140" cy="140" r="121" fill="none" stroke="rgba(255, 255, 255, 0.3)" strokeWidth="1" />
      </>
    );
  };

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + 40, paddingBottom: insets.bottom + 40 }
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.header}>
          <Text style={[styles.title, { color: colors.foreground }]}>Your Compass</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            Building consistent daily focus.
          </Text>
        </View>

        <View
          style={styles.compassContainer}
          accessible
          accessibilityLabel={isGoalMet
            ? 'Compass pointing to Success. Recorded timer minute goal met.'
            : `Recorded timer minutes today: ${minutesFocusedToday} of ${dailyGoalMinutes}.`}
        >
          <View style={styles.compassRing}>
            <Svg width={COMPASS_SIZE} height={COMPASS_SIZE} style={StyleSheet.absoluteFill}>
              {renderBezel()}
              {renderTicks()}
              {renderCompassRose()}
            </Svg>

            <View style={[styles.marker, styles.northMarker]}>
              <Text style={[styles.successLabel, { opacity: isGoalMet ? 1 : 0, color: isGoalMet ? '#1a3b5c' : colors.primary }]}>
                SUCCESS
              </Text>
              <Text style={[styles.antiqueMarkerText, { color: isGoalMet ? '#1a3b5c' : '#8a251e', fontWeight: isGoalMet ? '800' : '600' }]}>
                N
              </Text>
            </View>
            
            <View style={[styles.marker, styles.eastMarker]}>
              <Text style={[styles.antiqueMarkerText, { color: '#3d3024' }]}>E</Text>
            </View>
            <View style={[styles.marker, styles.southMarker]}>
              <Text style={[styles.antiqueMarkerText, { color: '#3d3024' }]}>S</Text>
            </View>
            <View style={[styles.marker, styles.westMarker]}>
              <Text style={[styles.antiqueMarkerText, { color: '#3d3024' }]}>W</Text>
            </View>

            <Animated.View style={[styles.needleContainer, animatedNeedleStyle]}>
              <Svg width={40} height={260} viewBox="0 0 40 260">
                <Defs>
                  <LinearGradient id="brassPin" x1="0" y1="0" x2="1" y2="1">
                    <Stop offset="0%" stopColor="#f5e09f" />
                    <Stop offset="50%" stopColor="#cfae61" />
                    <Stop offset="100%" stopColor="#634516" />
                  </LinearGradient>
                  <LinearGradient id="needleDarkSide" x1="0" y1="0" x2="1" y2="0">
                    <Stop offset="0%" stopColor="#1a1a1a" />
                    <Stop offset="100%" stopColor="#3d3d3d" />
                  </LinearGradient>
                  <LinearGradient id="needleLightSide" x1="0" y1="0" x2="1" y2="0">
                    <Stop offset="0%" stopColor="#4a4a4a" />
                    <Stop offset="100%" stopColor="#808080" />
                  </LinearGradient>
                  <LinearGradient id="needleRedDark" x1="0" y1="0" x2="1" y2="0">
                    <Stop offset="0%" stopColor="#5c110b" />
                    <Stop offset="100%" stopColor="#8a251e" />
                  </LinearGradient>
                  <LinearGradient id="needleRedLight" x1="0" y1="0" x2="1" y2="0">
                    <Stop offset="0%" stopColor="#ba382f" />
                    <Stop offset="100%" stopColor="#d45b53" />
                  </LinearGradient>
                  <LinearGradient id="needleBlueDark" x1="0" y1="0" x2="1" y2="0">
                    <Stop offset="0%" stopColor="#0f1b29" />
                    <Stop offset="100%" stopColor="#1a3b5c" />
                  </LinearGradient>
                  <LinearGradient id="needleBlueLight" x1="0" y1="0" x2="1" y2="0">
                    <Stop offset="0%" stopColor="#2c537a" />
                    <Stop offset="100%" stopColor="#4a7aab" />
                  </LinearGradient>
                </Defs>
                
                <G style={{ shadowColor: '#000', shadowOpacity: 0.35, shadowRadius: 8, shadowOffset: {width: 0, height: 16} }}>
                  <Path d="M 20 15 L 32 130 L 20 245 L 8 130 Z" fill="rgba(0,0,0,0.25)" transform="translate(6, 12)" />
                  
                  <Path d="M 20 15 L 32 130 L 20 130 Z" fill={isGoalMet ? "url(#needleBlueDark)" : "url(#needleRedDark)"} />
                  <Path d="M 20 15 L 8 130 L 20 130 Z" fill={isGoalMet ? "url(#needleBlueLight)" : "url(#needleRedLight)"} />

                  <Path d="M 20 245 L 32 130 L 20 130 Z" fill="url(#needleDarkSide)" />
                  <Path d="M 20 245 L 8 130 L 20 130 Z" fill="url(#needleLightSide)" />
                  
                  <Circle cx="20" cy="130" r="12" fill="#1a1a1a" />
                  <Circle cx="20" cy="130" r="10" fill="url(#brassPin)" />
                  <Circle cx="20" cy="130" r="3" fill="#3a250a" />
                </G>
              </Svg>
            </Animated.View>
          </View>
        </View>

        <View style={[styles.statsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.statsHeader}>
             <Text style={[styles.statsTitle, { color: colors.foreground }]}>Daily Recorded Total</Text>
             {isGoalMet && (
               <View style={[styles.successBadge, { backgroundColor: colors.primary + '20' }]}>
                 <Feather name="check" size={14} color={colors.primary} />
                 <Text style={[styles.successBadgeText, { color: colors.primary }]}>Goal Met</Text>
               </View>
             )}
          </View>
          
          <View style={styles.statsRow}>
            <View style={styles.statBox}>
              <Text style={[styles.statValue, { color: colors.foreground }]}>{minutesFocusedToday}</Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>Recorded timer minutes</Text>
            </View>
            <View style={[styles.divider, { backgroundColor: colors.border }]} />
            <View style={styles.statBox}>
              <Text style={[styles.statValue, { color: colors.foreground }]}>{dailyGoalMinutes}</Text>
              <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>Daily Goal</Text>
            </View>
          </View>
          <Text style={[styles.statsFootnote, { color: colors.mutedForeground }]}>
            Timer minutes are grouped by completion date in this device’s current time zone.
          </Text>

          {editingGoal ? (
            <View style={styles.editGoalSection}>
              <Text style={[styles.editGoalLabel, { color: colors.foreground }]}>Adjust Daily Goal</Text>
              <View style={styles.editControls}>
                <Pressable
                  onPress={() => adjustGoal(-5)}
                  style={({ pressed }) => [
                    styles.adjustButton,
                    { backgroundColor: colors.secondary },
                    pressed && { opacity: 0.7 }
                  ]}
                >
                  <Feather name="minus" size={20} color={colors.foreground} />
                </Pressable>
                
                <Text style={[styles.tempGoalValue, { color: colors.foreground }]}>{tempGoal}m</Text>
                
                <Pressable
                  onPress={() => adjustGoal(5)}
                  style={({ pressed }) => [
                    styles.adjustButton,
                    { backgroundColor: colors.secondary },
                    pressed && { opacity: 0.7 }
                  ]}
                >
                  <Feather name="plus" size={20} color={colors.foreground} />
                </Pressable>
              </View>
              
              <View style={styles.editActions}>
                <Pressable
                  onPress={() => {
                    setTempGoal(dailyGoalMinutes);
                    setEditingGoal(false);
                  }}
                  style={[styles.actionButton, styles.cancelButton, { backgroundColor: colors.secondary }]}
                >
                  <Text style={[styles.actionButtonText, { color: colors.foreground }]}>Cancel</Text>
                </Pressable>
                <Pressable
                  onPress={handleSaveGoal}
                  style={[styles.actionButton, styles.saveButton, { backgroundColor: colors.primary }]}
                >
                  <Text style={[styles.actionButtonText, { color: colors.primaryForeground }]}>Save</Text>
                </Pressable>
              </View>
            </View>
          ) : (
            <Pressable
              onPress={() => {
                setTempGoal(dailyGoalMinutes);
                setEditingGoal(true);
              }}
              style={({ pressed }) => [
                styles.editGoalButton,
                { borderColor: colors.border },
                pressed && { backgroundColor: colors.secondary }
              ]}
            >
              <Feather name="target" size={16} color={colors.mutedForeground} />
              <Text style={[styles.editGoalButtonText, { color: colors.mutedForeground }]}>
                Change Goal
              </Text>
            </Pressable>
          )}

          <Pressable
            accessibilityRole="button"
            accessibilityLabel={showTodaySessions ? 'Hide today session breakdown' : 'Show today session breakdown'}
            accessibilityState={{ expanded: showTodaySessions }}
            onPress={() => setShowTodaySessions((visible) => !visible)}
            style={({ pressed }) => [
              styles.breakdownToggle,
              { borderColor: colors.border },
              pressed && { opacity: 0.7 },
            ]}
          >
            <View style={styles.breakdownToggleCopy}>
              <Text style={[styles.breakdownTitle, { color: colors.foreground }]}>Today’s sessions</Text>
              <Text style={[styles.breakdownSubtitle, { color: colors.mutedForeground }]}>
                {todaySessions.length
                  ? `${todaySessions.length} recorded ${todaySessions.length === 1 ? 'timer' : 'timers'}`
                  : 'No timer sessions recorded'}
              </Text>
            </View>
            <Feather
              name={showTodaySessions ? 'chevron-up' : 'chevron-down'}
              size={20}
              color={colors.mutedForeground}
            />
          </Pressable>

          {showTodaySessions && (
            <View style={styles.sessionBreakdown}>
              {sortedTodaySessions.length ? (
                sortedTodaySessions.map((session) => (
                  <View key={session.id} style={styles.sessionRow}>
                    <View style={styles.sessionRowCopy}>
                      <Text style={[styles.sessionTimestamp, { color: colors.foreground }]}>
                        {formatSessionTimestamp(session.completedAt)}
                      </Text>
                      <Text style={[styles.sessionTimestampLabel, { color: colors.mutedForeground }]}>
                        Completed
                      </Text>
                    </View>
                    <Text style={[styles.sessionMinutes, { color: colors.primary }]}>
                      {session.durationMinutes} {session.durationMinutes === 1 ? 'min' : 'mins'}
                    </Text>
                  </View>
                ))
              ) : (
                <Text style={[styles.emptyBreakdown, { color: colors.mutedForeground }]}>
                  Finish a timer to see its recorded completion time and minutes here.
                </Text>
              )}
              <Text style={[styles.breakdownNote, { color: colors.mutedForeground }]}>
                Totals use completion dates in this device’s current time zone. Older saved timestamps may be inaccurate. Your daily goal is saved on this device.
              </Text>
            </View>
          )}
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
  },
  title: {
    fontFamily: 'Inter_700Bold',
    fontSize: 28,
    letterSpacing: -0.5,
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: 'Inter_500Medium',
    fontSize: 16,
    textAlign: 'center',
  },
  compassContainer: {
    width: COMPASS_SIZE,
    height: COMPASS_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 48,
  },
  compassRing: {
    width: '100%',
    height: '100%',
    borderRadius: COMPASS_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.15,
    shadowRadius: 32,
    elevation: 10,
  },
  marker: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    width: 40,
    height: 40,
    zIndex: 10,
  },
  northMarker: { 
    top: 16,
    height: 60,
  },
  southMarker: { bottom: 26 },
  eastMarker: { right: 26 },
  westMarker: { left: 26 },
  markerText: {
    fontFamily: 'Inter_700Bold',
    fontSize: 22,
  },
  antiqueMarkerText: {
    fontFamily: Platform.OS === 'ios' ? 'Georgia' : 'serif',
    fontSize: 26,
    fontStyle: 'italic',
  },
  successLabel: {
    fontFamily: 'Inter_700Bold',
    fontSize: 12,
    textTransform: 'uppercase',
    letterSpacing: 1.5,
    marginBottom: 2,
  },
  needleContainer: {
    width: 40,
    height: 260,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'absolute',
    zIndex: 20,
  },
  statsCard: {
    width: '100%',
    borderRadius: 24,
    borderWidth: 1,
    padding: 24,
  },
  statsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 24,
  },
  statsTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 18,
  },
  successBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    gap: 6,
  },
  successBadgeText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 13,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  statBox: {
    flex: 1,
  },
  statValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 36,
    marginBottom: 4,
  },
  statLabel: {
    fontFamily: 'Inter_500Medium',
    fontSize: 14,
  },
  divider: {
    width: 1,
    height: 40,
    marginHorizontal: 24,
  },
  statsFootnote: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    lineHeight: 18,
    marginBottom: 8,
  },
  editGoalButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderRadius: 12,
    borderWidth: 1,
    gap: 8,
  },
  editGoalButtonText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
  },
  breakdownToggle: {
    borderTopWidth: 1,
    marginTop: 20,
    paddingTop: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  breakdownToggleCopy: {
    flex: 1,
    gap: 3,
  },
  breakdownTitle: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
  },
  breakdownSubtitle: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
  },
  sessionBreakdown: {
    marginTop: 12,
    gap: 10,
  },
  sessionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  sessionRowCopy: {
    flex: 1,
    gap: 2,
  },
  sessionTimestamp: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 14,
  },
  sessionTimestampLabel: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
  },
  sessionMinutes: {
    fontFamily: 'Inter_700Bold',
    fontSize: 14,
  },
  emptyBreakdown: {
    fontFamily: 'Inter_500Medium',
    fontSize: 13,
    lineHeight: 19,
  },
  breakdownNote: {
    fontFamily: 'Inter_500Medium',
    fontSize: 12,
    lineHeight: 18,
    marginTop: 4,
  },
  editGoalSection: {
    marginTop: 8,
    paddingTop: 24,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.05)',
  },
  editGoalLabel: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
    marginBottom: 16,
    textAlign: 'center',
  },
  editControls: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 24,
    marginBottom: 24,
  },
  adjustButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tempGoalValue: {
    fontFamily: 'Inter_700Bold',
    fontSize: 28,
    minWidth: 80,
    textAlign: 'center',
  },
  editActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: 'center',
  },
  cancelButton: {
    borderWidth: 0,
  },
  saveButton: {
    borderWidth: 0,
  },
  actionButtonText: {
    fontFamily: 'Inter_600SemiBold',
    fontSize: 15,
  },
});

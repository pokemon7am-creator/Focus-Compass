import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useMemo, useRef, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useFocus } from '@/context/FocusContext';
import { useColors } from '@/hooks/useColors';
import { useDailyFrictionCompletion } from '@/hooks/useDailyFrictionCompletion';

type Difficulty = 1 | 2 | 3 | 4;

const physicalChallenges = {
  1: [
    ['8 slow squats', 'Move at a comfortable pace. Stop if anything hurts.'],
    ['15-second wall sit', 'Keep it gentle and use support if you need it.'],
    ['20-second standing reset', 'Stretch your shoulders and take three easy breaths.'],
  ],
  2: [
    ['12 slow squats', 'Keep your chest lifted and move with control. Stop if anything hurts.'],
    ['25-second wall sit', 'Use wall support and keep the position comfortable.'],
    ['30-second movement reset', 'March gently, roll your shoulders, then take four easy breaths.'],
  ],
  3: [
    ['18 controlled squats', 'Use a chair for support if needed. Stop if anything hurts.'],
    ['40-second wall sit', 'Adjust your depth or stand early if you feel discomfort.'],
    ['45-second movement reset', 'March in place, stretch, and finish with five calm breaths.'],
  ],
  4: [
    ['25 controlled squats', 'Break them into smaller sets and stop if anything hurts.'],
    ['60-second wall sit', 'Use a comfortable depth and take breaks whenever needed.'],
    ['60-second movement reset', 'March, stretch both sides, and finish with six slow breaths.'],
  ],
} satisfies Record<Difficulty, [string, string][]>;

function getDifficulty(minutes: number): Difficulty {
  if (minutes >= 45) return 4;
  if (minutes >= 25) return 3;
  if (minutes >= 10) return 2;
  return 1;
}

function getMathProblem(level: Difficulty, seed: number) {
  if (level === 1) {
    const a = 8 + (seed % 8);
    const b = 4 + (seed % 5);
    return { expression: `${a} + ${b}`, answer: a + b };
  }
  if (level === 2) {
    const a = 34 + (seed % 23);
    const b = 18 + (seed % 19);
    return { expression: `${a} + ${b}`, answer: a + b };
  }
  if (level === 3) {
    const a = 7 + (seed % 7);
    const b = 6 + ((seed * 3) % 7);
    return { expression: `${a} × ${b}`, answer: a * b };
  }
  const a = 11 + (seed % 8);
  const b = 7 + ((seed * 3) % 6);
  const c = 13 + ((seed * 5) % 18);
  return { expression: `(${a} × ${b}) − ${c}`, answer: a * b - c };
}

let challengeVisitSequence = 0;

export default function ChallengeScreen() {
  const colors = useColors();
  const focus = useFocus();
  const { kind, mode } = useLocalSearchParams<{ kind?: string; mode?: string }>();
  const isMath = kind === 'math';
  const challengeKind = isMath ? 'math' : 'physical';
  const isQuickReset = !isMath && mode === 'quick-reset';
  const dailyCompletion = useDailyFrictionCompletion(challengeKind);
  const elapsedMinutes = Math.max(
    0,
    Math.floor((focus.sessionSeconds - focus.remainingSeconds) / 60),
  );
  const difficulty = getDifficulty(elapsedMinutes);
  const [visitSequence] = useState(() => {
    challengeVisitSequence += 1;
    return challengeVisitSequence;
  });
  const seed = Math.max(1, elapsedMinutes * 17 + visitSequence);
  const physical = useMemo(
    () => isQuickReset
      ? ['30-second reset', 'Stand, stretch your shoulders, and take three easy breaths.']
      : physicalChallenges[difficulty][seed % physicalChallenges[difficulty].length],
    [difficulty, isQuickReset, seed],
  );
  const math = useMemo(() => getMathProblem(difficulty, seed), [difficulty, seed]);
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const savingRef = useRef(false);

  React.useEffect(() => {
    if (mode === 'app-switch') {
      focus.clearFrictionCheck();
      router.replace('/roast?mode=app-switch');
    }
  }, [focus.clearFrictionCheck, mode]);

  const markComplete = async () => {
    if (savingRef.current) return;
    if (isMath && Number(answer.trim()) !== math.answer) {
      setError('Not quite. Check the order of operations and try again.');
      return;
    }
    savingRef.current = true;
    setError('');
    setIsSaving(true);
    try {
      // Do not show success until the scoped daily completion is persisted.
      await dailyCompletion.complete();
      focus.completeFrictionPath(challengeKind);
    } catch {
      setError('Could not save your completion. Try again.');
    } finally {
      savingRef.current = false;
      setIsSaving(false);
    }
  };

  if (mode === 'app-switch') return null;

  if (dailyCompletion.status !== 'available') {
    const statusError = dailyCompletion.status === 'error';
    const statusComplete = dailyCompletion.status === 'completed';
    const challengeLabel = isMath ? 'Math' : 'Physical';
    return (
      <Screen>
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} style={styles.back}>
            <Feather name="arrow-left" size={20} color={colors.foreground} />
            <Text style={[styles.backText, { color: colors.foreground }]}>Back to choices</Text>
          </Pressable>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>{challengeLabel.toUpperCase()} FRICTION</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>
            {statusComplete ? `${challengeLabel} complete for today.` : statusError ? 'Status unavailable.' : 'Checking availability…'}
          </Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {statusComplete
              ? `You can complete another ${challengeLabel.toLowerCase()} friction challenge tomorrow.`
              : statusError
                ? dailyCompletion.error
                : 'Loading this device’s completion status before starting a problem.'}
          </Text>
        </View>
        <View style={[styles.challengeCard, { backgroundColor: colors.deepBackground }]}>
          <View style={[styles.challengeIcon, { backgroundColor: colors.accent }]}>
            <Feather name={statusComplete ? 'check' : statusError ? 'alert-circle' : 'clock'} size={34} color={colors.accentForeground} />
          </View>
          <Text style={[styles.challengeTitle, { color: colors.deepForeground, fontSize: 25 }]}>
            {statusComplete ? 'Completed today · Available tomorrow' : statusError ? 'Your daily status must load first' : 'Checking this device…'}
          </Text>
          <Pressable
            testID={statusError ? `retry-challenge-${challengeKind}-status` : `completed-${challengeKind}-return`}
            disabled={!statusError && !statusComplete}
            onPress={statusError ? () => void dailyCompletion.refresh() : () => router.back()}
            style={({ pressed }) => [
              styles.completeButton,
              { backgroundColor: colors.deepForeground },
              pressed && styles.pressed,
            ]}
          >
            <Feather name={statusError ? 'refresh-cw' : 'arrow-left'} size={18} color={colors.deepBackground} />
            <Text style={[styles.completeText, { color: colors.deepBackground }]}>
              {statusError ? 'Retry status' : statusComplete ? 'Return to choices' : 'Please wait'}
            </Text>
          </Pressable>
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable onPress={() => router.back()} style={styles.back}>
          <Feather name="arrow-left" size={20} color={colors.foreground} />
          <Text style={[styles.backText, { color: colors.foreground }]}>Back to choices</Text>
        </Pressable>
        <Text style={[styles.eyebrow, { color: isMath ? colors.primary : colors.foreground }]}>
          {isMath ? 'MATH FRICTION' : 'PHYSICAL FRICTION'} · LEVEL {difficulty}
        </Text>
        <Text style={[styles.title, { color: colors.foreground }]}>
          {isMath ? 'Solve before you switch.' : 'Move before you switch.'}
        </Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          This level reflects the {elapsedMinutes} focused {elapsedMinutes === 1 ? 'minute' : 'minutes'} you interrupted.
          {!isMath ? ' Completion is self-reported; Focus Compass does not use your camera or motion sensors to verify movement.' : ''}
        </Text>
      </View>

      <View
        style={[
          styles.challengeCard,
           { backgroundColor: isMath ? colors.deepBackground : colors.secondary },
        ]}
      >
        <View style={[styles.challengeIcon, { backgroundColor: colors.accent }]}>
          <Feather name={isMath ? 'hash' : 'activity'} size={34} color={colors.accentForeground} />
        </View>
        <Text
          style={[
            styles.challengeLabel,
             { color: isMath ? colors.deepForeground : colors.foreground },
             isMath && styles.mathLabel,
          ]}
        >
          LEVEL {difficulty} CHALLENGE
        </Text>
        <Text
          style={[
            styles.challengeTitle,
             { color: isMath ? colors.deepForeground : colors.foreground },
             isMath && styles.mathExpression,
          ]}
        >
          {isMath ? math.expression : physical[0]}
        </Text>
        <Text
          style={[
            styles.challengeDetail,
             { color: isMath ? colors.deepMuted : colors.foreground },
             isMath && styles.mathInstructions,
          ]}
        >
          {isMath
            ? 'Enter the exact answer. No timer—accuracy matters more than speed.'
            : physical[1]}
        </Text>

        {isMath ? (
          <TextInput
            testID="math-answer"
             accessibilityLabel="Your answer to the math problem"
            value={answer}
            onChangeText={(value) => {
              setAnswer(value);
              setError('');
            }}
            keyboardType="numbers-and-punctuation"
            placeholder="Your answer"
             placeholderTextColor={colors.deepBackground}
             selectionColor={colors.deepBackground}
             style={[styles.answerInput, { backgroundColor: colors.deepForeground, color: colors.deepBackground }]}
          />
        ) : null}
         {error ? <Text accessibilityRole="alert" accessibilityLiveRegion="polite" style={[styles.error, isMath && styles.mathError]}>{error}</Text> : null}

        <Pressable
          testID="complete-challenge"
          accessibilityState={{ disabled: isSaving }}
          disabled={isSaving}
          onPress={markComplete}
          style={({ pressed }) => [
            styles.completeButton,
             { backgroundColor: isMath ? colors.deepForeground : colors.primary },
             isMath && styles.mathButton,
             isSaving && styles.disabled,
             pressed && styles.pressed,
          ]}
        >
            <Feather name={isMath ? 'check' : 'activity'} size={18} color={isMath ? colors.deepBackground : colors.primaryForeground} />
           <Text style={[styles.completeText, { color: isMath ? colors.deepBackground : colors.primaryForeground }, isMath && styles.mathButtonText]}>
              {isSaving ? 'Saving completion…' : isMath ? 'Check answer' : 'I completed it'}
          </Text>
        </Pressable>
      </View>

      {!isMath ? (
        <View style={[styles.alternative, { backgroundColor: colors.secondary }]}>
          <Feather name="heart" size={19} color={colors.secondaryForeground} />
          <View style={styles.alternativeCopy}>
            <Text style={[styles.alternativeTitle, { color: colors.secondaryForeground }]}>
              Keep it comfortable.
            </Text>
            <Text style={[styles.alternativeBody, { color: colors.secondaryForeground }]}>
              Stop immediately if anything hurts. This is self-reported, not camera-verified.
            </Text>
            {!isQuickReset ? (
              <Pressable
                testID="quick-physical-reset"
                onPress={() => router.replace('/challenge?kind=physical&mode=quick-reset')}
              >
                <Text style={[styles.quickResetText, { color: colors.primary }]}>
                  Prefer a lower-impact option? Use the 30-second reset.
                </Text>
              </Pressable>
            ) : null}
          </View>
        </View>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { gap: 8 },
  back: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 },
  backText: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, letterSpacing: -0.7 },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24 },
  challengeCard: { borderRadius: 28, padding: 24, alignItems: 'center' },
  challengeIcon: { width: 76, height: 76, borderRadius: 24, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  challengeLabel: { color: '#F6D98C', fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 1.1 },
  challengeTitle: { color: '#FFF9F1', fontFamily: 'Inter_700Bold', fontSize: 32, lineHeight: 39, textAlign: 'center', marginTop: 10 },
  challengeDetail: { color: '#F1F5F2', fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, textAlign: 'center', marginTop: 8 },
  mathLabel: { fontSize: 14, lineHeight: 22, textAlign: 'center' },
  mathExpression: { fontSize: 40, lineHeight: 52, width: '100%', fontVariant: ['tabular-nums'], marginTop: 16 },
  mathInstructions: { fontSize: 18, lineHeight: 28, marginTop: 14 },
  answerInput: { minHeight: 68, alignSelf: 'stretch', marginTop: 20, borderRadius: 17, fontFamily: 'Inter_700Bold', fontSize: 28, textAlign: 'center', paddingHorizontal: 16, paddingVertical: 14 },
  mathError: { fontSize: 17, lineHeight: 26 },
  mathButton: { minHeight: 60, paddingVertical: 14, paddingHorizontal: 16 },
  mathButtonText: { fontSize: 18, lineHeight: 26, textAlign: 'center', flexShrink: 1 },
  error: { color: '#FFB4A9', fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 20, textAlign: 'center', marginTop: 10 },
  completeButton: { minHeight: 56, alignSelf: 'stretch', borderRadius: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 22 },
  completeText: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  alternative: { borderRadius: 18, padding: 15, flexDirection: 'row', gap: 11, alignItems: 'flex-start' },
  alternativeCopy: { flex: 1, gap: 3 },
  alternativeTitle: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  alternativeBody: { flex: 1, fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 21 },
  quickResetText: { fontFamily: 'Inter_700Bold', fontSize: 14, lineHeight: 20, marginTop: 6 },
  pressed: { opacity: 0.75, transform: [{ scale: 0.985 }] },
  disabled: { opacity: 0.55 },
});
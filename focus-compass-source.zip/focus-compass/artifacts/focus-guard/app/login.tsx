import { useAuth, useSignIn } from '@clerk/expo';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useColors } from '@/hooks/useColors';

export default function LoginScreen() {
  const colors = useColors();
  const { signIn, errors, fetchStatus } = useSignIn();
  const { isLoaded } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const busy = !isLoaded || fetchStatus === 'fetching';
  const message = isLoaded ? errors?.global?.[0]?.message : undefined;

  const submit = async () => {
    if (!isLoaded || !signIn) return;
    const result = await signIn.password({ emailAddress: email.trim(), password });
    if (result.error) return;
    if (signIn.status === 'complete') {
      await signIn.finalize({ navigate: () => router.replace('/(tabs)') });
    }
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>FOCUS COMPASS</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Welcome back.</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Sign in to keep your practice available across devices.</Text>
      </View>
      <View style={[styles.form, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.label, { color: colors.foreground }]}>Email address</Text>
        <TextInput editable={isLoaded} value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="you@example.com" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} />
        <Text style={[styles.label, { color: colors.foreground }]}>Password</Text>
        <TextInput editable={isLoaded} value={password} onChangeText={setPassword} secureTextEntry placeholder="Your password" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} />
        {message ? <Text style={[styles.error, { color: colors.destructive }]}>{message}</Text> : null}
        <Pressable disabled={busy || !email || !password} onPress={submit} style={({ pressed }) => [styles.button, { backgroundColor: colors.primary }, (busy || !email || !password) && styles.disabled, pressed && styles.pressed]}>
          <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>{!isLoaded ? 'Connecting…' : busy ? 'Signing in…' : 'Sign in'}</Text>
        </Pressable>
      </View>
      <Pressable onPress={() => router.push('/signup')} style={styles.linkButton}>
        <Text style={[styles.linkText, { color: colors.primary }]}>New to Focus Compass? Create an account</Text>
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { gap: 7, alignItems: 'center', marginBottom: 12 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, textAlign: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 32, lineHeight: 38, textAlign: 'center' },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, textAlign: 'center' },
  form: { borderWidth: 1, borderRadius: 24, padding: 18, gap: 10 },
  label: { fontFamily: 'Inter_700Bold', fontSize: 15, marginTop: 2 },
  input: { height: 52, borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, fontFamily: 'Inter_500Medium', fontSize: 16, marginBottom: 7 },
  error: { fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 20 },
  button: { minHeight: 54, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginTop: 6, paddingVertical: 12, paddingHorizontal: 16 },
  buttonText: { fontFamily: 'Inter_700Bold', fontSize: 17, textAlign: 'center', flexShrink: 1 },
  linkButton: { alignItems: 'center', padding: 10, marginTop: 10 },
  linkText: { fontFamily: 'Inter_700Bold', fontSize: 15, textAlign: 'center' },
  disabled: { opacity: 0.5 },
  pressed: { opacity: 0.75 },
});
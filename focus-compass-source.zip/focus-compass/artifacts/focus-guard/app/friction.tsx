import { Feather } from '@expo/vector-icons';
import { router, type Href, useLocalSearchParams } from 'expo-router';
import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useFocus } from '@/context/FocusContext';
import { useColors } from '@/hooks/useColors';
import {
  type DailyFrictionKind,
  useDailyFrictionCompletion,
} from '@/hooks/useDailyFrictionCompletion';

const options = [
  {
    id: 'physical',
    icon: 'activity' as const,
    title: 'Physical reset',
    body: 'Move your body before returning to the task.',
    route: '/challenge?kind=physical',
  },
  {
    id: 'math',
    icon: 'hash' as const,
    title: 'Math reset',
    body: 'Solve a quick problem before returning to the task.',
    route: '/challenge?kind=math',
  },
] satisfies { id: DailyFrictionKind; icon: 'activity' | 'hash'; title: string; body: string; route: Href }[];

function difficultyLabel(minutes: number) {
  if (minutes >= 45) return 'LEVEL 4 · INTENSE';
  if (minutes >= 25) return 'LEVEL 3 · HARD';
  if (minutes >= 10) return 'LEVEL 2 · MEDIUM';
  return 'LEVEL 1 · LIGHT';
}

export default function FrictionScreen() {
  const colors = useColors();
  const focus = useFocus();
  const { mode } = useLocalSearchParams<{ mode?: string }>();
  const physicalDaily = useDailyFrictionCompletion('physical');
  const mathDaily = useDailyFrictionCompletion('math');
  const dailyByKind = { physical: physicalDaily, math: mathDaily };
  const elapsedMinutes = Math.max(
    0,
    Math.floor((focus.sessionSeconds - focus.remainingSeconds) / 60),
  );
  const isEscapeCheck = mode === 'app-switch';
  const canContinue = !isEscapeCheck || focus.frictionCheck.completed;

  React.useEffect(() => {
    if (isEscapeCheck) {
      focus.clearFrictionCheck();
      router.replace('/roast?mode=app-switch');
    }
  }, [focus.clearFrictionCheck, isEscapeCheck]);

  // Older notifications and navigation history may still point here. Automatic
  // app-switch checks no longer offer a math/physical choice.
  if (isEscapeCheck) return null;

  return (
    <Screen style={styles.screen}>
      <View style={styles.header}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>MANUAL RESET</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Choose a reset.</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
          Choose a physical or math reset whenever you want to pause and return to your task.
        </Text>
        <View style={[styles.levelPill, { backgroundColor: colors.accent }]}>
          <Text style={[styles.levelText, { color: colors.accentForeground }]}>
            {difficultyLabel(elapsedMinutes)}
          </Text>
        </View>
      </View>

      <View style={styles.options}>
        {options.map((option) => {
          const daily = dailyByKind[option.id];
          const unavailable = daily.status !== 'available';
          const optionStatus = daily.status === 'completed'
              ? 'Completed today · Available tomorrow'
              : daily.status === 'loading'
                ? 'Checking today’s availability…'
                : daily.status === 'error'
                  ? daily.error
                  : option.body;
          return (
          <Pressable
            key={option.id}
            testID={`friction-${option.id}`}
            accessibilityState={{ disabled: unavailable }}
            disabled={unavailable}
            onPress={() => {
              focus.selectFrictionPath(option.id);
              router.push(option.route);
            }}
            style={({ pressed }) => [
              styles.option,
              { backgroundColor: colors.card, borderColor: colors.border },
              unavailable && styles.disabled,
              pressed && styles.pressed,
            ]}
          >
            <View style={[styles.icon, { backgroundColor: colors.foreground }]}>
              <Feather name={option.icon} size={24} color={colors.primaryForeground} />
            </View>
            <View style={styles.optionCopy}>
              <Text style={[styles.optionTitle, { color: colors.foreground }]}>{option.title}</Text>
              <Text style={[styles.optionBody, { color: colors.mutedForeground }]}>{optionStatus}</Text>
            </View>
            <Feather name="chevron-right" size={22} color={colors.mutedForeground} />
          </Pressable>
          );
        })}
        {options.map((option) => {
          const daily = dailyByKind[option.id];
          return daily.status === 'error' ? (
            <Pressable
              key={`retry-${option.id}`}
              testID={`retry-${option.id}-status`}
              onPress={() => void daily.refresh()}
            >
              <Text style={[styles.retryText, { color: colors.primary }]}>
                Retry {option.id} status
              </Text>
            </Pressable>
          ) : null;
        })}
      </View>

      <Pressable
        testID="return-to-focus-from-friction"
        accessibilityState={{ disabled: !canContinue }}
        disabled={!canContinue}
        onPress={() => {
          focus.clearFrictionCheck();
          router.back();
        }}
        style={({ pressed }) => [
          styles.returnButton,
          { backgroundColor: colors.foreground },
          !canContinue && styles.disabled,
          pressed && styles.pressed,
        ]}
      >
        <Feather name="arrow-left" size={19} color={canContinue ? colors.primaryForeground : colors.mutedForeground} />
        <Text style={[styles.returnText, { color: canContinue ? colors.primaryForeground : colors.mutedForeground }]}>
          {canContinue ? 'Return to focus' : 'Complete your reset to continue'}
        </Text>
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: { justifyContent: 'center', paddingBottom: 28 },
  header: { gap: 8 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 32, lineHeight: 38, letterSpacing: -0.7 },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 17, lineHeight: 25 },
  levelPill: { alignSelf: 'flex-start', borderRadius: 12, paddingHorizontal: 11, paddingVertical: 7, marginTop: 4 },
  levelText: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.8 },
  options: { gap: 11 },
  option: { minHeight: 106, borderWidth: 1, borderRadius: 22, padding: 15, flexDirection: 'row', alignItems: 'center', gap: 13 },
  icon: { width: 50, height: 50, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  optionCopy: { flex: 1, gap: 4 },
  optionTitle: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  optionBody: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 20 },
  returnButton: { minHeight: 56, borderRadius: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 },
  returnText: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  pressed: { opacity: 0.74, transform: [{ scale: 0.985 }] },
  disabled: { opacity: 0.55 },
  retryText: { alignSelf: 'flex-end', fontFamily: 'Inter_700Bold', fontSize: 14, paddingVertical: 5 },
});
import { useAuth, useSignUp } from '@clerk/expo';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useColors } from '@/hooks/useColors';

export default function SignupScreen() {
  const colors = useColors();
  const { signUp, errors, fetchStatus } = useSignUp();
  const { isLoaded } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [code, setCode] = useState('');
  const [verificationSent, setVerificationSent] = useState(false);
  const busy = !isLoaded || fetchStatus === 'fetching';
  const message = isLoaded
    ? errors?.global?.[0]?.message ??
      errors?.fields?.emailAddress?.message ??
      errors?.fields?.password?.message ??
      errors?.fields?.code?.message
    : undefined;

  const submit = async () => {
    if (!isLoaded || !signUp) return;
    const result = await signUp.password({ emailAddress: email.trim(), password });
    if (result.error) return;
    await signUp.verifications.sendEmailCode();
    setVerificationSent(true);
  };

  const verify = async () => {
    if (!isLoaded || !signUp) return;
    await signUp.verifications.verifyEmailCode({ code });
    if (signUp.status === 'complete') await signUp.finalize({ navigate: () => router.replace('/(tabs)') });
  };

  return (
    <Screen>
      <View style={styles.header}>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>START WITH FOCUS COMPASS</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>{verificationSent ? 'Check your email.' : 'Find your focus path.'}</Text>
        <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{verificationSent ? 'Enter the verification code we sent to finish your account.' : 'Create an account to keep your practice available across devices.'}</Text>
      </View>
      <View style={[styles.form, { backgroundColor: colors.card, borderColor: colors.border }]}>
        {!verificationSent ? (
          <>
            <Text style={[styles.label, { color: colors.foreground }]}>Email address</Text>
            <TextInput editable={isLoaded} value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" placeholder="you@example.com" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} />
            <Text style={[styles.label, { color: colors.foreground }]}>Password</Text>
            <TextInput editable={isLoaded} value={password} onChangeText={setPassword} secureTextEntry placeholder="At least 8 characters" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} />
            <Pressable disabled={busy || !email || !password} onPress={submit} style={({ pressed }) => [styles.button, { backgroundColor: colors.primary }, (busy || !email || !password) && styles.disabled, pressed && styles.pressed]}>
              <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>{!isLoaded ? 'Connecting…' : busy ? 'Creating…' : 'Create account'}</Text>
            </Pressable>
          </>
        ) : (
          <>
            <Text style={[styles.label, { color: colors.foreground }]}>Verification code</Text>
            <TextInput editable={isLoaded} value={code} onChangeText={setCode} keyboardType="number-pad" placeholder="Enter your code" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground, borderColor: colors.border }]} />
            <Pressable disabled={busy || !code} onPress={verify} style={({ pressed }) => [styles.button, { backgroundColor: colors.primary }, (busy || !code) && styles.disabled, pressed && styles.pressed]}>
              <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>{!isLoaded ? 'Connecting…' : busy ? 'Verifying…' : 'Verify email'}</Text>
            </Pressable>
          </>
        )}
        {message ? <Text style={[styles.error, { color: colors.destructive }]}>{message}</Text> : null}
      </View>
      <Pressable onPress={() => router.replace('/login')} style={styles.linkButton}>
        <Text style={[styles.linkText, { color: colors.primary }]}>Already have an account? Sign in</Text>
      </Pressable>
      <View nativeID="clerk-captcha" />
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { gap: 7, alignItems: 'center', marginBottom: 12 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1, textAlign: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 31, lineHeight: 38, textAlign: 'center' },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24, textAlign: 'center' },
  form: { borderWidth: 1, borderRadius: 24, padding: 18, gap: 10 },
  label: { fontFamily: 'Inter_700Bold', fontSize: 15, marginTop: 2 },
  input: { height: 52, borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, fontFamily: 'Inter_500Medium', fontSize: 16, marginBottom: 7 },
  button: { minHeight: 54, borderRadius: 17, alignItems: 'center', justifyContent: 'center', marginTop: 6, paddingVertical: 12, paddingHorizontal: 16 },
  buttonText: { fontFamily: 'Inter_700Bold', fontSize: 17, textAlign: 'center', flexShrink: 1 },
  error: { fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 20 },
  linkButton: { alignItems: 'center', padding: 10, marginTop: 10 },
  linkText: { fontFamily: 'Inter_700Bold', fontSize: 15, textAlign: 'center' },
  disabled: { opacity: 0.5 },
  pressed: { opacity: 0.75 },
});
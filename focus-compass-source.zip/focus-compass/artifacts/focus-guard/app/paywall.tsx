import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { ActivityIndicator, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useRevenueCat } from '@/context/RevenueCatContext';
import { useColors } from '@/hooks/useColors';

const benefits = [
  ['award', 'Focus Compass Premium entitlement linked to this purchase'],
  ['refresh-cw', 'Eligible purchases can be restored'],
  ['cloud', 'Membership status stays synced across your devices'],
  ...(Platform.OS === 'ios' ? [] : [['tool', 'Native blocking and Family Guard are coming soon'] as const]),
] as const;

export default function PaywallScreen() {
  const colors = useColors();
  const revenueCat = useRevenueCat();
  const [notice, setNotice] = useState<string | null>(null);
  const monthly = revenueCat.offering?.monthly ?? revenueCat.offering?.availablePackages[0] ?? null;
  const canUseStore = Boolean(
    monthly &&
      revenueCat.configured &&
      revenueCat.ready &&
      !revenueCat.loading &&
      !revenueCat.isPremium,
  );
  const isPreview = revenueCat.storeMode === 'preview';

  return (
    <Screen>
      <View style={styles.topRow}>
        <View style={styles.secureContainer} pointerEvents="none">
          <Text style={[styles.secure, { color: colors.mutedForeground }]}>
            {isPreview ? 'PURCHASE PREVIEW' : 'STORE MEMBERSHIP'}
          </Text>
        </View>
        <Pressable
          testID="close-paywall"
          onPress={() => router.back()}
          style={({ pressed }) => [styles.close, { backgroundColor: colors.muted }, pressed && styles.pressed]}
        >
          <Feather name="x" size={20} color={colors.foreground} />
        </Pressable>
      </View>

      <View style={[styles.mark, { backgroundColor: colors.foreground }]}>
        <Feather name="shield" size={36} color={colors.primary} />
      </View>
      <Text style={[styles.title, { color: colors.foreground }]}>Focus Compass Premium</Text>
      <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
        {Platform.OS === 'ios'
          ? 'Subscribe for the Focus Compass Premium entitlement, linked to your store account.'
          : 'Subscribe for the Focus Compass Premium entitlement. Features marked coming soon are not available in this build.'}
      </Text>
      {isPreview ? (
        <View style={[styles.previewNotice, { backgroundColor: colors.secondary }]}>
          <Feather name="info" size={17} color={colors.secondaryForeground} />
          <Text style={[styles.previewText, { color: colors.secondaryForeground }]}>
            Preview mode uses RevenueCat’s Test Store. No real charge or App Store subscription is created.
          </Text>
        </View>
      ) : null}

      <View style={styles.benefits}>
        {benefits.map(([icon, label]) => (
          <View key={label} style={styles.benefit}>
            <View style={[styles.check, { backgroundColor: colors.secondary }]}>
              <Feather name={icon} size={18} color={colors.secondaryForeground} />
            </View>
            <Text style={[styles.benefitText, { color: colors.foreground }]}>{label}</Text>
          </View>
        ))}
      </View>

      <View style={[styles.plan, { backgroundColor: colors.card, borderColor: colors.primary }]}>
        <View style={styles.planCopy}>
          <Text style={[styles.planName, { color: colors.foreground }]}>Focus Compass Premium</Text>
          <Text style={[styles.planCaption, { color: colors.mutedForeground }]}>Monthly · cancel anytime</Text>
        </View>
        <Text style={[styles.price, { color: colors.foreground }]}>
          {monthly?.product.priceString ?? 'Monthly'}
        </Text>
      </View>

      {revenueCat.error ? <Text style={[styles.error, { color: colors.destructive }]}>{revenueCat.error}</Text> : null}
      {notice ? <Text style={[styles.notice, { color: colors.foreground }]}>{notice}</Text> : null}

      <Pressable
        testID="subscribe-premium"
        disabled={!canUseStore}
        onPress={async () => {
          if (!monthly) return;
          setNotice(null);
          const result = await revenueCat.purchase(monthly);
          if (result.status === 'success') {
            setNotice(isPreview ? 'Preview purchase completed. Premium is active in this test environment.' : 'Purchase completed. Premium is active.');
          } else if (result.status === 'cancelled') {
            setNotice('Purchase cancelled. You were not charged.');
          }
        }}
        style={({ pressed }) => [
          styles.subscribe,
          { backgroundColor: canUseStore ? colors.primary : colors.muted },
          pressed && styles.pressed,
        ]}
      >
        {revenueCat.loading ? (
          <ActivityIndicator color={colors.primaryForeground} />
        ) : (
          <>
            <Feather name="zap" size={18} color={canUseStore ? colors.primaryForeground : colors.mutedForeground} />
            <Text style={[styles.subscribeText, { color: canUseStore ? colors.primaryForeground : colors.mutedForeground }]}>
              {revenueCat.isPremium
                ? 'Premium is active'
                : isPreview
                  ? 'Try preview purchase'
                  : 'Subscribe to Focus Compass Premium'}
            </Text>
          </>
        )}
      </Pressable>

      <Pressable
        testID="restore-purchases"
        disabled={!revenueCat.ready || revenueCat.loading}
        onPress={async () => {
          setNotice(null);
          const result = await revenueCat.restore();
          if (result.status === 'success') setNotice('Premium restored successfully.');
          if (result.status === 'not_found') setNotice('No active Premium purchase was found for this store account.');
        }}
      >
        <Text style={[styles.restore, { color: colors.mutedForeground }]}>
          {revenueCat.operation === 'restoring' ? 'Restoring…' : 'Restore purchases'}
        </Text>
      </Pressable>
      {!revenueCat.loading && (!monthly || revenueCat.error) ? (
        <Pressable testID="retry-store" disabled={!revenueCat.configured} onPress={() => void revenueCat.reload()}>
          <Text style={[styles.restore, { color: colors.primary }]}>Retry store connection</Text>
        </Pressable>
      ) : null}
      <Text style={[styles.legal, { color: colors.mutedForeground }]}>
        {isPreview
          ? 'Test Store results apply only to this preview environment.'
          : 'Price and subscription details come from the store. Payment is charged to your store account; manage or cancel in store settings.'}
      </Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  topRow: { minHeight: 44, justifyContent: 'center', marginBottom: 10 },
  secureContainer: { ...StyleSheet.absoluteFill, justifyContent: 'center', alignItems: 'center' },
  close: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', position: 'absolute', left: 0, zIndex: 10 },
  secure: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 0.8, textAlign: 'center' },
  mark: { width: 72, height: 72, borderRadius: 24, alignItems: 'center', justifyContent: 'center', marginTop: 10, alignSelf: 'center' },
  title: { fontFamily: 'Inter_700Bold', fontSize: 36, lineHeight: 40, letterSpacing: -1.5, maxWidth: 340, textAlign: 'center', alignSelf: 'center' },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 17, lineHeight: 26, maxWidth: 350, textAlign: 'center', alignSelf: 'center' },
  previewNotice: { borderRadius: 14, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  previewText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 12, lineHeight: 18 },
  benefits: { gap: 14, marginVertical: 8 },
  benefit: { flexDirection: 'row', alignItems: 'center', gap: 13 },
  check: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  benefitText: { fontFamily: 'Inter_600SemiBold', fontSize: 16, lineHeight: 22 },
  plan: { borderWidth: 2, borderRadius: 20, padding: 16, flexDirection: 'row', alignItems: 'center' },
  planCopy: { flex: 1 },
  planName: { fontFamily: 'Inter_700Bold', fontSize: 16, flexShrink: 1 },
  planCaption: { fontFamily: 'Inter_500Medium', fontSize: 13, marginTop: 4 },
  price: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  error: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 18, textAlign: 'center' },
  notice: { fontFamily: 'Inter_600SemiBold', fontSize: 12, lineHeight: 18, textAlign: 'center' },
  subscribe: { minHeight: 56, borderRadius: 18, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, paddingVertical: 12, paddingHorizontal: 16 },
  subscribeText: { fontFamily: 'Inter_700Bold', fontSize: 17, textAlign: 'center', flexShrink: 1 },
  restore: { fontFamily: 'Inter_700Bold', fontSize: 15, textAlign: 'center' },
  legal: { fontFamily: 'Inter_500Medium', fontSize: 12, lineHeight: 18, textAlign: 'center', paddingHorizontal: 16 },
  pressed: { opacity: 0.75, transform: [{ scale: 0.98 }] },
});
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React, { useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useColors } from '@/hooks/useColors';

const TUTORIAL_KEY = 'zen-tutorial-seen-v1';
const slides = [
  { icon: 'clock' as const, title: 'Choose a window', body: 'Set a focus timer that fits the moment, then return to it whenever your attention drifts.' },
  { icon: 'wind' as const, title: 'Return to stillness', body: 'Use the Stillness page to breathe at your own pace and earn leaves for completed minutes.' },
  Platform.OS === 'ios'
    ? { icon: 'refresh-cw' as const, title: 'Reset and return', body: 'Choose a short physical or math reset when you need help returning to your task.' }
    : { icon: 'shield' as const, title: 'Make the choice visible', body: 'Pick the apps you want to avoid, then let a little friction help you keep your promise.' },
];

export default function TutorialScreen() {
  const colors = useColors();
  const [index, setIndex] = useState(0);
  const slide = slides[index];
  const finish = async () => {
    await AsyncStorage.setItem(TUTORIAL_KEY, '1');
    router.replace('/(tabs)');
  };

  return (
    <Screen>
      <View style={styles.top}>
        <View style={styles.skipContainer}>
          <Pressable onPress={finish} hitSlop={10}>
            <Text style={[styles.skip, { color: colors.mutedForeground }]}>Skip</Text>
          </Pressable>
        </View>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>WELCOME TO FOCUS COMPASS</Text>
      </View>
      <View style={[styles.hero, { backgroundColor: colors.foreground }]}>
        <View style={[styles.icon, { backgroundColor: colors.secondary }]}>
          <Feather name={slide.icon} size={42} color={colors.secondaryForeground} />
        </View>
        <Text style={styles.heroTitle}>{slide.title}</Text>
        <Text style={styles.heroBody}>{slide.body}</Text>
      </View>
      <View style={styles.dots}>
        {slides.map((item, dotIndex) => (
          <View key={item.title} style={[styles.dot, { backgroundColor: dotIndex === index ? colors.primary : colors.border }]} />
        ))}
      </View>
      <Pressable
        onPress={index === slides.length - 1 ? finish : () => setIndex((value) => value + 1)}
        style={({ pressed }) => [styles.button, { backgroundColor: colors.primary }, pressed && styles.pressed]}
      >
        <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>
          {index === slides.length - 1 ? 'Start with Focus Compass' : 'Next'}
        </Text>
        <Feather name={index === slides.length - 1 ? 'check' : 'arrow-right'} size={19} color={colors.primaryForeground} />
      </Pressable>
    </Screen>
  );
}

const styles = StyleSheet.create({
  top: { alignItems: 'center', gap: 12 },
  skipContainer: { alignSelf: 'flex-end', minHeight: 32, justifyContent: 'center' },
  eyebrow: { width: '100%', fontFamily: 'Inter_700Bold', fontSize: 13, lineHeight: 20, letterSpacing: 1.1, textAlign: 'center' },
  skip: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  hero: { minHeight: 475, borderRadius: 30, padding: 26, alignItems: 'center', justifyContent: 'center' },
  icon: { width: 96, height: 96, borderRadius: 30, alignItems: 'center', justifyContent: 'center', marginBottom: 30 },
  heroTitle: { color: '#FFF9F1', fontFamily: 'Inter_700Bold', fontSize: 30, textAlign: 'center' },
  heroBody: { color: '#E0E6E3', fontFamily: 'Inter_500Medium', fontSize: 17, lineHeight: 26, textAlign: 'center', marginTop: 13 },
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 7, marginVertical: 20 },
  dot: { width: 8, height: 8, borderRadius: 4 },
  button: { minHeight: 56, borderRadius: 18, flexDirection: 'row', gap: 9, alignItems: 'center', justifyContent: 'center', paddingVertical: 12, paddingHorizontal: 16 },
  buttonText: { fontFamily: 'Inter_700Bold', fontSize: 17, textAlign: 'center', flexShrink: 1 },
  pressed: { opacity: 0.75, transform: [{ scale: 0.985 }] },
});
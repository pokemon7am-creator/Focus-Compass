import { Feather } from '@expo/vector-icons';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { router } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { SessionReflection, useFocus } from '@/context/FocusContext';
import { useColors } from '@/hooks/useColors';

const feelings: { value: SessionReflection['feeling']; label: string; detail: string; icon: 'sun' | 'minus-circle' | 'cloud' }[] = [
  { value: 'clear', label: 'Clear', detail: 'I knew what mattered.', icon: 'sun' },
  { value: 'okay', label: 'Okay', detail: 'I made some progress.', icon: 'minus-circle' },
  { value: 'scattered', label: 'Scattered', detail: 'My attention wandered.', icon: 'cloud' },
];

export default function ReflectionScreen() {
  const colors = useColors();
  const focus = useFocus();
  const [feeling, setFeeling] = useState<SessionReflection['feeling'] | null>(null);
  const [note, setNote] = useState('');
  const [saveError, setSaveError] = useState('');

  useEffect(() => {
    if (focus.hydrated && !focus.pendingReflectionId) {
      router.replace('/(tabs)');
    }
  }, [focus.hydrated, focus.pendingReflectionId]);

  const leave = () => router.replace('/(tabs)');
  const save = () => {
    setSaveError('');
    if (!feeling) {
      setSaveError('Choose how your focus felt before saving.');
      return;
    }
    if (!focus.pendingReflectionId) {
      setSaveError('This session is already saved. Return to your focus history.');
      return;
    }
    const reflection: SessionReflection = {
      feeling,
      ...(note.trim() ? { note: note.trim() } : {}),
    };
    if (!focus.saveReflection(reflection)) {
      setSaveError('This reflection could not be saved. Return to your focus history and try again.');
      return;
    }
    leave();
  };

  return (
    <KeyboardAvoidingView behavior="padding" style={styles.keyboard}>
      <Screen scroll style={styles.screen}>
        <View style={styles.header}>
          <View style={[styles.icon, { backgroundColor: colors.accent }]}>
            <Feather name="edit-3" size={30} color={colors.accentForeground} />
          </View>
          <Pressable
            testID="skip-reflection"
            accessibilityRole="button"
            accessibilityLabel="Skip reflection"
            onPress={() => {
              focus.skipReflection();
              leave();
            }}
            style={({ pressed }) => [styles.skipButton, { borderColor: colors.border }, pressed && styles.pressed]}
          >
            <Text style={[styles.skipText, { color: colors.mutedForeground }]}>Skip</Text>
          </Pressable>
        </View>

        <View style={styles.copy}>
          <Text style={[styles.eyebrow, { color: colors.primary }]}>SESSION COMPLETE</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>How did your focus feel?</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            A quick check-in keeps your focus history honest. There is no wrong answer.
          </Text>
        </View>

        <View style={styles.choices}>
          {feelings.map((item) => {
            const selected = feeling === item.value;
            return (
              <Pressable
                key={item.value}
                testID={`reflection-${item.value}`}
                accessibilityRole="radio"
                accessibilityLabel={`${item.label}. ${item.detail}`}
                accessibilityState={{ selected }}
                onPress={() => setFeeling(item.value)}
                style={({ pressed }) => [
                  styles.choice,
                  { backgroundColor: colors.card, borderColor: selected ? colors.primary : colors.border },
                  selected && { backgroundColor: colors.secondary },
                  pressed && styles.pressed,
                ]}
              >
                <View style={[styles.choiceIcon, { backgroundColor: selected ? colors.primary : colors.muted }]}>
                  <Feather name={item.icon} size={24} color={selected ? colors.primaryForeground : colors.foreground} />
                </View>
                <View style={styles.choiceCopy}>
                  <Text style={[styles.choiceLabel, { color: colors.foreground }]}>{item.label}</Text>
                  <Text style={[styles.choiceDetail, { color: colors.mutedForeground }]}>{item.detail}</Text>
                </View>
                {selected ? <Feather name="check-circle" size={24} color={colors.primary} /> : null}
              </Pressable>
            );
          })}
        </View>

        <View style={styles.noteSection}>
          <Text style={[styles.noteLabel, { color: colors.foreground }]}>Add a note <Text style={{ color: colors.mutedForeground }}>(optional)</Text></Text>
          <TextInput
            testID="reflection-note"
            accessibilityLabel="Optional reflection note"
            value={note}
            onChangeText={setNote}
            placeholder="What helped or got in the way?"
            placeholderTextColor={colors.mutedForeground}
            maxLength={140}
            multiline
            textAlignVertical="top"
            style={[styles.noteInput, { backgroundColor: colors.card, borderColor: colors.border, color: colors.foreground }]}
          />
          <Text style={[styles.counter, { color: colors.mutedForeground }]}>{note.length}/140</Text>
        </View>

        <Pressable
          testID="save-reflection"
          accessibilityRole="button"
          accessibilityLabel="Save reflection"
          onPress={save}
          style={({ pressed }) => [
            styles.saveButton,
            { backgroundColor: colors.primary, opacity: feeling ? 1 : 0.55 },
            pressed && styles.pressed,
          ]}
        >
          <Feather name="check" size={21} color={colors.primaryForeground} />
          <Text style={[styles.saveText, { color: colors.primaryForeground }]}>Save reflection</Text>
        </Pressable>
        {saveError ? (
          <Text accessibilityRole="alert" style={[styles.saveError, { color: colors.foreground }]}>
            {saveError}
          </Text>
        ) : null}
      </Screen>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  keyboard: { flex: 1 },
  screen: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  icon: { width: 64, height: 64, borderRadius: 23, alignItems: 'center', justifyContent: 'center' },
  skipButton: { minHeight: 46, borderWidth: 1, borderRadius: 17, paddingHorizontal: 18, justifyContent: 'center' },
  skipText: { fontFamily: 'Inter_700Bold', fontSize: 15 },
  copy: { gap: 8 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 31, lineHeight: 38, letterSpacing: -0.7 },
  subtitle: { fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 24 },
  choices: { gap: 11 },
  choice: { minHeight: 84, borderRadius: 20, borderWidth: 1, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 12 },
  choiceIcon: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  choiceCopy: { flex: 1, gap: 3 },
  choiceLabel: { fontFamily: 'Inter_700Bold', fontSize: 18 },
  choiceDetail: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 20 },
  noteSection: { gap: 8 },
  noteLabel: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  noteInput: { minHeight: 86, borderRadius: 18, borderWidth: 1, padding: 14, fontFamily: 'Inter_500Medium', fontSize: 16, lineHeight: 22 },
  counter: { alignSelf: 'flex-end', fontFamily: 'Inter_500Medium', fontSize: 12 },
  saveButton: { minHeight: 58, borderRadius: 19, flexDirection: 'row', gap: 9, alignItems: 'center', justifyContent: 'center' },
  saveText: { fontFamily: 'Inter_700Bold', fontSize: 17 },
  saveError: { fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 21, textAlign: 'center' },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});
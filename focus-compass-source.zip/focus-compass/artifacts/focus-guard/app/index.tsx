import AsyncStorage from '@react-native-async-storage/async-storage';
import { router } from 'expo-router';
import React, { useEffect } from 'react';
import { ActivityIndicator, View } from 'react-native';
import colors from '@/constants/colors';

const TUTORIAL_KEY = 'zen-tutorial-seen-v1';

export default function EntryScreen() {
  useEffect(() => {
    AsyncStorage.getItem(TUTORIAL_KEY)
      .then((seen) => router.replace(seen === '1' ? '/(tabs)' : '/tutorial'))
      .catch(() => router.replace('/tutorial'));
  }, []);

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.light.background }}>
      <ActivityIndicator color={colors.light.primary} />
    </View>
  );
}
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import React from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useColors } from '@/hooks/useColors';

const sections = [
  {
    title: '1. Using Focus Compass',
    body: Platform.OS === 'ios'
      ? 'Focus Compass provides timers, attention-reset tools, breathing exercises, study support, sounds, and in-app rewards. Use the app only for lawful purposes and do not rely on it as a replacement for your own judgment.'
      : 'Focus Compass provides timers, app-friction tools, breathing exercises, study support, sounds, and in-app rewards. Use the app only for lawful purposes and do not rely on it as a replacement for your own judgment.',
  },
  {
    title: Platform.OS === 'ios' ? '2. Focus timers and resets' : '2. Focus tools and app blocking',
    body: Platform.OS === 'ios'
      ? 'Focus timers, reminders, and optional attention resets are intended to support your choices, not guarantee them. Interruptions and device settings can affect timers and reminders. You remain responsible for important messages, alarms, and other device needs.'
      : 'App blocking and focus reminders are intended to support your choices, not guarantee them. Device permissions, operating-system limits, interruptions, and settings can affect how blocking works. You remain responsible for important messages, alarms, and other device needs.',
  },
  {
    title: '3. Breathing and wellbeing',
    body: 'Breathing exercises are general wellness content, not medical advice or treatment. Breathe comfortably, stop if you feel lightheaded or uncomfortable, and seek professional help for medical concerns or emergencies.',
  },
  {
    title: '4. AI Tutor',
    body: 'Tutor explanations are generated study assistance. They may be incomplete or incorrect, so check important answers against your course materials, a trusted source, or a qualified instructor. Do not submit private or sensitive information.',
  },
  {
    title: '5. Rewards and purchases',
    body: 'Leaves, collectibles, soundscapes, and other rewards are in-app features and have no cash value. Any Premium purchase is handled through the applicable app store or purchase provider and is subject to that provider’s terms, billing rules, and refund process.',
  },
  {
    title: '6. Accounts and saved data',
    body: 'You are responsible for activity performed through your account. We may save your settings and progress so features work across sessions and supported devices. Do not use another person’s account or attempt to interfere with syncing.',
  },
  {
    title: '7. Availability and changes',
    body: 'Features may change, be unavailable, or depend on your device, permissions, network, or third-party services. We may update these terms and the app as Focus Compass evolves. Continued use after an update means you accept the revised terms.',
  },
  {
    title: '8. Acceptance',
    body: 'By using Focus Compass, you agree to these Terms of Use. If you do not agree, do not use the app.',
  },
];

export default function TermsScreen() {
  const colors = useColors();

  return (
    <Screen>
      <View style={styles.header}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Go back"
          onPress={() => router.back()}
          style={({ pressed }) => [
            styles.backButton,
            { backgroundColor: colors.secondary, borderColor: colors.border },
            pressed && styles.pressed,
          ]}
        >
          <Feather name="arrow-left" size={19} color={colors.primary} />
          <Text style={[styles.backText, { color: colors.foreground }]}>Back</Text>
        </Pressable>
        <Text style={[styles.eyebrow, { color: colors.primary }]}>FOCUS COMPASS</Text>
        <Text style={[styles.title, { color: colors.foreground }]}>Terms of Use</Text>
        <Text style={[styles.updated, { color: colors.mutedForeground }]}>Effective September 17, 2026</Text>
      </View>

      <View style={[styles.intro, { backgroundColor: colors.secondary, borderColor: colors.border }]}>
        <Feather name="book-open" size={21} color={colors.primary} />
        <Text style={[styles.introText, { color: colors.secondaryForeground }]}>
          These terms explain the focus, wellness, study, reward, and purchase features in Focus Compass.
        </Text>
      </View>

      {sections.map((section) => (
        <View key={section.title} style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{section.title}</Text>
          <Text style={[styles.sectionBody, { color: colors.mutedForeground }]}>{section.body}</Text>
        </View>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center', gap: 7, marginBottom: 2 },
  backButton: {
    alignSelf: 'flex-start',
    minHeight: 42,
    borderWidth: 1,
    borderRadius: 14,
    paddingHorizontal: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    marginBottom: 9,
  },
  backText: { fontFamily: 'Inter_700Bold', fontSize: 14 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 1.1 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 36, textAlign: 'center' },
  updated: { fontFamily: 'Inter_500Medium', fontSize: 13 },
  intro: { borderWidth: 1, borderRadius: 18, padding: 15, flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  introText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 14, lineHeight: 21 },
  section: { borderWidth: 1, borderRadius: 18, padding: 16, gap: 7 },
  sectionTitle: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  sectionBody: { fontFamily: 'Inter_500Medium', fontSize: 14, lineHeight: 22 },
  pressed: { opacity: 0.76, transform: [{ scale: 0.985 }] },
});
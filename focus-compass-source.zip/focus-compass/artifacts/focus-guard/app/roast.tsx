import { Feather } from '@expo/vector-icons';
import { useGenerateRoast } from '@workspace/api-client-react';
import { router, useLocalSearchParams } from 'expo-router';
import React, { useEffect, useRef, useState } from 'react';
import { Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Screen } from '@/components/Screen';
import { useFocus } from '@/context/FocusContext';
import { useRewards } from '@/context/RewardsContext';
import { useColors } from '@/hooks/useColors';

function getFallbackRoast(
  mode: 'override' | 'app-switch' | 'end-session',
  style: 'classic' | 'bold' | 'dry' | 'chaos' | 'margin-notes',
  elapsedMinutes: number,
) {
  if (mode === 'end-session') {
    if (style === 'chaos') return 'Ending early? Incredible. The timer is now filing a missing-person report.';
    if (style === 'dry') return 'Ending early. A bold choice for someone who selected a timer.';
    if (style === 'bold') return 'Ending early? Your excuses have excellent attendance.';
    if (style === 'margin-notes') return 'Ending early? I left a small note in the margin: this could have been a paragraph.';
    return 'Ending early? The timer was not the one who got distracted.';
  }

  if (mode === 'app-switch') {
    if (elapsedMinutes >= 45) return 'You built forty-five minutes of momentum, then traded it for an app you already knew would still be there. Spectacular timing.';
    if (elapsedMinutes >= 25) return 'You protected your attention for nearly half an hour, then handed it over without even charging rent.';
    if (elapsedMinutes >= 10) return 'Ten focused minutes in, and the distraction still convinced you it had breaking news about absolutely nothing.';
    if (style === 'chaos') return 'Back already? The distraction has been defeated by its own mediocrity.';
    if (style === 'dry') return 'You left during a live focus session. Noted.';
    if (style === 'bold') return 'Back already? That distraction must have been devastatingly average.';
    if (style === 'margin-notes') return 'Back already? The margin notes say this plot twist needed more foreshadowing.';
    return 'You left during a live focus session. Your attention noticed, even if the timer stayed polite.';
  }

  if (style === 'chaos') return 'You paid attention to everything except the thing you chose. A bold experiment.';
   if (style === 'dry') return 'You opened Focus Compass. Then immediately practiced not using Focus Compass.';
  if (style === 'bold') return 'You paid attention to everything except the thing you chose to do.';
   if (style === 'margin-notes') return 'You opened Focus Compass, then added a footnote to your focus plan instead of following it.';
   return 'You opened Focus Compass to avoid scrolling. Bold strategy to immediately request more scrolling.';
}

export default function RoastScreen() {
  const colors = useColors();
  const focus = useFocus();
  const rewards = useRewards();
  const [seconds, setSeconds] = useState(10);
  const actingRef = useRef(false);
  const { mode } = useLocalSearchParams<{ mode?: string }>();
  const isEndingSession = mode === 'end-session';
  const isAppSwitch = mode === 'app-switch';
  const elapsedMinutes = Math.floor((focus.sessionSeconds - focus.remainingSeconds) / 60);
  const overrideCount = focus.overridesToday;
  const roastMode = isEndingSession ? 'end-session' : isAppSwitch ? 'app-switch' : 'override';
  const roast = useGenerateRoast();
  const requestedRoast = useRef(false);
  const fallbackRoast = getFallbackRoast(roastMode, rewards.equipped.roast, elapsedMinutes);

  useEffect(() => {
    if (requestedRoast.current) return;
    requestedRoast.current = true;
    roast.mutate({
      data: {
        style: rewards.equipped.roast,
        mode: roastMode,
        elapsedMinutes: Math.max(0, elapsedMinutes),
        overrideCount,
      },
    });
  }, [elapsedMinutes, overrideCount, rewards.equipped.roast, roast, roastMode]);

  useEffect(() => {
    if (seconds <= 0) return;
    const timer = setTimeout(() => setSeconds((value) => value - 1), 1000);
    return () => clearTimeout(timer);
  }, [seconds]);

  const override = () => {
    if (seconds > 0 || actingRef.current) return;
    actingRef.current = true;
    focus.recordOverride();
    const sessionId = isEndingSession ? focus.endSession() : null;
    if (isEndingSession && sessionId) router.replace('/reflection');
    else router.back();
  };

  return (
    <Screen style={styles.screen}>
      <Pressable
        testID="cancel-unlock"
        onPress={() => router.back()}
        style={({ pressed }) => [styles.close, { borderColor: colors.border }, pressed && styles.pressed]}
      >
        <Feather name="x" size={20} color={colors.foreground} />
      </Pressable>

      <View style={[styles.icon, { backgroundColor: colors.accent }]}>
        <Feather name="message-circle" size={34} color={colors.accentForeground} />
      </View>

      <Text style={[styles.label, { color: colors.primary }]}>
        {isEndingSession ? 'MISSION CHECK' : isAppSwitch ? 'FOCUS CHECK' : 'A QUICK REALITY CHECK'}
      </Text>
      <Text style={[styles.roast, { color: colors.foreground }]}>
        “{roast.data?.roast ?? fallbackRoast}”
      </Text>
      <Text style={[styles.context, { color: colors.mutedForeground }]}>
        {isEndingSession
          ? `${elapsedMinutes} whole ${elapsedMinutes === 1 ? 'minute' : 'minutes'} will be recorded if you end now.`
          : isAppSwitch
             ? Platform.OS === 'ios'
               ? 'You returned during a focus session. Take this pause, then choose whether to return to your timer.'
               : 'Focus Compass can detect that you left, but native device access is still required to identify and block the outside app.'
           : `You have overridden ${overrideCount} ${overrideCount === 1 ? 'time' : 'times'} today. The app will still be there after your focus ${Platform.OS === 'ios' ? 'session' : 'block'}.`}
      </Text>

      <View style={[styles.countdown, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={[styles.countdownNumber, { color: seconds > 0 ? colors.primary : colors.success }]}>
          {seconds > 0 ? seconds : 'Pause complete'}
        </Text>
        <Text style={[styles.countdownLabel, { color: colors.mutedForeground }]}>
          {seconds > 0 ? 'seconds to reconsider' : 'Choose your next step'}
        </Text>
      </View>

      <View style={styles.actions}>
        <Pressable
          testID="return-to-focus"
          onPress={() => router.back()}
          style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.foreground }, pressed && styles.pressed]}
        >
          <Feather name="arrow-left" size={18} color={colors.primaryForeground} />
          <Text style={[styles.primaryText, { color: colors.primaryForeground }]}>Return to focus</Text>
        </Pressable>
        <Pressable
          testID="override-guard"
          disabled={seconds > 0}
          onPress={override}
          style={({ pressed }) => [
            styles.overrideButton,
              { borderColor: colors.border, opacity: seconds > 0 ? 0.45 : 1 },
            pressed && styles.pressed,
          ]}
        >
          <Text style={[styles.overrideText, { color: seconds > 0 ? colors.mutedForeground : colors.foreground }]}>
            {isEndingSession ? 'End session anyway' : 'Override anyway'}
          </Text>
        </Pressable>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  screen: { justifyContent: 'center', paddingBottom: 34 },
  close: { position: 'absolute', top: 0, right: 20, width: 40, height: 40, borderRadius: 20, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  icon: { width: 68, height: 68, borderRadius: 24, alignItems: 'center', justifyContent: 'center' },
  label: { fontFamily: 'Inter_700Bold', fontSize: 13, letterSpacing: 1.1 },
  roast: { fontFamily: 'Inter_700Bold', fontSize: 31, lineHeight: 40, letterSpacing: -0.7 },
  context: { fontFamily: 'Inter_500Medium', fontSize: 17, lineHeight: 26 },
  countdown: { borderWidth: 1, borderRadius: 20, padding: 16, flexDirection: 'row', flexWrap: 'wrap', alignItems: 'baseline', gap: 8 },
  countdownNumber: { fontFamily: 'Inter_700Bold', fontSize: 25 },
  countdownLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 15 },
  actions: { gap: 11 },
  primaryButton: { minHeight: 56, paddingVertical: 12, paddingHorizontal: 16, borderRadius: 18, flexDirection: 'row', gap: 9, alignItems: 'center', justifyContent: 'center' },
  primaryText: { fontFamily: 'Inter_700Bold', fontSize: 17, flexShrink: 1, textAlign: 'center' },
  overrideButton: { minHeight: 50, paddingVertical: 12, paddingHorizontal: 16, borderRadius: 18, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  overrideText: { fontFamily: 'Inter_600SemiBold', fontSize: 16, textAlign: 'center' },
  pressed: { opacity: 0.72, transform: [{ scale: 0.98 }] },
});